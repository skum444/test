package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.OracleBBC;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.DonePage;
import com.rbs.automation.dj.pages.FinancialsPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DBVerificationStepDefinitions {

    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    DonePage donePage;
    private HelperFunctions helper = new HelperFunctions();

    public DBVerificationStepDefinitions(TestContext context) {

        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        donePage = testContext.getPageObjectManager().getDonePage(context);

    }

    @Then("^verify that the DB table LND_APP_REASON_TB\\.REASON_TEXT has been updated with reason \"([^\"]*)\"$")
    public void verify_that_the_DB_table_LND_APP_REASON_TB_REASON_TEXT_has_been_updated_with_reason(String reason)
            throws Throwable {


        String dbReason = helper.returnReasonForApplication(testContext, driver);
        if (!dbReason.toLowerCase().contains(reason.toLowerCase()))
            helper.failTest("Check DB Reason text", "Expected reason: " + reason, "Actual: " + dbReason, driver, testContext);

    }

    @Then("^verify that the DB table LND_APP_STATE_TB_APPL_STATE has been updated with application state set to \"([^\"]*)\"$")
    public void verify_that_the_DB_table_LND_APP_STATE_TB_APPL_STATE_has_been_updated_with_application_state_set_to(
            String appStatus) throws Throwable {


        String dbAppState = helper.returnApplicationState(testContext, driver);

        if (!dbAppState.toLowerCase().contains(appStatus.toLowerCase()))
            helper.failTest("Check Application status text", "Expected reason: " + dbAppState, "Actual: " + appStatus, driver, testContext);

    }

    @Then("^verify DB will store the RMP data$")
    public void verifyDBWillStoreTheRMPData() throws Exception {
        OracleBBC oracleBBC = new OracleBBC(testContext);
        oracleBBC.fetchTurnoverAmountForApplication("QA_04_NWB");
    }

    @Then("the system stores the consent flag to the table LND_APP_APPL_DETAIL_TB.SOFT_SEARCH_CONSENT_FLAG$")
    public void system_stores_consent_flag() throws Exception {
        Thread.sleep(30000);
        String consentFlag = helper.returnConsentFlag(testContext);
        try {
            if (!consentFlag.equalsIgnoreCase("Y"))
                helper.failTest("Check consent flag:FAILED", "Y", consentFlag, driver, testContext);
                FinancialsPage.validationStatus="Check consent flag FAILED: Expected:'Y';Actual:"+consentFlag;
        }catch(Exception e){
            helper.failTest("Error during consent validation in DB", "",e.getMessage(), driver, testContext);
        }
        FinancialsPage.validationStatus="Consent Flag in LND_APP_APPL_DETAIL_TB.SOFT_SEARCH_CONSENT_FLAG is as expected:Y";
    }


	
	
	@Then("^verify that the initial status of KP CONFIRMED FLAG is unconfirmed$")
	public void verify_that_the_initial_status_of_KP_CONFIRMED_FLAG_is_unconfirmed() throws Throwable {
		String kpState = helper.statusOfKP(testContext, driver);
		System.out.println("Status of KP before editing is"+kpState);
		
		
	}

    @And("^verify that the DB table LND_APP_STATE_TB_APPL_SUB_STATUS has been updated with application state set to \"([^\"]*)\"$")
    public void verify_that_the_DB_table_LND_APP_STATE_TB_APPL_SUB_STATUS_has_been_updated_with_application_sub_status_set_to(String applSubStatus) throws Exception {
        String dbAppState = helper.returnApplicationSubStatus(testContext, driver);
        if (!dbAppState.toLowerCase().contains(applSubStatus.toLowerCase()))
            helper.failTest("Check Application status text", "Expected reason: " + dbAppState, "Actual: " + applSubStatus, driver, testContext);
    }


    @And("^the system sets the Expiry Date of the application in LND_APP_APPL_DETAIL_TB.APP_EXPIRY_DATE_TS$")
    public void system_sets_expiry_date() throws Exception {
        String dbExpDate = helper.returnApplicationExpiryDate(testContext, driver);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String applStartDate = helper.returnApplicationStartDate(testContext, driver);
        Calendar c1 = Calendar.getInstance();
        c1.setTime(sdf.parse(applStartDate));
        c1.add(Calendar.DAY_OF_MONTH, 28);
        String expExpiryDate = sdf.format(c1.getTime());
        System.out.println("Date after Addition: " + expExpiryDate);
        if (!expExpiryDate.equals(dbExpDate)) {
            helper.failTest("Check Application Expiry Date", "Expected reason: " + expExpiryDate, "Actual: " + dbExpDate, driver, testContext);
        }
    }
    
    
    @Then("^validate if valid FI flag is \"([^\\\"]*)\"$")
    public void validate_if_FI_Flag_is(String expFIFlag) throws Exception{
    	Thread.sleep(10000);
    	String actualValidFIFlag=helper.returnFIFlag(testContext);
    	if(!expFIFlag.equals(actualValidFIFlag)) {
    		FinancialsPage.validationStatus="Valid FI Flag Validation:FAILED\nExpected flag: "+ expFIFlag+"\nActual:" + actualValidFIFlag;
    		 helper.failTest("Valid Fi Flag Validation:FAILED", "Expected flag: " + expFIFlag, "Actual: " + actualValidFIFlag, driver, testContext);
    	}
		FinancialsPage.validationStatus="Valid FI Flag Validation:PASSED: \nExpected flag: "+ expFIFlag+"\nActual:" + actualValidFIFlag;
	    
    }
    
    @And ("^verify that the DB table LND_APP_STATE_TB_APPL_PREV_STATE has been updated with application state set to \"([^\\\"]*)\"$")
    public void verify_appl_prev_state(String appStatus)throws Exception{
    String dbAppState = helper.returnApplicationPrevState(testContext, driver);
    if (!dbAppState.toLowerCase().contains(appStatus.toLowerCase()))
        helper.failTest("Check Prev Application status text", "Expected reason: " + dbAppState, "Actual: " + appStatus, driver, testContext);
    }
    
    @Then("^verify that the DB table LND_BDT_PERS_CUST_DET_TB.KP_STATE_IND has been updated with reason \"([^\"]*)\"$")
	public void verify_KP_STATE_IND_Value(String expected_KP_STATUS_IND) throws Throwable {
		String kp_state_ind = helper.statusOfKP_STATE_IND_Value(testContext, driver);
		System.out.println("kp_state_ind"+kp_state_ind);
		System.out.println("expected_KP_STATUS_IND"+expected_KP_STATUS_IND);
		if(!kp_state_ind.equals(expected_KP_STATUS_IND)) {
			helper.failTest("Valid KP_STATE_IND Column Validation:FAILED", "Expected flag: " + expected_KP_STATUS_IND, "Actual: " + kp_state_ind, driver, testContext);
		}
    }
	   
		@Then("^verify that the DB table LND_BDT_PERS_CUST_DET_TB.KP_STATE_IND has been updated with removed reason$")
		public void verify_KP_STATE_IND_removed_Value() throws Throwable {
			String kp_state_ind = helper.statusOfKP_STATE_IND_removed_Value(testContext, driver);
			System.out.println("kp_state_ind"+kp_state_ind);
			
			if(kp_state_ind.equals('2')) {
				helper.failTest("Valid KP_STATE_IND Column Validation:FAILED", "Expected flag count is: 2" , "Actual flag count is: " + kp_state_ind, driver, testContext);
			}		
		
		
		
	}
    
}
