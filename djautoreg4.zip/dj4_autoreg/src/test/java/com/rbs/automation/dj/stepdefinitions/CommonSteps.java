package com.rbs.automation.dj.stepdefinitions;

import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.Reporter;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.TestRun;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.HomePage;

import com.rbs.automation.dj.testcontext.TestContext;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CommonSteps {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	HomePage homePage;
	TestRun reporter;

	private HelperFunctions helper = new HelperFunctions();

	public CommonSteps(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		homePage = testContext.getPageObjectManager().getHomePage(context);

	}


	@Given("^I'm on the \"([^\"]*)\" page$")
	public void i_m_on_the_page(String page) throws Throwable {

		// driver.get("http://gbmacvcsw2517.rbsres01.net:8887/content/#/"+page);
		Thread.sleep(2000);
		driver.get("http://gbmacvcsw2517.rbsres01.net:8887/content/#/personalisedquotepage");
		//driver.get("http://gbmacvcsw2517.rbsres01.net:8887/content/#/financials");
	}


	@Given("^URL has been launched for the \"([^\"]*)\" for the \"([^\"]*)\" for customer segment \"([^\"]*)\" and for \"([^\"]*)\" and for \"([^\"]*)\"$")
	public void url_has_been_launched_for_the_for_the_for_customer_segment_and_for_and_for(String testName, String regBrand, String segment, String entityType, String jiraRef) throws Throwable {

		// initialise the test
		helper.initialiseTest(testContext, testName, regBrand,segment, entityType, jiraRef);

		// navigate to homepage
		homePage.navigateTo_HomePage(regBrand);
	}



	@Given("^URL has been launched for the \"([^\"]*)\" for the \"([^\"]*)\" for BPM \"([^\"]*)\"$")

	public void url_has_been_launched_for_the_for_the_for_BPM(String testName, String regBrand,
															  String segment) throws Throwable {


		String entityType = (String)testContext.getScenarioContext().getContext(TestData.EnityType);
		String jiraRef = (String)testContext.getScenarioContext().getContext(TestData.JIRA);
		// initialise the test

		helper.initialiseTest(testContext, testName, regBrand,segment, entityType, jiraRef);


		// navigate to BPM homepage
		homePage.navigateTo_BPMHomePage(regBrand);
	}


	@When("^user clicks the \"([^\"]*)\" link$")
	public void user_clicks_the_link(String link) throws Throwable {

		driver.findElement(By.linkText(link)).click();
	}

	@Then("^user is redirected to \"([^\"]*)\" site$")
	public void user_is_redirected_to_site(String site) throws Throwable {

		if (driver.getCurrentUrl().contains("quote.lombard.co.uk"))
			testContext.scenarioContext.setContext(TestData.Status, "Pass");

		else
			testContext.scenarioContext.setContext(TestData.Status, "Fail");

	}

	@Then("^return user to login page$")
	public void return_user_to_login_page() throws Throwable {

		Thread.sleep(2000);
		String url = helper.getURLLink((String) testContext.scenarioContext.getContext(TestData.Brand));
		driver.get(url);
	}

	@Then("^the \"([^\"]*)\" page is displayed$")
	public void the_page_is_displayed(String pageHeader) throws Throwable {

		driver.findElement(By.xpath("//h1[contains(text(), '" + pageHeader + "')]")).isDisplayed();

	}

	@When("^the User clicks the \"([^\"]*)\" link$")
	public void the_User_clicks_the_link(String navigationLink) throws Throwable {

		driver.findElement(By.xpath("//a[contains(text(), '" + navigationLink + "')]")).click();
	}

	@When("^take a screenshot$")
	public void take_a_screenshot() throws Throwable {

		helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
	}

	@Before
	public void before(Scenario scenario) throws Throwable {
		String scenarioName = scenario.getName();
		System.out.println("===========================================================================");
		System.out.println("============================== TEST STARTED  ===============================");
		System.out.println("===========================================================================");
		System.out.println("===========================================================================");
		System.out.println("==== Running Scenario : " + scenarioName);
		System.out.println("==== DIR : " + System.getProperty("user.dir"));


	}

	
	@After
	public void TearDown(Scenario scenario) throws Throwable {

	   // Capture state of application when test complete - Read the Reason Table text
	   // & other values

	   helper.captureReasonText(testContext, driver);
	   helper.returnApplicationState(testContext, driver);
	   
	   String scenarioName = scenario.getName();
	   testContext.scenarioContext.setContext(TestData.ScenarioName, scenarioName);
	   
	   
	   
	   // Aplication Start and End date
	   
	  
	try {
	    String dateStarteApp = (String) testContext.scenarioContext.getContext(TestData.ApplicationStartDate);
		String dateExpApp = (String) testContext.scenarioContext.getContext(TestData.ApplicationExpDate);
			
		
		//Parsing the date
		LocalDate dateBefore = LocalDate.parse(dateStarteApp);
		LocalDate dateAfter = LocalDate.parse(dateExpApp);
			
		//calculating number of days in between
		long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
			
		testContext.scenarioContext.setContext(TestData.ApplicationExpiryDays,noOfDaysBetween);

	}catch(Exception e)
	{
	 System.out.println("Applcation start and expiry could not be calculated");
	}
		

	   String   testRunName = TestRun.getTestRunName();
	       testContext.scenarioContext.setContext(TestData.TestRunName, testRunName);


	   String testStatus = (String) testContext.scenarioContext.getContext(TestData.Status);

	   String needsInfo = (String)testContext.scenarioContext.getContext(TestData.NeedsInfo);

	  
	   needsInfo = "" + needsInfo;

	   if(!needsInfo.contains("null")) {
	      needsInfo = needsInfo.replace(",", "<br>");
	   } else{
	      needsInfo = "N/A";
	   }

	   testContext.scenarioContext.setContext(TestData.NeedsInfo, needsInfo);

	   //write test data
	   System.out.println("===========================================================================");
	   System.out.println("============================== TEST STATUS ================================");
	   System.out.println("===========================================================================");

	   System.out.println("==== TEST RUN: " + testContext.scenarioContext.getContext(TestData.TestRunName));
	   System.out.println("==== TEST: " + testContext.scenarioContext.getContext(TestData.TestName));
	   System.out.println("==== SCENARIO NAME: " + testContext.scenarioContext.getContext(TestData.ScenarioName));
	   System.out.println("==== TEST STATUS: " + testContext.scenarioContext.getContext(TestData.Status));
	   System.out.println("==== JIRA REF: " + testContext.scenarioContext.getContext(TestData.JIRA));
	   System.out.println("==== APPLICATION ID: " + testContext.scenarioContext.getContext(TestData.ApplicationID));
	   System.out.println("==== APPLICATION Start Date: " + testContext.scenarioContext.getContext(TestData.ApplicationStartDate));
	   System.out.println("==== APPLICATION Expiry Date: " + testContext.scenarioContext.getContext(TestData.ApplicationExpDate));	  
	   System.out.println("==== DBID: " + testContext.scenarioContext.getContext(TestData.DBID));
	   System.out.println("==== BIN: " + testContext.scenarioContext.getContext(TestData.BIN));
	   System.out.println("==== SIC Code: " +  testContext.scenarioContext.getContext(TestData.SICCode));	   
	   System.out.println("==== BRAND: " + testContext.scenarioContext.getContext(TestData.Brand));
	   System.out.println("==== SEGMENT: " + testContext.scenarioContext.getContext(TestData.Segment));
	   System.out.println("==== ENTITY TYPE: " + testContext.scenarioContext.getContext(TestData.EnityType));
	   System.out.println("==== NEEDS INFO: " + testContext.scenarioContext.getContext(TestData.NeedsInfo));
	   System.out.println("==== APPLICATION STATUS: " + testContext.scenarioContext.getContext(TestData.ApplicationStatus));
	   System.out.println("==== REASON TEXT: " + testContext.scenarioContext.getContext(TestData.ReasonText));
	  System.out.println("==== REPORT : " + testContext.scenarioContext.getContext(TestData.TestSnapShotDir));


	   // Write test status and values to the report
	   Reporter.addScenarioLog("<b=>=================================== TEST STATUS ===================================</b>");
	   Reporter.addScenarioLog("<b>TEST:</b> " + testContext.scenarioContext.getContext(TestData.TestName) + ", <b>TEST STATUS: </b>" + testContext.scenarioContext.getContext(TestData.Status));
	   Reporter.addScenarioLog("<b>JIRA REF: </b>" + testContext.scenarioContext.getContext(TestData.JIRA) + ", <b>APPLICATION STATUS:</b> " + testContext.scenarioContext.getContext(TestData.ApplicationStatus));
	   Reporter.addScenarioLog("<b>DBID: </b>" + testContext.scenarioContext.getContext(TestData.DBID) + ", <b>BRAND:</b> " + testContext.scenarioContext.getContext(TestData.Brand) + ", <b>SEGMENT:</b> " + testContext.scenarioContext.getContext(TestData.Segment) +", <b>ENTITY TYPE:</b> " + testContext.scenarioContext.getContext(TestData.EnityType) +", <b>APPLICATION ID: </b>" + testContext.scenarioContext.getContext(TestData.ApplicationID));
	   Reporter.addScenarioLog("<b>APP Start Date: </b>" + testContext.scenarioContext.getContext(TestData.ApplicationStartDate) + ", <b>Application Exp Date:</b> " + testContext.scenarioContext.getContext(TestData.ApplicationExpDate));
	   Reporter.addScenarioLog("<b>BIN: </b>" + testContext.scenarioContext.getContext(TestData.BIN));
	   Reporter.addScenarioLog("<b>ENTITY TYPE: </b>" + testContext.scenarioContext.getContext(TestData.EnityType) + ", <b>APPLICATION STATUS:</b> " + testContext.scenarioContext.getContext(TestData.EnityType));
	   Reporter.addScenarioLog("<b>NEEDS INFO: </b> " + needsInfo);
	   Reporter.addScenarioLog("<b>Reason Text:</b> " + testContext.scenarioContext.getContext(TestData.ReasonText));


	   //Reporter.addScenarioLog("<b>===================================================================================</b></B>");

	   // take a screen shot of the last page
	   helper.addfullScreenCaptureToExtentReport(driver, testContext);

	   if (testStatus.equalsIgnoreCase("fail"))
	   {

	      helper.captureNetworkLogFailures(driver,testContext);
	   }



	   helper.addTestStatusToWordDoc(testContext);

	   // clear up everything and close the browser.
	   driver.manage().deleteAllCookies();
	   driver.close();
	   driver.quit();


	}

		
}
