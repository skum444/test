package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.AdditionalIncomePage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import org.mockito.Mockito;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class AdditionalIncomeStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    AdditionalIncomePage additionalIncomePage;
    private HelperFunctions helper = new HelperFunctions();

    public AdditionalIncomeStepDefinitions(TestContext context) {
        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        additionalIncomePage = testContext.getPageObjectManager().getAdditionalIncomePage(context);
    }

    @Then("^the Additional Income page is displayed$")
    public void the_Additional_Income_page_is_displayed() throws Throwable {
        additionalIncomePage.verifyAdditionalIncomeIsDisplayed();
    }

    @Then("^the user selects \"([^\"]*)\" to add additonal income$")
    public void the_user_selects_to_add_additonal_income(String arg1) throws Throwable {
        additionalIncomePage.firstKP();

    }

    @Then("^the user adds sources of income$")
    public void the_user_adds_sources_of_income() throws Throwable {
        additionalIncomePage.verifySourceOfIncomeIsDisplayed();
        additionalIncomePage.verifyBuyToLetIncomeIsDisplayed();
        additionalIncomePage.selectDocumentValueCheckbox();

    }

    @Then("^the user clicks the Next button$")
    public void the_user_clicks_the_Next_button() throws Throwable {
       additionalIncomePage.kpNextButton();

    }

    @Then("^the user clicks the Continue button$")
     public void the_user_clicks_the_Continue_button() throws Throwable {
       additionalIncomePage.kpContinueButton();

    }

    @Then("^the user selects next\"([^\"]*)\" to add additional income$")
    public void the_user_selects_next_to_add_additional_income(String arg1) throws Throwable {
      additionalIncomePage.secondKP();
    }


}
