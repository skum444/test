package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.DonePage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DonePageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	DonePage donePage;
	private HelperFunctions helper = new HelperFunctions();

	public DonePageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		donePage = testContext.getPageObjectManager().getDonePage(context);

	}
	/*

	@Then("^the Done page is displayed$")
	public void the_Done_page_is_displayed() throws Throwable {

		donePage.verifyDonePageIsDisplayed();
	}

	@When("^user clicks the continue button on the done page$")
	public void user_clicks_the_continue_button_on_the_done_page() throws Throwable {

		donePage.Done_ClickHome();
	}

	@Then("^verify FI required page is displayed$")
	public void verify_FI_required_page_is_displayed() throws Throwable {
		donePage.verifyFIRequiredMessageDisplayed();
	}

	@Then("^user is redirected to the homepage$")
	public void user_is_redirected_to_the_homepage() throws Throwable {

		String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
		
		helper.addfullScreenCaptureToExtentReport(driver, testContext);

		try {

			if (brand.toLowerCase().contains("RBS") && !driver.getCurrentUrl().contains("rbs"))
				helper.failTest("Expecting RBS homepage", "Expecting RBS homepage to be displayed", "", driver,testContext);

			if (brand.toLowerCase().contains("NWB") && !driver.getCurrentUrl().contains("natwest"))
				helper.failTest("Expecting Natwest homepage", "Expecting Natwest homepage to be displayed", "", driver,testContext);

		} catch (Exception e) {
			testContext.scenarioContext.setContext(TestData.Status, "Fail");
			helper.failTest("Expecting Natwest homepage ", "Expecting Natwest homepage ", e.getMessage(), driver,testContext);
		}

	}
	
	*/
}