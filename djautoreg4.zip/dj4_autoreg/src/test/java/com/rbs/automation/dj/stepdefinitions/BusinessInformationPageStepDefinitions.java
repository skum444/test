package com.rbs.automation.dj.stepdefinitions;

import java.util.Collection;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.BusinessInformationPage;
import com.rbs.automation.dj.testcontext.TestContext;
import com.sun.tools.javac.util.List;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;

public class BusinessInformationPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	BusinessInformationPage businessInformationPage;
	

	private HelperFunctions helper = new HelperFunctions();

	public BusinessInformationPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		businessInformationPage = testContext.getPageObjectManager().getBusinessInfoPage(context);
		

	}
	
	

@When("^clicks saves updates button on the business inofrmation$")
public void clicks_saves_updates_button_on_the_business_inofrmation() throws Throwable {
   
	businessInformationPage.saveBusinessDetails();
}

@Then("^verify the \"([^\"]*)\" error message is displayed$")
public void verify_the_is_displayed(String errorMessage) throws Throwable {
	businessInformationPage.verifyErrorMessageIsDisplayed(errorMessage);
}

	
	
	@Then("^no sub-sector list is displayed$")
	public void no_sub_sector_list_is_displayed() throws Throwable {
	   
		businessInformationPage.verifySubSectorNotDisplayed();
		
	}

	@Then("^the Company sector dropdown should display \"([^\"]*)\" option at the top$")
	public void the_Company_sector_dropdown_should_display_option_at_the_top(String firstOption) throws Throwable {
	   
		businessInformationPage.verifySectorFirstOption(firstOption);
	}
	
	@Then("^I should see sub-sector list defaulted with the following values$")
	public void i_should_see_sub_sector_list_defaulted_with_the_following_values(DataTable dtSubSector) throws Throwable {
		  java.util.List<Map<String, String>> subSectorList = dtSubSector.asMaps(String.class, String.class);
		    
		  businessInformationPage.verifySubSectorOptions(subSectorList);
		
	}

	@Then("^the dropdown should display \"([^\"]*)\" option at the top and \"([^\"]*)\" option at the bottom$")
	public void the_dropdown_should_display_option_at_the_top_and_option_at_the_bottom(String firstOption, String lastOption) throws Throwable {
	    
		businessInformationPage.verifySubSectorFirstandLatOptions(firstOption,lastOption);
	}
	

	
	@Then("^in 'Your business information' section \"([^\"]*)\" is displayed$")
	public void in_Your_business_information_section_is_displayed(String sector) throws Throwable {
		
		
		businessInformationPage.confirmSectorIsDisplayed(sector);
		
	}

	@Then("^\"([^\"]*)\" is displayed if applicable$")
	public void is_displayed_if_applicable(String subSector) throws Throwable {
		
		businessInformationPage.confirmSubSectorIsDisplayed(subSector);
	}
	
	
	
	@Then("^the 'Your business information' page is displayed$")
	public void the_Your_business_information_page_is_displayed() throws Throwable {
	   
		businessInformationPage.VerifyBusinessInfoPageIsDisplayed();
	}

	@When("^the user clicks the edit link$")
	public void the_user_clicks_the_edit_link() throws Throwable {
	    
		businessInformationPage.clickEditBusinessDetailsLink();
	}

	@When("^the user selects \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_selects_and(String sector, String subSector) throws Throwable {
	    
		businessInformationPage.selectCompanySector(sector);
		businessInformationPage.selectCompanySubSector(subSector);
		
	}

	@When("^the user selects \"([^\"]*)\" option for sub sector$")
	public void the_user_selects_option(String subSector) throws Throwable {
		businessInformationPage.selectCompanySubSector(subSector);
	}
	
	
	@When("^user selects \"([^\"]*)\" from the Company Sector drop down$")
	public void user_selects_from_the_Company_Sector_drop_down(String companySector) throws Throwable {
		businessInformationPage.selectCompanySector(companySector);
	}

	@When("^the user selects the Confirm and continue button$")
	public void the_user_selects_the_Confirm_and_Continue_button() throws Throwable {
	    
		businessInformationPage.confirmAndContinue();
	}
	
	@Then("^enter lease term \"([^\"]*)\"$")
	public void enter_lease_term(String leaseTerm) throws Throwable {
	 
		businessInformationPage.enterLeaseTerm(leaseTerm);
		
	}
	
	@Then("^verify that the \"([^\"]*)\" is displayed$")
	public void verify_that_the_is_displayed(String tradingDate) throws Throwable {
	    
		businessInformationPage.verifyTradingDate(tradingDate);
	}

	
	@Then("^business information has been updated$")
	public void business_information_has_been_updated() throws Throwable {
	
		businessInformationPage.verifyBusinessInformationHasBeenSaved();
	}

	@Then("^business information has not been updated$")
	public void business_information_hasnot_been_updated() throws Throwable {
	  
		businessInformationPage.verifyBusinessInformationHasNotBeenSaved();
	}



	
	@When("^user clicks edit business information link$")
	public void user_clicks_edit_business_information_link() throws Throwable {
	    
		businessInformationPage.clickEditBusinessDetailsLink();
	}
	
	
	
	@When("^the user answers \"([^\"]*)\" to the business active in consumer litigation question$")
	public void the_user_answers_to_the_business_active_in_consumer_litigation_question(String answer) throws Throwable {
	   
		businessInformationPage.isThisActiveInConsumerLitigation(answer);
	}

	@When("^the user answers \"([^\"]*)\" to the proffessional cricket-rugby-football club question$")
	public void the_user_answers_to_the_proffessional_cricket_rugby_football_club_question(String answer) throws Throwable {
	    
		businessInformationPage.isThisAProffessionalClub(answer);
	}
	
	
	@Then("^the following message is displayed \"([^\"]*)\"$")
	public void the_following_message_is_displayed(String staticMessage) throws Throwable {
	   
		businessInformationPage.verifyBIStaticInfo(staticMessage);
	}

	@When("^the user clicks the how we use your information link$")
	public void the_user_clicks_the_how_we_use_your_information_link() throws Throwable {
	   
		businessInformationPage.clickTheHowWeuseUseYourInfoLink();
		
	}

	@Then("^the How we use your info pdf is displayed$")
	public void the_How_we_use_your_info_pdf_is_displayed() throws Throwable {
	    
		businessInformationPage.verifyTheBIInformationPageIsDisplayed();
	}
	
	
	@When("^user edits business information$")
	public void user_edits_business_information() throws Throwable {
	  
		businessInformationPage.editBusinessDetails("PetHeaven", "74858687", "Leisure", "O&G Pipelines", "March", "2007");
	}
	
	
	
	@When("^user updates business address$")
	public void user_updates_business_address(DataTable BIZaddr) throws Throwable {
		  java.util.List<Map<String, String>> BIZaddrdet = BIZaddr.asMaps(String.class, String.class);
		businessInformationPage.updateAddress(BIZaddrdet);
	}

	
	
	
	
	@When("^user edits business information with the below inputs$")
	public void user_edits_business_information_with_the_below_inputs(DataTable BIZedit) throws Throwable {
		java.util.List<Map<String, String>> BIZeditdet = BIZedit.asMaps(String.class, String.class);
		businessInformationPage.getBIZeditINfoList(BIZeditdet);
	}
	
	
	
	@When("^user saves the business information updates$")
	public void user_saves_the_business_information_updates() throws Throwable {
	    
		businessInformationPage.saveBusinessDetails();
	}

	@When("^user cancels the business information updates$")
	public void user_cancels_the_business_information_updates() throws Throwable {
		
		businessInformationPage.cancelEditBusinessDetails();
	}
	

	
	@When("^user updates the business information details$")
	public void user_updates_the_business_information_details() throws Throwable {
		businessInformationPage.getValuesFromExcelAndupdateMoreInfoAboutBusiness();
	
	}
	
	@When("^user updates the business information details with the below inputs$")
	public void user_updates_the_business_information_details_with_the_below_inputs(DataTable BIZInfo ) throws Throwable {
		   java.util.List<Map<String, String>> BIZInfodet = BIZInfo.asMaps(String.class, String.class);
		businessInformationPage.getBIZINfoList(BIZInfodet);
	
	}

	
	
	@Then("^the user verifies the manage risks link and popup window$")
	public void the_user_verifies_the_manage_risks_link_and_popup_window() throws Throwable {
	    
		businessInformationPage.verifyTheManageRisksLink();
		
	}
	
	@Then("^the validation message \"([^\"]*)\" is displayed under the \"([^\"]*)\"$")
	public void the_validation_message_is_displayed_under_the(String validationMessage, String fieldText) throws Throwable {
	   
		businessInformationPage.verifyValidationMessagesExistForMissingBusinessInformation(validationMessage, fieldText);
	}
	
	@Then("^verify that postcode look up, house number and country fields are not displayed$")
	public void verify_that_postcode_look_up_house_number_and_country_fields_are_not_displayed() throws Throwable {
	    
		businessInformationPage.verifyAddressfieldsNotDisplayed();
	}
	
	@When("^user edits \"([^\"]*)\" field with \"([^\"]*)\"$")
	public void edit_BI_field_with_values(String fieldName, String fieldValue) throws Throwable {
	    
		businessInformationPage.editFieldName(fieldName,fieldValue);
	}
	


	

}
