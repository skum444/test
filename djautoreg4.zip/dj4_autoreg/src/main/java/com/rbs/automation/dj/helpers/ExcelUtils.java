package com.rbs.automation.dj.helpers;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.joda.time.DateTime;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.Logger;
import com.rbs.automation.dj.managers.FileReaderManager;


public class ExcelUtils {

	static PrintWriter out = null;
	public static String DJ1_WB;
	public static int zd;
	public static int ddb;
	public static int Ed;
	public static int result;
	public static int resultinput;
	public static int testdata;
	public static int DatafromDB;
	public static int zambezicustomerdata;
	public static int DatafromcoreDB;
	public static int resultoutput;
	//private static ReporterA reporter;

	

	private static void createExcelSheet(String sWorkBook, String sSheetName, String refernum) {

		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		try {
			deleteExcelSheet(sWorkBook, sSheetName);
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			sheet = workbook.createSheet(sSheetName);
			row = sheet.createRow(0);

			HSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.YELLOW.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			HSSFFont font = workbook.createFont();
			font.setColor(HSSFColor.BLACK.index);
			style.setFont(font);

			Cell cell = row.createCell(0);
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue("Label Names for Application ID:" + refernum);
			cell.setCellStyle(style);

			Cell cell1 = row.createCell(1);
			cell1.setCellType(cell.CELL_TYPE_STRING);
			cell1.setCellValue("Data from Zambezi");
			cell1.setCellStyle(style);

			Cell cell2 = row.createCell(2);
			cell2.setCellType(cell.CELL_TYPE_STRING);
			cell2.setCellValue("Data from DB");
			cell2.setCellStyle(style);

			Cell cell3 = row.createCell(3);
			cell3.setCellType(cell.CELL_TYPE_STRING);
			cell3.setCellValue("Data from TestData");
			cell3.setCellStyle(style);

			Cell cell4 = row.createCell(4);
			cell4.setCellType(cell.CELL_TYPE_STRING);
			cell4.setCellValue("Comparison Result");
			cell4.setCellStyle(style);

			FileOutputStream opfile1 = new FileOutputStream(new File(sWorkBook));
			workbook.write(opfile1);

			opfile1.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private static void createExcelSheetstatus(String sWorkBook, String sSheetName) {

		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		try {
			deleteExcelSheet(sWorkBook, sSheetName);
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			sheet = workbook.createSheet(sSheetName);
			row = sheet.createRow(0);

			HSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.YELLOW.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			HSSFFont font = workbook.createFont();
			font.setColor(HSSFColor.BLACK.index);
			style.setFont(font);

			Cell cell = row.createCell(0);
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue("Application ID");
			cell.setCellStyle(style);

			Cell cell1 = row.createCell(1);
			cell1.setCellType(cell.CELL_TYPE_STRING);
			cell1.setCellValue("Status");
			cell1.setCellStyle(style);

			Cell cell2 = row.createCell(2);
			cell2.setCellType(cell.CELL_TYPE_STRING);
			cell2.setCellValue("Previous Status");
			cell2.setCellStyle(style);

			Cell cell3 = row.createCell(3);
			cell3.setCellType(cell.CELL_TYPE_STRING);
			cell3.setCellValue("Channel");
			cell3.setCellStyle(style);

			/*
			 * Cell cell4 = row.createCell(4);
			 * cell4.setCellType(cell.CELL_TYPE_STRING); cell4.setCellValue(
			 * "Comparison Result"); cell4.setCellStyle(style);
			 */

			FileOutputStream opfile1 = new FileOutputStream(new File(sWorkBook));
			workbook.write(opfile1);

			opfile1.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// credit

	private static void createExcelSheetBNF(String sWorkBook, String sSheetName) {

		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		try {
			deleteExcelSheet(sWorkBook, sSheetName);
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			sheet = workbook.createSheet(sSheetName);
			row = sheet.createRow(0);

			HSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.YELLOW.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			HSSFFont font = workbook.createFont();
			font.setColor(HSSFColor.BLACK.index);
			style.setFont(font);

			Cell cell = row.createCell(0);
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue("Field Name");
			cell.setCellStyle(style);

			Cell cell1 = row.createCell(1);
			cell1.setCellType(cell.CELL_TYPE_STRING);
			cell1.setCellValue("Data from inputter");
			cell1.setCellStyle(style);

			Cell cell2 = row.createCell(2);
			cell2.setCellType(cell.CELL_TYPE_STRING);
			cell2.setCellValue("Data from Reviewer");
			cell2.setCellStyle(style);

			Cell cell3 = row.createCell(3);
			cell3.setCellType(cell.CELL_TYPE_STRING);
			cell3.setCellValue("Data from Notification screen");
			cell3.setCellStyle(style);

			Cell cell4 = row.createCell(4);
			cell4.setCellType(cell.CELL_TYPE_STRING);
			cell4.setCellValue("Pre populated Values");
			cell4.setCellStyle(style);

			Cell cell5 = row.createCell(5);
			cell5.setCellType(cell.CELL_TYPE_STRING);
			cell5.setCellValue("LND_BNF_CORE_OD_TB");
			cell5.setCellStyle(style);

			Cell cell6 = row.createCell(6);
			cell6.setCellType(cell.CELL_TYPE_STRING);
			cell6.setCellValue("LND_BNF_CORE_COMMS_TB");
			cell6.setCellStyle(style);

			Cell cell7 = row.createCell(7);
			cell7.setCellType(cell.CELL_TYPE_STRING);
			cell7.setCellValue("LND_BNF_CORED_DG_TB");
			cell7.setCellStyle(style);

			Cell cell8 = row.createCell(8);
			cell8.setCellType(cell.CELL_TYPE_STRING);
			cell8.setCellValue("Result");
			cell8.setCellStyle(style);

			FileOutputStream opfile1 = new FileOutputStream(new File(sWorkBook));
			workbook.write(opfile1);

			opfile1.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void setTestDataRow_BB_Write_highilght(String sSheetName, String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AppSummary.xls";

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcelhighlight(sMasterTDWorkbook, sSheetName, value, rownum, colnum);

	}

	private static void WriteToExcelhighlight(String sWorkBook, String sSheetName, String respval, int rownum,
			int colnum) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;

		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sSheetName);
			HSSFRow row;
			if (colnum == 0) {
				row = sheet.createRow(rownum);
			} else {
				row = sheet.getRow(rownum);
			}

			Cell cell = row.createCell(colnum);

			cell.setCellType(cell.CELL_TYPE_STRING);
			// System.out.println(respval);
			cell.setCellValue(respval);
			HSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.YELLOW.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			HSSFFont font = workbook.createFont();
			font.setColor(HSSFColor.BROWN.index);
			style.setFont(font);
			cell.setCellStyle(style);

			FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
			workbook.write(opfile);

			opfile.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	

	private static void codetoComparetwocolns(String sWorkBook, String sSheetName, int colno1, int colno2,
			int resultcolno) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;

		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFRow row = null;
			HSSFSheet sheet = null;
			int sheetRows1 = 0;
			int rowCols1 = 0;

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();

			for (int i = 3; i < sheetRows; i++) {
				Cell cell = null;

				row = sheet.getRow(i);
				String colnovalue1 = row.getCell(colno1).getStringCellValue();
				String colnovalue2 = row.getCell(colno2).getStringCellValue();
				try {

					if (colnovalue1.equalsIgnoreCase(colnovalue2)) {
						cell = row.createCell(resultcolno);
						cell.setCellType(cell.CELL_TYPE_STRING);

						cell.setCellValue("Pass");
					} else {

						cell = row.createCell(resultcolno);
						cell.setCellType(cell.CELL_TYPE_STRING);

						cell.setCellValue("Fail");

					}

				} catch (Exception e) {
					cell = row.createCell(resultcolno);
					cell.setCellType(cell.CELL_TYPE_STRING);
					cell.setCellValue("Fail");
					System.out.println(e);
				}

				FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
				workbook.write(opfile);

				opfile.close();

			}

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	private static void codetoCompare(String sWorkBook, String sSheetName) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;

		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFRow row = null;
			HSSFSheet sheet = null;
			int sheetRows1 = 0;
			int rowCols1 = 0;

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();

			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);
				String headerval = row.getCell(0).getStringCellValue();

				if (!headerval.contains("Section Header:")) {
					String BPMval = row.getCell(1).getStringCellValue();
					String DBval = row.getCell(2).getStringCellValue();

					if (BPMval.equalsIgnoreCase(DBval)) {
						Cell cell = row.createCell(3);
						cell.setCellType(cell.CELL_TYPE_STRING);

						cell.setCellValue("Pass");
					} else {
						if (BPMval.equals(" ") || BPMval.equals("")) {
							if (DBval.equals("")) {
								Cell cell = row.createCell(3);
								cell.setCellType(cell.CELL_TYPE_STRING);

								cell.setCellValue("Pass");
							} else {
								Cell cell = row.createCell(3);
								cell.setCellType(cell.CELL_TYPE_STRING);

								cell.setCellValue("Fail");
							}

						} else {
							Cell cell = row.createCell(3);
							cell.setCellType(cell.CELL_TYPE_STRING);

							cell.setCellValue("Fail");
						}
					}

					FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
					workbook.write(opfile);

					opfile.close();

				}
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}



	private static void deleteExcelSheet(String sWorkBook, String sSheetName) {
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;
		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			int index = 0;

			HSSFSheet sheetold = workbook.getSheet(sSheetName);
			if (sheetold != null) {
				index = workbook.getSheetIndex(sheetold);
				workbook.removeSheetAt(index);
				FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
				workbook.write(opfile);
				opfile.close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	

	


	

	

	public static void closeReporter() {
		out.close();
	}

	public static Map<String, String> getTestDataRow(String sSheetName, String sTestName, int iRow) throws Exception {
		String sMasterTDWorkbook = GenericUtils.getProperty("masterTestDataWorkbook");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(sMasterTDWorkbook, sSheetName, sTestName);

		return tdRows.get(iRow);
	}

	

	public static Map<String, String> getTestDataRow_DJ1(String sSheetName, String sTestName, String region) throws Exception {
		
		workbook(region);

		// load test data sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(DJ1_WB, sSheetName, sTestName);

		return tdRows.get(0);
	}

	public static List<Map<String, String>> getProductInformation_DJ1(String sSheetName, String sTestName, String region) throws Exception {
		//String region = StepLib.Reg_Brand;
		//String region = "RBS";
		workbook(region);

		// load test data sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(DJ1_WB, sSheetName, sTestName);

		
		return tdRows;
	}
	
	
	public static void workbook(String Reg) {
		
		
		// Set the report path based on generated testName
		Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
		String excelDataWorkbookName = prop.getProperty("ExcelDataSheet");
		
		
		if (Reg.contains("NWB")) {
		
				DJ1_WB = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + excelDataWorkbookName;	
		} else if (Reg.contains("RBS")) {
			
				DJ1_WB = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + excelDataWorkbookName;
				
		}else if (Reg.contains("dataValidation")) {
					
				String excelDataValidationWorkBookName = prop.getProperty("excelDataValidationWorkBookName");
				DJ1_WB = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + excelDataValidationWorkBookName;	
					
				
		}
	}

	
	public static void setTestDataRow_BB_Write(String sSheetName, String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AssistedJourney.xls";

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcel(sMasterTDWorkbook, sSheetName, value, rownum, colnum);

	}

	
	public static void setTestDataRow_BB_Write_AJ(String sSheetName, String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AppSummary.xls";

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcel(sMasterTDWorkbook, sSheetName, value, rownum, colnum);

	}

	public static void setTestDataRow_BB_Write_appid(String sSheetName, String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AppDetails.xls";

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcel(sMasterTDWorkbook, sSheetName, value, rownum, colnum);

	}
	
	
	public static void WriteApplicationIDToDataSheet(String sSheetName, String sTestName, String applicationID, String region) {
		
		
		workbook(region);


		try {
			FileInputStream file = new FileInputStream(new File(DJ1_WB));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sSheetName);
			HSSFRow row;
			
			int currentRow = sheet.getPhysicalNumberOfRows();

			// Create a new row
			row = sheet.createRow(currentRow);
			
			// Add test name
			Cell cell = row.createCell(0);
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue(sTestName);
			
			// Add Application ID
			Cell cell2 = row.createCell(1);
			cell2.setCellType(cell2.CELL_TYPE_STRING);
			cell2.setCellValue(applicationID);
			
			
			// Add DateTimeStamp
			Cell cell3 = row.createCell(2);
			cell3.setCellType(cell3.CELL_TYPE_STRING);
			cell3.setCellValue(DateTime.now().toString());

			FileOutputStream opfile = new FileOutputStream(new File(DJ1_WB));
			workbook.write(opfile);

			opfile.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	
public static void WriteReasonTextToDataSheet(String testRunName, String sSheetName, String testName, String reasonText, String DBID,  String BIN,String region, String segment, String appId, String appStatus) {
										
		workbook("dataValidation");
		
	

		try {
			FileInputStream file = new FileInputStream(new File(DJ1_WB));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sSheetName);
			HSSFRow row;
			
			int currentRow = sheet.getPhysicalNumberOfRows();

			// Create a new row
			row = sheet.createRow(currentRow);
			
			
			
			
			// Add TestName
			Cell cell8 = row.createCell(0);
			cell8.setCellType(cell8.CELL_TYPE_STRING);
			cell8.setCellValue(testName);
			
			// Add DBID
			Cell cell = row.createCell(1);
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue(DBID);
			
			// Add BIN
			Cell cell1 = row.createCell(2);
			cell1.setCellType(cell1.CELL_TYPE_STRING);
			cell1.setCellValue(BIN);
			
			// Add brand
			Cell cell2 = row.createCell(3);
			cell2.setCellType(cell2.CELL_TYPE_STRING);
			cell2.setCellValue(region);
			
			// Add Segment
			Cell cell3 = row.createCell(4);
			cell3.setCellType(cell3.CELL_TYPE_STRING);
			cell3.setCellValue(segment);
			
			// Add Reason Text
			Cell cell4 = row.createCell(5);
			cell4.setCellType(cell4.CELL_TYPE_STRING);
			cell4.setCellValue(reasonText);
			
			// Add application id
			Cell cell5 = row.createCell(6);
			cell5.setCellType(cell5.CELL_TYPE_STRING);
			cell5.setCellValue(appId);
			
			// Add application status
			Cell cell6 = row.createCell(7);
			cell6.setCellType(cell6.CELL_TYPE_STRING);
			cell6.setCellValue(appStatus);
			
			// Add DateTimeStamp
			Cell cell7 = row.createCell(8);
			cell7.setCellType(cell7.CELL_TYPE_STRING);
			cell7.setCellValue(DateTime.now().toString());
			
			// Add Test run name
			Cell cell9 = row.createCell(9);
			cell9.setCellType(cell9.CELL_TYPE_STRING);
			cell9.setCellValue(testRunName);
			
			
			
			
			

			FileOutputStream opfile = new FileOutputStream(new File(DJ1_WB));
			workbook.write(opfile);

			opfile.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private static void WriteToExcel(String sWorkBook, String sSheetName, String respval, int rownum, int colnum) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;

		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sSheetName);
			HSSFRow row;
			if (colnum == 0) {
				row = sheet.createRow(rownum);
			} else {
				row = sheet.getRow(rownum);
			}

			Cell cell = row.createCell(colnum);

			cell.setCellType(cell.CELL_TYPE_STRING);

			cell.setCellValue(respval);

			FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
			workbook.write(opfile);

			opfile.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	
	
	
	private static ArrayList<Map<String, String>> getMapFromExcel(String sWorkBook, String sSheetName, String sTCName) throws Exception {
		
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);

			//System.out.println("Number of rows being read: " + sheetRows);
			row = sheet.getRow(0);

			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}

			rowCols = colNames.size();

			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);

				//if (row.getCell(0).getStringCellValue().equalsIgnoreCase(sTCName)
				//&& row.getCell(1).getStringCellValue().equalsIgnoreCase("Y"))
				
				if (row.getCell(0).getStringCellValue().equalsIgnoreCase(sTCName)) {

					rowMap = new LinkedHashMap<String, String>(rowCols);

					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						String value ="";
						
						
						//SET AS STRING TYPE
						Cell cell = row.getCell(c);
						//System.out.println("cell value: " + cell);
						
						if(cell != null)
						{
						
							cell.setCellType(Cell.CELL_TYPE_STRING); 
							if(cell.getStringCellValue().isEmpty())
								value = "";
							else
								value = "" + cell.getStringCellValue();
						
						}else{
							
							value = "";
						}
						
						rowMap.put(key, value);
					}
					
					

					mapArray.add(rowMap);

				}

			}
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			
			Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
			
			
			
		} catch (IOException e) {
			
			Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
			
			
		}
		return mapArray;
	}

	


public static void updateFromExcel(String sSheetName, String sTCName, String columnToUpdate, String value) throws Exception {
		
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;


		try {
			FileInputStream file = new FileInputStream(new File(DJ1_WB));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
		
			int ColumnUpdatePosition = 0;
			
			row = sheet.getRow(0);
			
			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				
		if(row.getCell(i).getStringCellValue().contains(columnToUpdate))
					ColumnUpdatePosition = i;
			}


			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);

				
				if (row.getCell(0).getStringCellValue().equalsIgnoreCase(sTCName)) {

					if(row.getCell(ColumnUpdatePosition) == null)
					{
					Cell cell= row.createCell(ColumnUpdatePosition);
					cell.setCellType(cell.CELL_TYPE_STRING);
					cell.setCellValue(value);
					
					}else{
						Cell cell = row.getCell(ColumnUpdatePosition);
						cell.setCellValue(value);
					}
					
					FileOutputStream opfile = new FileOutputStream(new File(DJ1_WB));
					workbook.write(opfile);
				
											
					}

				}
			
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			
			//Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
		}
	}



}
