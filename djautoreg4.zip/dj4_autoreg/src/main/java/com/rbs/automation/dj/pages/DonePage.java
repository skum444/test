package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.helpers.ExcelUtils;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.testcontext.TestContext;

public class DonePage {

	private WebDriver driver;
	private String sTestDataSheetName = "Done";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();


	// initialise the page elements when the class is instantiated
	public DonePage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	
	@FindBy(how = How.XPATH, using = "//span[@class='ApplicationSubmittedDJ_appID_1xbg']")
	public WebElement textApplicationID;
	
	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Thanks.')]")
	public WebElement textDone;
	
	
	@FindBy(how = How.XPATH, using = "//h2/span")
	public WebElement textFinancialInfoRequired;
	
	
	public void Done_ClickHome() throws Exception {
		try {
			
		
			helper.clickAnyButtonInDigitalJourney("Close this page", driver,testContext);
			
			
			
		} catch (Exception e) {
			
			helper.failTest("Done Page ", "Could not close page", e.getMessage(), driver,testContext);
		}

	}
	
	
	
	public void verifyFIRequiredMessageDisplayed() throws Exception {
		
		
		try {
			
			if (!(textFinancialInfoRequired.getText().contains("We need your financials"))) 
			
				helper.failTest("Done Page ", "We need your financials message not displayed", "", driver,testContext);
			
		} catch (Exception e) {
						
			helper.failTest("Done Page ", "We need your financials message not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	

	public void verifyDonePageIsDisplayed() throws Exception {
		
		helper.initialisePage(driver, testContext, "Done");
		
		String testName= (String)testContext.scenarioContext.getContext(TestData.TestName);
		String brand = (String)testContext.scenarioContext.getContext(TestData.Brand);
		String appID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
		
		if(driver.getPageSource().contains("We need your financials"))
			ExcelUtils.updateFromExcel(sTestDataSheetName, testName, "DonePage","FI");
		else
			ExcelUtils.updateFromExcel(sTestDataSheetName, testName, "DonePage","Thankyou");	
				
		// Write application ID to the data sheet
		helper.writeApplicationID(sTestDataSheetName, appID, testContext, driver);		
		
		try {
						
			if (!(textDone.getText().contains("Thanks."))) {
				helper.failTest("Thankyou page ", "Thankyou page not displayed", "", driver,testContext);
			}
		} catch (Exception e) {
			
			
			helper.failTest("Thankyou page", "Thankyou page not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	
	
}
