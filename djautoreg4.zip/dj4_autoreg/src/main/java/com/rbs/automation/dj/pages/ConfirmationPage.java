package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.testcontext.TestContext;

public class ConfirmationPage {

	private WebDriver driver;
	private String sTestDataSheetName = "Confirmation";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();


	// initialise the page elements when the class is instantiated
	public ConfirmationPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	
	@FindBy(how = How.XPATH, using = "//h1[contains(text(), 'Confirm')]")
	public WebElement textHeaderTxt;
	
	@FindBy(how = How.XPATH, using = "(//input[@name='overseasDependant'])[2]")
	public WebElement radioBtnConsent;
	
	
	public void Confirmation_ClickContinue() throws Exception {
		try {
		
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,300)");
			
			Thread.sleep(2000);			
			
			WebElement radioBtnTertiaryQ1 = driver.findElement(
					By.xpath("//label[@class ='zb-input-label-name' and contains(text(), 'No')]"));

			radioBtnTertiaryQ1.click();
			
			
			
		   helper.clickAnyButtonInDigitalJourney("Confirm and submit", driver,testContext);
		   
		   Thread.sleep(2000);
			
			
			// close the questionaire pop window
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//h1[text() = 'We need your feedback']")).size()!=0)
			{
				driver.findElement(By.xpath("//span[text() = 'No']")).click();
				
			}
	
			
		} catch (Exception e) {
			
			helper.failTest("Confimation Page ", "Confimation Page  not displayed", e.getMessage(), driver,testContext);
		}

	}

	public void verifyLendingConfirmationPage() throws Exception {
		
		helper.initialisePage(driver, testContext, "Confirmation");
		
		try {
			String text = textHeaderTxt.getText();
			
			if (!(text.contains("Confirm"))) {
				helper.failTest("Confimation Page ", "Confimation Page  not displayed", "", driver,testContext);
			}
		
			
		} catch (Exception e) {
			
			helper.failTest("Confimation Page ", "Confimation Page  not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	
}
