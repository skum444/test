package com.rbs.automation.dj.managers;
 
import com.rbs.automation.dj.pages.*;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.pages.BusinessInformationPage;
import com.rbs.automation.dj.pages.KeyPrinciplesPage;
import com.rbs.automation.dj.pages.IneligibleLandingPage;



public class PageObjectManager {
 
	private WebDriver driver;
	
	private TestContext  testContext;
 
	private HomePage homePage;
 
	private LoginPage loginPage;
	
	private LoginPage2 loginPage2;
	
	private WelcomePage landingPage;
	
	private NeedsPage needsPage;
	
	private QuotesPage quotesPage;
	
	private SelectedProductPage selectedProductPage;
	
	private AccountDetailsPage accountDetailsPage;
	
	private ConfirmationPage confirmationPage;
	
	private DonePage donePage;
	
	private CreditCheckPage creditCheckPage;
	
	private requestCallBackPage callBackRequestPage;
	
	private OneConnectJourneyPages oneConnectJourneyPages;
	
	private BPMLoginPage bpmLoginPage;
	
	private BPMMyWorksPage bpmWorksTabPage;
	
	private BPMApplicationSummaryPage bpmApplicationSummaryPage;
	
	private BPMLendingDigitalSearchPage bpmLendingDigitalSearchPage;
	
	private BPMMyWorksPage bpmMyWorksPage;
	
	private BusinessInformationPage businessInformationPage;
	
	private IneligibleLandingPage ineligibleLandingPage;

	private KeyPrinciplesPage keyPrinciplesPage;

	private ThankYouPage thankYouPage;

    private CancelApplicationPage cancelApplicationPage;

    private ApplicationCancelledPage applicationCancelledPage;

    private AdditionalIncomePage additionalIncomePage;

    private FinancialsPage financialsPage;
    
    private PersonalisedQuotePage personalisedQuotePage;
    
    private OutcomePage outcomePage;

 	public PageObjectManager(WebDriver driver) {

 
		this.driver = driver;
	
	}
 
	
	
	
	
	public HomePage getHomePage(TestContext testContext){
 
		return (homePage == null) ? homePage = new HomePage(driver,testContext) : homePage;
 
	}
	
	public OutcomePage getOutcomePage(TestContext testContext){
		 
		return (outcomePage == null) ? outcomePage = new OutcomePage(driver,testContext) : outcomePage;
 
	}
	
	
	
	public LoginPage getLoginPage(TestContext testContext){
		 
		return (loginPage == null) ? loginPage = new LoginPage(driver,testContext) : loginPage;
 
	}
	
	public LoginPage2 getLoginPage2(TestContext testContext){
		 
		return (loginPage2 == null) ? loginPage2 = new LoginPage2(driver,testContext) : loginPage2;
 
	}
	
	
	public WelcomePage getLandingPage(TestContext testContext){
		 
		return (landingPage == null) ? landingPage = new WelcomePage(driver,testContext) : landingPage;
 
	}
	
	public IneligibleLandingPage getIneligibleLandingPage(TestContext testContext){
		 
		return (ineligibleLandingPage == null) ? ineligibleLandingPage = new IneligibleLandingPage(driver,testContext) : ineligibleLandingPage;
 
	}
	
	public KeyPrinciplesPage getKeyPrinciplesPage(TestContext testContext){
		 
		return (keyPrinciplesPage == null) ? keyPrinciplesPage = new KeyPrinciplesPage(driver,testContext) : keyPrinciplesPage;
 
	}
	
	
	
	
	public NeedsPage getNeedsPage(TestContext testContext){
		 
		return (needsPage == null) ? needsPage = new NeedsPage(driver,testContext) : needsPage;
 
	}
	
	
	
	

	public QuotesPage getQuotesPage(TestContext testContext){
		 
		return (quotesPage == null) ? quotesPage = new QuotesPage(driver,testContext) : quotesPage;
 
	}
	
	public BusinessInformationPage getBusinessInfoPage(TestContext testContext){
		 
		return (businessInformationPage == null) ? businessInformationPage = new BusinessInformationPage(driver,testContext) : businessInformationPage;
 
	}
	
	
	
	public AccountDetailsPage getAccountDetailsPage(TestContext testContext){
		 
		return (accountDetailsPage == null) ? accountDetailsPage = new AccountDetailsPage(driver,testContext) : accountDetailsPage;
 
	}
	

	public SelectedProductPage getSelectedProductPage(TestContext testContext){
		 
		return (selectedProductPage == null) ? selectedProductPage = new SelectedProductPage(driver,testContext) : selectedProductPage;
 
	}
	
	
	public ConfirmationPage getConfirmationPage(TestContext testContext){
		 
		return (confirmationPage == null) ? confirmationPage = new ConfirmationPage(driver,testContext) : confirmationPage;
 
	}
	
	public DonePage getDonePage(TestContext testContext){
		 
		return (donePage == null) ? donePage = new DonePage(driver,testContext) : donePage;
 
	}

	public ThankYouPage  getthankYouPage(TestContext testContext) {
		return (thankYouPage==null) ? thankYouPage = new ThankYouPage(driver,testContext) :thankYouPage;
	}

	public CancelApplicationPage getCancelApplicationPage(TestContext testContext) {
		return (cancelApplicationPage== null) ? cancelApplicationPage = new CancelApplicationPage(driver,testContext) : cancelApplicationPage;
	}

	public ApplicationCancelledPage getApplicationCancelledPage(TestContext testContext) {
		return (applicationCancelledPage == null) ? applicationCancelledPage = new ApplicationCancelledPage(driver,testContext) : applicationCancelledPage;
	}

	public AdditionalIncomePage getAdditionalIncomePage(TestContext testContext){
		return (additionalIncomePage == null) ? additionalIncomePage = new AdditionalIncomePage(driver,testContext) : additionalIncomePage;
	}

	public CreditCheckPage getCreditCheckPage(TestContext testContext){
		 
		return (creditCheckPage == null) ? creditCheckPage = new CreditCheckPage(driver,testContext) : creditCheckPage;
 
	}

	public requestCallBackPage getCallBackRequestPage(TestContext testContext){
		 
		return (callBackRequestPage == null) ? callBackRequestPage = new requestCallBackPage(driver,testContext) : callBackRequestPage;
 
	}
	
		
	
	public OneConnectJourneyPages getOneConnectJourneyPages(TestContext testContext){
		 
		return (oneConnectJourneyPages == null) ? oneConnectJourneyPages = new OneConnectJourneyPages(driver,testContext) : oneConnectJourneyPages;
 
	}
	
	public BPMLoginPage getBPMLoginPage(TestContext testContext){
		 
		return (bpmLoginPage == null) ? bpmLoginPage = new BPMLoginPage(driver,testContext) : bpmLoginPage;
 
	}
	
	
	public BPMMyWorksPage BPMWorksTabPage(TestContext testContext) {

		return (bpmWorksTabPage == null) ? bpmWorksTabPage = new BPMMyWorksPage(driver,testContext) : bpmWorksTabPage;		
		
	}


	public BPMApplicationSummaryPage BPMApplicationSummaryPage(TestContext testContext) {
		
		return (bpmApplicationSummaryPage == null) ? bpmApplicationSummaryPage = new BPMApplicationSummaryPage(driver,testContext) : bpmApplicationSummaryPage;
	}


	public BPMLendingDigitalSearchPage BPMLendingDigitalSearchPage(TestContext testContext) {
		
		return (bpmLendingDigitalSearchPage == null) ? bpmLendingDigitalSearchPage = new BPMLendingDigitalSearchPage(driver,testContext) : bpmLendingDigitalSearchPage;
	}


	public BPMMyWorksPage BPMMyWorksPage(TestContext testContext) {		
		
		return (bpmMyWorksPage == null) ? bpmMyWorksPage = new BPMMyWorksPage(driver,testContext) : bpmMyWorksPage;
	}

	public FinancialsPage getFinancialsPage(TestContext testContext){


		return (financialsPage == null) ? financialsPage = new FinancialsPage(driver,testContext) : financialsPage;

	}
	
	public PersonalisedQuotePage getPersonalisedQuotePage(TestContext testContext){


		return (personalisedQuotePage == null) ? personalisedQuotePage = new PersonalisedQuotePage(driver,testContext) : personalisedQuotePage;

	}
	
	
	
	


}