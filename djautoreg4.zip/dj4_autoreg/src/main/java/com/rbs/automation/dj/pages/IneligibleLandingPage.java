package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class IneligibleLandingPage {

    private WebDriver driver;
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    // initialise the page elements when the class is instantiated
    public IneligibleLandingPage(WebDriver driver, TestContext context) {

        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
        testContext.scenarioContext.setContext(TestData.PageName, "CallBackRequest");
    }

    @FindBy(how = How.NAME, using = "phoneNumber")
    public WebElement inputMobileNumber;

    @FindBy(how = How.NAME, using = "emailAddress")
    public WebElement inputEmail;

    @FindBy(how = How.XPATH, using = "//h1[contains(text() ,'chat about your borrowing needs')]")
    public WebElement txtHeader;

    @FindBy(how = How.XPATH, using = "//h1[contains(text() ,'Sorry - we need more information')]")
    public WebElement txtHeaderHS;


    @FindBy(how = How.XPATH, using = "//h1[contains(text() ,'Sorry - for business account holders only')]")
    public WebElement txtHeaderHSPersonalAccount;

    //@FindBy(how = How.CSS, using = ".IneligiblePageHS_header__CYUqk > div > p")
    @FindBy(how = How.CSS, using = "#inEligbileHSMessage p")
    public WebElement hsGenericInformationText;

    @FindBy(how = How.CSS, using = "#inEligbileHSMessage p")
    public WebElement hsSpecificInformationText;

    @FindBy(how = How.CSS, using = "#zb-lending-card p:nth-child(3)")
    public WebElement hsPersonalAccountInformationText;

    @FindBy(how = How.XPATH, using = "//div[contains(@class,'IneligiblePageAJ_header')]//p")
    public WebElement txtInfoAJSpecific;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ajGenericMessage\"]/div/p")
    public WebElement txtInfoAJGeneric;

    @FindBy(how = How.XPATH, using = "//a[text()='Help & support']")
    public WebElement linkHelpSupport;

    @FindBy(how = How.XPATH, using = "//div[text()='Request a callback']")
    public WebElement btnCallBackRequest;

    @FindBy(how = How.XPATH, using = "//a[text()='Request a callback']")
    public WebElement linkCallBackRequest;


    public void completeIneligibleForm(String email, String phone) throws Exception {
        try {

            helper.waitForLoading(driver);
            helper.waitForLoadingElementInvisibility(driver);

            driver.findElement(By.xpath("//input[1]")).click();

            driver.findElement(By.xpath("//div[@class='zb-dropdown-list zb-has-scrollbar']/ul/li/div[contains(text(),'44')]")).click();


            //Enter  phone
            helper.enterValue(inputMobileNumber, phone);

            Thread.sleep(1000);
            helper.enterValue(inputEmail, email);


            // Click continue on Submit Request
            helper.clickAnyButtonInDigitalJourney("Confirm", driver, testContext);
            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(2000);

            helper.clickAnyButtonInDigitalJourney("Exit", "2", driver, testContext);


        } catch (Exception e) {

            helper.failTest("Chat about your borrowing needs not displayed", "Chat about your borrowing needs not displayed", e.getMessage(), driver, testContext);
        }

    }

    public void completeAJSpecificCallBackForm(String email, String phone) throws Exception {
        try {

            //Enter  phone
            helper.enterValue(inputMobileNumber, phone);

            Thread.sleep(1000);
            helper.enterValue(inputEmail, email);


            // Click Submit callback request button
            helper.clickAnyButtonInDigitalJourney("Confirm", driver, testContext);

            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(1000);

            helper.clickAnyButtonInDigitalJourney("Exit", "2", driver, testContext);


        } catch (Exception e) {

            helper.failTest("AJ Specific CallBackForm Not Displayed", "AJ Specific CallBackForm Not Displayed", e.getMessage(), driver, testContext);
        }
    }

    public void completeAJGenericCallBackForm(String email, String phone) throws Exception {
        try {

            //Enter  phone
            helper.enterValue(inputMobileNumber, phone);

            Thread.sleep(1000);
            helper.enterValue(inputEmail, email);


            // Click Submit callback request button
            helper.clickAnyButtonInDigitalJourney("Confirm", driver, testContext);

            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(1000);

            helper.clickAnyButtonInDigitalJourney("Close", "2", driver, testContext);


        } catch (Exception e) {

            helper.failTest("AJ Generic CallBackForm Not Displayed", "AJ Generic CallBackForm Not Displayed", e.getMessage(), driver, testContext);
        }
    }

    public void completeHardStopCallBackForm(String email, String phone) throws Exception {
        try {

            // Click Request callback button
            helper.clickAnyButtonInDigitalJourney("Request a Callback", driver, testContext);

            helper.waitForLoading(driver);

            //Enter  phone
            helper.enterValue(inputMobileNumber, phone);

            Thread.sleep(1000);
            helper.enterValue(inputEmail, email);


            // Click continue on Submit Request
            helper.clickAnyButtonInDigitalJourney("Submit callback request", driver, testContext);


            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(2000);

            helper.clickAnyButtonInDigitalJourney("Exit", "2", driver, testContext);


        } catch (Exception e) {

            helper.failTest("Chat about your borrowing needs not displayed", "Chat about your borrowing needs not displayed", e.getMessage(), driver, testContext);
        }

    }

    public void verifyHSGenericInformationTextIsDisplayed(String message) throws Exception {
        try {
            String text = hsGenericInformationText.getText();
            System.out.println("Information Text is: " + text);
            if (!(text.contains(message)))
                helper.failTest("HardStop Generic Page not displayed", "HardStop Generic Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Generic Page not displayed", "HardStop Generic Page not displayed", e.getMessage(), driver, testContext);
        }

    }

    public void verifyHSSpecificInformationTextIsDisplayed(String message) throws Exception {
        try {
            String text = hsSpecificInformationText.getText();
            System.out.println("Information Text is: " + text);
            if (!(text.contains(message)))
                helper.failTest("HardStop Specific Page not displayed", "HardStop Specific Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Specific Page not displayed", "HardStop Specific Page not displayed", e.getMessage(), driver, testContext);
        }

    }

    public void verifyHSPersonalAccountInformationTextIsDisplayed(String message) throws Exception {
        try {
            String text = hsPersonalAccountInformationText.getText();
            if (!(text.contains(message)))
                helper.failTest("HardStop Personal Account Page not displayed", "HardStop Personal Account Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Personal Account Page not displayed", "HardStop Personal Account Page not displayed", e.getMessage(), driver, testContext);
        }

    }


    public void verifyHardStopPageIsDisplayed() throws Exception {

        helper.initialisePage(driver, testContext, "HardStopLandingPage");

        //capture BIN
        //helper.captureBIN(testContext, driver);

        // Read Application ID and write to excel
        Thread.sleep(1000);
        helper.captureApplicationID(testContext, driver);

        try {
            String text = txtHeaderHS.getText();

            if (!(text.contains("Sorry - we need more information")))
                helper.failTest("HardStop Landing Page not displayed", "Hard Stop Landing Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("Hard Stop Landing Page not displayed", "Hard Stop Landing Page not displayed", e.getMessage(), driver, testContext);
        }
    }

    public void verifyHardStopPersonalAccountPageIsDisplayed() throws Exception {

        helper.initialisePage(driver, testContext, "HardStopPersonalAccountPage");

        //capture BIN
        //helper.captureBIN(testContext, driver);

        // Read Application ID and write to excel
        Thread.sleep(1000);
        helper.captureApplicationID(testContext, driver);

        try {
            String text = txtHeaderHSPersonalAccount.getText();

            if (!(text.contains("Sorry - for business account holders only")))
                helper.failTest("HardStop Personal Account Page not displayed", "HardStop Personal Account Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Personal Account Page not displayed", "HardStop Personal Account Page not displayed", e.getMessage(), driver, testContext);
        }
    }


    public void verifyIneligibleLandingPageIsDisplayed() throws Exception {

        helper.initialisePage(driver, testContext, "IneligibleLandingPage");

        // Read Application ID and write to excel
        Thread.sleep(1000);
        helper.captureApplicationID(testContext, driver);

        //capture BIN
        helper.captureBIN(testContext, driver);


        try {
            String text = txtHeader.getText();

            if (!(text.contains("chat about your borrowing needs")))
                helper.failTest("Ineligible Landing Page not displayed", "Ineligible Landing Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("Ineligible Landing Page not displayed", "Ineligible Landing Page not displayed", e.getMessage(), driver, testContext);
        }
    }


    public void userClicksOnTheHelpandSupportLink() throws Exception {


        try {
            helper.waitForLoadingElementInvisibility(driver);
            Thread.sleep(2000);
            linkHelpSupport.click();
            Thread.sleep(1000);

        } catch (Exception e) {
            helper.failTest("Help and Support link click failed ", "Help and Support link click failed ", e.getMessage(), driver, testContext);
        }
    }

    public void userClicksOnTheCallBackRequestLink() throws Exception {


        try {


            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", linkCallBackRequest);

            linkCallBackRequest.click();


            // new window should have focus at this point
            helper.getLatestWindowFocused(driver);


        } catch (Exception e) {
            helper.failTest("Help and Support link click failed ", "Help and Support link click failed ", e.getMessage(), driver, testContext);
        }
    }


    public void callbackRequestOnTabClicked() throws Exception {

        helper.waitForLoading(driver);

        try {

            // new window should have focus at this point
            helper.getLatestWindowFocused(driver);

            btnCallBackRequest.click();


        } catch (Exception e) {
            helper.failTest("Callback request tab not displayed", "Callback request tab not displayed", e.getMessage(), driver, testContext);
        }
    }


    public void userCompletesCallBackTabFormAndSubmitsForm(String email, String mobileNumber) throws Exception {

        helper.initialisePage(driver, testContext, "CallbackTabRequest");

        try {


            inputMobileNumber.clear();
            inputMobileNumber.sendKeys(mobileNumber);

            inputEmail.clear();
            inputEmail.sendKeys(email);

            helper.clickAnyButtonInDigitalJourney("Submit callback request", driver, testContext);

            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(2000);

            helper.clickAnyButtonInDigitalJourney("Close", driver, testContext);


        } catch (Exception e) {

            helper.failTest("Chat about your borrowing needs not displayed", "Chat about your borrowing needs not displayed", e.getMessage(), driver, testContext);
        }
    }


    public void userCompletesCallBackFormFromCustomerLinkAndSubmits(String email, String mobileNumber) throws Exception {

        helper.initialisePage(driver, testContext, "CallbackRequest");


        try {

            helper.getLatestWindowFocused(driver);

            // If the call back page is displayed after the loging screen the landing page also has the email and mobile number input fields
            // hence we use findelements (as opposed to the find element object here)
            int indexOfElement = 0;
            if (driver.findElements(By.id("mobileNumber")).size() > 1)
                indexOfElement = 1;

            driver.findElements(By.id("mobileNumber")).get(indexOfElement).clear();
            driver.findElements(By.id("mobileNumber")).get(indexOfElement).sendKeys(mobileNumber);

            driver.findElements(By.id("email")).get(indexOfElement).clear();
            driver.findElements(By.id("email")).get(indexOfElement).sendKeys(email);

            helper.clickAnyButtonInDigitalJourney("Submit callback request", driver, testContext);

            helper.getLatestWindowFocused(driver);
            driver.switchTo().activeElement();
            Thread.sleep(2000);

            helper.clickAnyButtonInDigitalJourney("Close", driver, testContext);


        } catch (Exception e) {
            helper.failTest("Chat about your borrowing needs not displayed", "Chat about your borrowing needs not displayed", e.getMessage(), driver, testContext);
        }
    }


    public void verifyAJSpecificInformationTextIsDisplayed(String message) throws Exception {
        try {
            String text = txtInfoAJSpecific.getText();
            System.out.println("Information Text is: " + text);
            if (!(text.contains(message)))
                helper.failTest("AJ Specific Page not displayed", "AJ Specific Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("AJ Specific Page not displayed", "AJ Specific Page not displayed", e.getMessage(), driver, testContext);
        }
    }

    public void verifyAJGenericInformationTextIsDisplayed(String message) throws Exception {
        try {
            String text = txtInfoAJGeneric.getText();
            System.out.println("Information Text is: " + text);
            if (!(text.contains(message)))
                helper.failTest("AJ Generic Page not displayed", "AJ Generic Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("AJ Generic Page not displayed", "AJ Generic Page not displayed", e.getMessage(), driver, testContext);
        }
    }
}


