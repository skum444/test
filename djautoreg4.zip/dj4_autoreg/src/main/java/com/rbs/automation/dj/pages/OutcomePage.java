package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.helpers.ExcelUtils;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.testcontext.TestContext;

public class OutcomePage {

	private WebDriver driver;
	private String sTestDataSheetName = "Outcome";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();


	// initialise the page elements when the class is instantiated
	public OutcomePage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	
	@FindBy(how = How.TAG_NAME, using = "h1")
	public WebElement outcomeTitle;

	@FindBy(how = How.CSS, using = "#app p")
	public WebElement outcomeinfoText;

	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Your reference number is:')]")
	public WebElement textApplicationID;
	
	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Thank you for your application')]")
	public WebElement textHeader;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'OutcomeProductSummary_productName')]")
	public WebElement textProduc;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'OutcomeProductSummary_productCategory')]")
	public WebElement textProductCategory;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Amount']/following-sibling::span")
	public WebElement textAmount;
	
	
	@FindBy(how = How.XPATH, using = "//p[text()='Term']/following-sibling::span")
	public WebElement textTerm;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Monthly repayments']/following-sibling::span")
	public WebElement textMonthlyRepayments;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Interest rate']/following-sibling::span")
	public WebElement textInterestRate;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Total interest']/following-sibling::span")
	public WebElement textTotalInterest;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Product fees']/following-sibling::span")
	public WebElement textProductFees;
	
	@FindBy(how = How.XPATH, using = "//p[text()='Total payable']/following-sibling::span")
	public WebElement textTotalPayable;
	
	
	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Conditions of fulfilment')]")
	public WebElement textConditionsOfFulfilmentHeader;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'What happens next')]")
	public WebElement textWhatHappensNextHeader;
	
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Your feedback is important to us')]")
	public WebElement textYourFeedbackHeader;
	
	
	@FindBy(how = How.XPATH, using = "//h2/span")
	public WebElement textFinancialInfoRequired;
	
	
	
	
	public void Outcome_ClosePage() throws Exception {
		try {
			
		
			helper.clickAnyButtonInDigitalJourney("Close this page", driver,testContext);
			
			
			
		} catch (Exception e) {
			
			helper.failTest("Outcome Page ", "Could not close page", e.getMessage(), driver,testContext);
		}

	}
	
	
	
	
	public void verifyOutcomePageElements() throws Exception {

			// outcome title text is displayed
			if (!helper.isElementPresent(outcomeTitle, driver))
				helper.failTest("Outcome Page - Title", "Title is present", "Title is not present", driver, testContext);

			// application id is present
			if (!helper.isElementPresent(outcomeinfoText, driver))
				helper.failTest("Outcome Page - Information Text", "Information Text is present", "Information Text is not present", driver, testContext);

			// application id is present
			if (!helper.isElementPresent(textApplicationID, driver))
				helper.failTest("Outcome Page - Application ID", "Application ID is present", "Application ID is not present", driver, testContext);

			// PRODUCT INFO
			
			// Selected product is present
			if (!helper.isElementPresent(textProduc, driver)) 
				helper.failTest("Outcome Page - Selected Product", "Selected Product is present", "Selected Product is not present", driver, testContext);
			
				
			// Selected product Category is present
			if (!helper.isElementPresent(textProductCategory, driver)) 
				helper.failTest("Outcome Page - Selected Product Category ", "Selected Product Category is present", "Selected Product Category is not present", driver, testContext);
				
			// PRODUCT PRICING & TERM
			
			// Product Info Amount is present
			if (!helper.isElementPresent(textAmount, driver)) 
				helper.failTest("Outcome Page - Selected Product Amount ", "Selected Product Amount is present", "Selected Product Amount is not present", driver, testContext);
																				
				
			// Product Info Term is present
			if (!helper.isElementPresent(textTerm, driver)) 
				helper.failTest("Outcome Page - Selected Product Term ", "Selected Product Term is present", "Selected Product Term is not present", driver, testContext);
						
			// Product Info Interest Rate is present
			if (!helper.isElementPresent(textInterestRate, driver)) 
				helper.failTest("Outcome Page - Selected Product Interest Rate ", "Selected Product Interest Rate is present", "Selected Product Interest Rate is not present", driver, testContext);
								
			// Product Info Interest Rate is present
			if (!helper.isElementPresent(textTotalInterest, driver)) 
				helper.failTest("Outcome Page - Selected Product Total Interest  ", "Selected Product Total Interest  is present", "Selected Product Total Interest  is not present", driver, testContext);
			
			
			// Product Info Product Fees  is present
			if (!helper.isElementPresent(textProductFees, driver)) 
				helper.failTest("Outcome Page - Selected Product Fees ", "Selected Product Fees  is present", "Selected Product Fees is not present", driver, testContext);
						
				
			// Product Info Product Fees  is present
			if (!helper.isElementPresent(textTotalPayable, driver)) 
				helper.failTest("Outcome Page - Selected Product Total payable ", "Selected Product Total payable  is present", "Selected Product Total payable is not present", driver, testContext);
						
		    // OTHER INFO
			
			
			
			// Conditions of fulfilment header is present
			if (!helper.isElementPresent(textConditionsOfFulfilmentHeader, driver)) 
				helper.failTest("Outcome Page - Conditions of fulfilment ", "Conditions of fulfilment header  is present", "Conditions of fulfilment header is not present", driver, testContext);
			
			
			// Whats happens next header is present
			if (!helper.isElementPresent(textWhatHappensNextHeader, driver)) 
				helper.failTest("Outcome Page - Whats happens next ", "Whats happens next header is present", "Whats happens next header is not present", driver, testContext);
						
			
			// Feedback header is present
			if (!helper.isElementPresent(textYourFeedbackHeader, driver)) 
				helper.failTest("Outcome Page - Feedback ", "Feedback header is present", "Feedback header is not present", driver, testContext);
						
			
		}
	
		
		
		
		/*
	
	public void verifyFIRequiredMessageDisplayed() throws Exception {
		
		
		try {
			
			if (!(textFinancialInfoRequired.getText().contains("We need your financials"))) 
			
				helper.failTest("Done Page ", "We need your financials message not displayed", "", driver,testContext);
			
		} catch (Exception e) {
						
			helper.failTest("Done Page ", "We need your financials message not displayed", e.getMessage(), driver,testContext);
		}
	}
	*/
	

	public void verifyOutcomePageIsDisplayed() throws Exception {
		
		helper.initialisePage(driver, testContext, "Thankyou");
		
		String testName= (String)testContext.scenarioContext.getContext(TestData.TestName);
		String brand = (String)testContext.scenarioContext.getContext(TestData.Brand);
		String appID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
		
		/*if(driver.getPageSource().contains("We need your financials"))
			ExcelUtils.updateFromExcel(sTestDataSheetName, testName, "DonePage","FI");
		else
			ExcelUtils.updateFromExcel(sTestDataSheetName, testName, "DonePage","Thankyou");	
				
		// Write application ID to the data sheet
		helper.writeApplicationID(sTestDataSheetName, appID, testContext, driver);		
		*/
		
		try {
						
			if (!(textHeader.getText().contains("Thank you for your application"))) {
				helper.failTest("outcome page ", "outcome page not displayed", "", driver,testContext);
			}
		} catch (Exception e) {
			
			
			helper.failTest("outcome page", "outcome page not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	
	
}
