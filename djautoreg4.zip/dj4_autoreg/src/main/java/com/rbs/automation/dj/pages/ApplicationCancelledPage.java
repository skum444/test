package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

    public class ApplicationCancelledPage {
    private WebDriver driver;
    private String sDataSheetName = "Application cancelled";
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    public ApplicationCancelledPage(WebDriver driver, TestContext context) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
    }

    @FindBy (how = How.XPATH, using = "//h1")
    public WebElement textApplicationCancelled;

    public void verifyApplicationCancelledIsDisplayed() throws Exception{
        try{
            helper.initialisePage(driver,testContext,"application cancelled");

            if (!textApplicationCancelled.getText().contains("Application cancelled")){
                helper.failTest("Application Cancelled Page","Application cancelled","",driver,testContext);
            }
        }catch (Exception e){
            helper.failTest("Application Cancelled Page","Application cancelled",e.getMessage(),driver,testContext);
        }
    }

    public void startNewApplication() throws Exception{
        helper.clickAnyButtonInDigitalJourney("Start new application",driver,testContext);
    }
}
