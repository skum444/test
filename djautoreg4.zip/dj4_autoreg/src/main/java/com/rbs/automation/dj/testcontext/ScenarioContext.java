package com.rbs.automation.dj.testcontext;
import java.util.HashMap;
import java.util.Map;

import com.rbs.automation.dj.enums.TestData;
 
public class ScenarioContext {
 
 private  Map<String, Object> scenarioContext;
 
     public ScenarioContext(){
         scenarioContext = new HashMap<>();
     }
 
     public void setContext(TestData key, Object value) {
         scenarioContext.put(key.toString(), value);
     }
 
     public Object getContext(TestData key){
         return scenarioContext.get(key.toString());
     }
 
     public Boolean isContains(TestData key){
         return scenarioContext.containsKey(key.toString());
     }
 
}

 
	

