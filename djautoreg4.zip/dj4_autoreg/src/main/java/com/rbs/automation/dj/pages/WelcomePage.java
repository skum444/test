package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class WelcomePage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public WelcomePage(WebDriver driver, TestContext context) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}
	
	//Welcome page Header
	@FindBy(how = How.XPATH, using = "//div/h2[contains(text(),'Great')]")
	public WebElement txtHeaderTextMsg;
	
	
	// Welcome page mid section
	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[1]")
	public WebElement txtViewYourQuotes;
	
	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[2]")
	public WebElement txtCallbackToDiscuss;
	
	
	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[3]")
	public WebElement txtAccessFundsIn24Hours;
	
	@FindBy(how = How.XPATH, using = "//div[starts-with(@class,'NextSteps_suitableText')]")
	public WebElement txtOnlineLEndingSuitableFor;
	
	
	@FindBy(how = How.XPATH, using = "//div[starts-with(@class,'NextSteps_applyText')]")
	public WebElement txtWhatYouMayNeedToApply;
	
	// Welcome Page update details
	
	@FindBy(how = How.XPATH, using = "//button[text()='Try again']")
	public WebElement btnRetry;

	@FindBy(how = How.XPATH, using = "//button[text()='Get started']")
	public WebElement btnGetStarted;

	@FindBy(how = How.XPATH, using = "//button[text()='Update']")
	public WebElement btnUpdate;

	@FindBy(how = How.NAME, using = "emailAddress")
	public WebElement inputEmail;

	@FindBy(how = How.NAME, using = "phoneNumber")
	public WebElement inputMobileNumber;

	@FindBy(how = How.XPATH, using = "//a[text()='Request a callback']")
	public WebElement linkRequestCallback;

	@FindBy(how = How.XPATH, using = "//a[text() = 'Contact us']")
	public WebElement linkContactUs;

	@FindBy(how = How.XPATH, using = "//img[@alt='Exit']")
	public WebElement btnExit;
	
	public void updateDetailsOnLandingPage(String email, String mobileNumber) throws Exception {

		try {

			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", linkRequestCallback);
			Thread.sleep(2000);

			if (helper.isElementPresent(By.xpath("//button[text()='Edit details']"), driver)) {
				 helper.clickAnyButtonInDigitalJourney("Get started", driver,testContext);

			} else {

				
				Thread.sleep(1000);
				helper.enterValue(inputEmail, email);
				
				// Select the country code from drop downlist
				driver.findElement(By.xpath("//div[@class='zb-dropdown-list zb-has-scrollbar']/ul/li/div[contains(text(),'+30')]")).click();
				
				helper.enterValue(inputMobileNumber, mobileNumber);
				
				btnUpdate.click();
				helper.clickAnyButtonInDigitalJourney("Get started", driver,testContext);

			}
		} catch (Exception e) {
			e.printStackTrace();
			helper.failTest("Landing Page", "Landing Page", e.getMessage(), driver, testContext);
		}

	}

	public void initialiseLandingPage() throws Exception {
		helper.waitForLoadingElementInvisibility(driver);

		//capture BIN
		helper.captureBIN(testContext, driver);

		// Read Application ID and write to excel
		Thread.sleep(1000);
		helper.captureApplicationID(testContext, driver);

		// initiate page
		helper.initialisePage(driver, testContext, "Landing");
	}
	
	
	public void verifyPalMessageOnLandingPage() throws Exception
	{
		initialiseLandingPage();

		String msg = txtHeaderTextMsg.getText();
		
		if(!msg.contains("we could lend your business"))
			helper.failTest("Landing Page", "Landing Page Pal message displayed","Landing Page Pal message NOT displayed", driver, testContext);
		
		
		String palAmount = msg.substring(msg.indexOf("£")+1, msg.length()-1).replace(",","").trim();
		if(!(Integer.parseInt(palAmount) > 0))
				helper.failTest("Landing Page", "Landing Page Pal Amount is displayed","Landing Page Pal Amount is NOT displayed", driver, testContext);

	
	}

	
	public void verifyNonPalMessageOnLandingPage() throws Exception
	{

		initialiseLandingPage();

		if(!txtHeaderTextMsg.getText().contains("your business could get a borrowing quote in 3 minutes "))
			helper.failTest("Landing Page", "Landing Page PAL message not displayed", "Landing Page Pal message IS displayed", driver, testContext);


	}


	public void VerifyWelcomePageDisplayElements() throws Exception
	{
		boolean elementDisplayError = false;
		String ErrorString = "";
		
		try {
			
			
		
		if(!txtHeaderTextMsg.getText().contains("Great news"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page header missing text";
			
		}
		
		
		if(!txtViewYourQuotes.getText().contains("to view your representative quotes"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page missing text 'to view your quotes'";
			
		}
		
		if(!txtCallbackToDiscuss.getText().contains("we'll callback to discuss"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page missing text 'we'll callback to discuss your application'";
			
		}
		
		
		if(!txtAccessFundsIn24Hours.getText().contains("to access funds once"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page missing text 'to access funds once everything is finalised'";
			
		}
		
		if(!txtOnlineLEndingSuitableFor.getText().contains("Online lending is suitable for"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page missing text 'Online lending is suitable for'";
			
		}
		
		
		if(!txtWhatYouMayNeedToApply.getText().contains("What you may need to apply"))
		{
			elementDisplayError = true;
			ErrorString += "Welcome page missing text 'What you may need to apply'";
			
		}
		
		if(elementDisplayError == true)
			helper.failTest("Welcome Page", "Welcome Page elements or text not present", ErrorString, driver, testContext);
		
		} catch (Exception e) {
			
			helper.failTest("Welcome Page", "Landing Page", e.getMessage(), driver, testContext);
		}
		 
		
		
	}
	
	
	public void verifyMessageOnLandingPage(String messageToVerify) throws Exception {
		helper.waitForLoading(driver);

		initialiseLandingPage();

		if (driver.getCurrentUrl().contains("welcome")) {

			String LandingPageText = driver.findElement(By.xpath("//h1")).getText();
			String PALText = driver.findElement(By.xpath("(//h2)[2]")).getText();
			
			
			helper.resetImplicitTimeoutToDefault(driver);

			if (!(PALText.toLowerCase().contains(messageToVerify.toLowerCase()))) {
				helper.failTest("Correct landing page message should be displayed", PALText, messageToVerify, driver, testContext);
			}

		} else if (driver.getCurrentUrl().contains("error")) {
			helper.failTest("Sorry, something's gone wrong page is displayed",
					"Sorry, something's gone wrong page is displayed", "", driver, testContext);
		} else if (driver.getCurrentUrl().contains("welcome")) {
			helper.failTest("Welcome page is displayed", "Welcome page is displayed", "", driver, testContext);
		} else if (driver.getCurrentUrl().contains("ineligibleDJ")) {
			helper.failTest("Ineligible page is displayed", "Ineligible page is displayed", "", driver, testContext);
		}
	}

	public void continueApplicationScreenDisplayedAndClickContinue() throws Exception {

		if (!driver.findElement(By.xpath("//span[@class='zb-card-header-title']")).getText()
				.equalsIgnoreCase("Application in progress"))
			helper.failTest("Application In Progress Page not displayed", "Application In Progress Page not displayed",
					"", driver, testContext);

		helper.clickAnyButtonInDigitalJourney("Continue application", driver, testContext);

	}

	public void continueApplicationScreenDisplayedAndClickCancel() throws Exception {

		if (!driver.findElement(By.xpath("//span[@class='zb-card-header-title']")).getText()
				.equalsIgnoreCase("Application in progress"))
			helper.failTest("Application In Progress Page not displayed", "Application In Progress Page not displayed",
					"", driver, testContext);
		

		driver.findElement(By.id("manualBusiness")).click();

		driver.findElement(By.xpath("//button[@class='zb-button zb-button-secondary' and text()='Confirm cancellation']")).click();

		driver.findElement(By.xpath("//*[text()='Other']")).click();
		
		driver.findElement(By.xpath("//textarea")).sendKeys("test");
		
		helper.clickAnyButtonInDigitalJourney("Confirm cancellation", driver, testContext);

		driver.findElement(By.xpath("//button[@class='zb-button zb-button-secondary']")).click();

		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//h1")).click();

		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//button[text()='Start new application']")).click();

		

	}
	
	public void verifyLandingPage() throws Exception {
		if(!txtHeaderTextMsg.isDisplayed())
			helper.failTest("Landing Page","Landing Page is Expected","Landing Page is not displayed",driver,testContext);
		initialiseLandingPage();

		}

	public void verifyDisplayedPage(String rptpage) throws Exception {

		initialiseLandingPage();

		String segment = (String) testContext.scenarioContext.getContext(TestData.Segment);

		String page = null;
		String url = driver.getCurrentUrl();
		if (rptpage.contains("welcome")) {
			page = "welcome";
		} else if (rptpage.contains("landing")) {
			page = "welcomeDJ";
		} else if (rptpage.contains("AJ")) {
			page = "ineligible";
		} else if (rptpage.contains("hardstop")) {
			page = "inEligible";
		}

		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		
		if (url.contains(page)) {

			if (url.contains("error")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
					// commoncomps.failTest("Technical error page is displayed
					// incorrectly instead of " + rptpage + " page", "Technical
					// error page is displayed incorrectly instead of " +
					// rptpage + " page", "", driver);
				}
			} else if (url.contains("ineligible")) {
				if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail("Page is displayed incorrectly instead of " + rptpage + " page");
					// commoncomps.failTest("Page is displayed incorrectly
					// instead of " + rptpage + " page", "Page is displayed
					// incorrectly instead of " + rptpage + " page", "",
					// driver);
				}
			} else if (url.contains("inEligible?reason=personal")) {
				Assert.fail("Sorry - for business account holders only page is displayed incorrectly instead of "
						+ rptpage + "page");
				// commoncomps.failTest("Sorry - for business account holders
				// only page is displayed incorrectly instead of " + rptpage +
				// "page", "Sorry - for business account holders only page is
				// displayed incorrectly instead of " + rptpage + "page", "",
				// driver);
			} else {
				if (segment.equalsIgnoreCase("ONECONNECT")) {
					if (url.contains("welcomeDJ")) {
						Assert.fail("Landing page is displayed incorrectly instead of " + rptpage + " page");
						// commoncomps.failTest("Landing page is displayed
						// incorrectly instead of " + rptpage + " page",
						// "Landing page is displayed incorrectly instead of " +
						// rptpage + " page", "", driver);
					}
				} else if (!(segment.equalsIgnoreCase("ONECONNECT"))) {
					if (!(url.contains("welcome"))) {
						Assert.fail("Welcome page is displayed incorrectly instead of " + rptpage + " page");
						// commoncomps.failTest("Welcome page is displayed
						// incorrectly instead of " + rptpage + " page",
						// "Welcome page is displayed incorrectly instead of " +
						// rptpage + " page", "", driver);
					}
				}
			}
			System.out.println(rptpage + " page is displayed as expected for the " + segment);
		} else if (url.contains("inEligibleInprogress")) {
			Assert.fail("Application in progress page is displayed incorrectly instead of " + rptpage + " page");
		} else {
			System.out.println("Incorrect page is displayed - " + url + "\nExpected page is  - " + rptpage + " for the "
					+ segment + " Customer");
			if (url.contains("welcomeDJ")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("Landing page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("welcome")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("welcome page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("ineligible")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("ineligible page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("error")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("error page is displayed incorrectly instead of " + rptpage + " page");
				}
			}
		}

		//btnExit.click();
		
	}





}
