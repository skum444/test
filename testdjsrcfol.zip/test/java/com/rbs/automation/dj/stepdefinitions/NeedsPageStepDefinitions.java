package com.rbs.automation.dj.stepdefinitions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import java.util.Collection;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.NeedsPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import javax.xml.crypto.KeySelector;
import java.time.Month;
import java.time.Year;

public class NeedsPageStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    NeedsPage needsPage;
    private HelperFunctions helper = new HelperFunctions();

    public NeedsPageStepDefinitions(TestContext context) {

        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        needsPage = testContext.getPageObjectManager().getNeedsPage(context);

    }

    @Then("^the needs page should be displayed\\.$")
    public void the_needs_page_should_be_displayed() throws Throwable {
        needsPage.verifyNeedsPageIsDisplayed();
    }

  

    @When("^user selects the following \"([^\"]*)\"$")
    public void user_selects_the_following(String purpose) throws Throwable {
        needsPage.selectPurpose(purpose);


    }

    @Then("^the correct \"([^\"]*)\" to be displayed on the same page$")
    public void the_correct_to_be_displayed_on_the_same_page(String headerText) throws Throwable {
        needsPage.verifyHeaderForPurpose(headerText);

    }

    @When("^user completes the following information on the needs page$")
    public void user_completes_the_following_information_on_the_needs_page() throws Throwable {
       needsPage.completeNeedsPageByExcel();
    }

    @When("^clicks continue on the needs page$")
    public void clicks_continue_on_the_needs_page() throws Throwable {
        needsPage.clickContinueOnNeedsPage();
    }

    @When("^user completes the following \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" information on the needs page$")
    public void user_completes_the_following_information_on_the_needs_page(String Purpose, String SubPurpose, String TertiaryQ1, String TransactionAmount, String Amount, String Years, String Months, String Product, String ContributionSource) throws Throwable {

        needsPage.completeNeedsPage(Purpose,SubPurpose,TertiaryQ1,TransactionAmount,Amount, Years, Months,Product,ContributionSource);
    }

  /*  @When("^user completes the following \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  information on the needs page$")
    public void user_completes_the_following_information_on_the_needs_page(String Purpose, String SubPurpose, String TertiaryQ1, String TransactionAmount, String Amount, String Years, String Months, String Product) throws Throwable {
        needsPage.completeNeedsPage(Purpose,SubPurpose,TertiaryQ1,TransactionAmount,Amount, Years, Months,Product);
    }
*/
    @When("^user completes the following \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" information on the needs page$")
    public void user_completes_the_following_information_on_the_needs_page(String Purpose, String SubPurpose, String Tenure , String LeaseTerm, String TransactionalAmount, String Amount, String Years, String Months, String Product, String ContributionSource) throws Throwable {
        needsPage.completePropertyNeedsPage(Purpose,SubPurpose,Tenure,LeaseTerm,TransactionalAmount,Amount,Years,Months,Product,ContributionSource);
   }

    @When("^user completes following information on the needs page$")
    public void user_completes_following_information_on_the_needs_page(DataTable NeedsInfo ) throws Throwable {
        java.util.List<Map<String, String>> needsInfoList = NeedsInfo.asMaps(String.class, String.class);

        needsPage.verifyNeedsInfoList(needsInfoList);
    }
    
    
    @When("^user completes additional cashflow questions \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_completes_additional_cashflow_questions_and_and(String whatProductRepay, String financingDebtWith, String sellGoodsAndServices) throws Throwable {
       
    	 needsPage.completeCashflowAdditionalQuestions(whatProductRepay, financingDebtWith, sellGoodsAndServices);
    }
    
    @When("^user completes additional property questions \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_completes_additional_property_questions_and(String tenure, String leaseTerm) throws Throwable {
        
    	needsPage.completeAdditionalPropertyQuestions(tenure, leaseTerm);
    }


    @Then("^the contribution source is displayed$")
    public void the_contribution_source_is_displayed() throws Throwable {
        needsPage.verifyContributionSourceIsDisplayed();
    }

    @Then("^a message is displayed 'Select contribution source'$")
    public void a_message_is_displayed_Select_contribution_source() throws Throwable {
       needsPage.verifyErrorContributionSource();
    }

    @Then("^verify 'Please provide contribution source' is not displayed$")
    public void verify_Please_provide_contribution_source_is_not_displayed() throws Throwable {
       needsPage.verifyContributionSourceNotdisplayed();
    }

    @Then("^I should see \"([^\"]*)\"$")
    public void i_should_see(String errorMessage) throws Throwable {
        needsPage.verifyNeedsPageError(errorMessage);
    }



}