package com.rbs.automation.dj.stepdefinitions;

import java.util.Properties;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.pages.WelcomePage;
import com.rbs.automation.dj.pages.IneligibleLandingPage;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.FileReaderManager;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WelcomePageStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    WelcomePage landingPage;
    IneligibleLandingPage ineligibleLandingPage;
    private HelperFunctions helper = new HelperFunctions();


    public WelcomePageStepDefinitions(TestContext context) {

        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        landingPage = testContext.getPageObjectManager().getLandingPage(context);
        ineligibleLandingPage = testContext.getPageObjectManager().getIneligibleLandingPage(context);
    }

    @Then("^verify landing screen is displayed with the correct message containing the text \"([^\"]*)\"$")
    public void verify_landing_screen_is_displayed_with_the_correct_message_containing_the_text(String messageToVerify)
            throws Throwable {

        landingPage.verifyMessageOnLandingPage(messageToVerify);
    }


    @Then("^verify landing screen is displayed with pal message and amount$")
    public void verify_landing_screen_is_displayed_with_pal_message_and_amount() throws Throwable {

        landingPage.verifyPalMessageOnLandingPage();
    }

    @Then("^verify landing screen is displayed without pal message$")
    public void verify_landing_screen_is_displayed_without_pal_message() throws Throwable {

        landingPage.verifyNonPalMessageOnLandingPage();
    }


    @When("^user enters values in \"([^\"]*)\" and \"([^\"]*)\" field and clicks on Get Started button\\.$")
    public void user_enters_values_in_and_field_and_clicks_on_Get_Started_button(String email, String mobileNumber)
            throws Throwable {

        landingPage.updateDetailsOnLandingPage(email, mobileNumber);

    }

    @When("^user enters email and mobile number and clicks on Get Started button\\.$")
    public void user_enters_email_and_mobile_number_and_clicks_on_Get_Started_button() throws Throwable {

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();

        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        landingPage.updateDetailsOnLandingPage(email, mobileNumber);

    }

    @Then("^user is displayed the continue application page and clicks cancel$")
    public void user_is_displayed_the_continue_application_page_and_clicks_cancel() throws Throwable {

        landingPage.continueApplicationScreenDisplayedAndClickCancel();
    }

    @Then("^user is displayed the continue application page and clicks continue$")
    public void user_is_displayed_the_continue_application_page_and_clicks_continue() throws Throwable {
        landingPage.continueApplicationScreenDisplayedAndClickContinue();
    }

    @Then("^verify the \"([^\"]*)\" page is displayed$")
    public void verify_the_page_is_displayed(String expectedPage) throws Throwable {
        landingPage.verifyDisplayedPage(expectedPage);
    }

    @Then("^verify all landing page elements are present$")
    public void verify_all_landing_page_elements_are_present() throws Throwable {
        landingPage.VerifyWelcomePageDisplayElements();
    }


    //========================================
    // Ineligible
    //========================================

    @Then("^verify that the inelligble landing page is displayed$")
    public void verify_that_the_inelligble_landing_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyIneligibleLandingPageIsDisplayed();

    }

    @When("^user completes the callback request form \"([^\"]*)\" and \"([^\"]*)\"  and confirms$")
    public void user_completes_the_callback_request_form_and_and_confirms(String email, String phone) throws Throwable {

        ineligibleLandingPage.completeIneligibleForm(email, phone);
    }


    @When("^user completes the callback request form and continues$")
    public void user_completes_the_callback_request_form_and_continues() throws Throwable {

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();

        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeIneligibleForm(email, mobileNumber);


    }

    @When("^user completes the AJ specific callback request form and continues$")
    public void user_completes_the_aj_specific_callback_request_and_continues() throws Throwable {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeAJSpecificCallBackForm(email, mobileNumber);
    }

    @When("^user completes the AJ generic callback request form and continues$")
    public void user_completes_the_aj_generic_callback_request_and_continues() throws Throwable {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeAJGenericCallBackForm(email, mobileNumber);
    }

    @When("^user completes the HS callback request form and continues$")
    public void user_completes_the_hs_callback_request_and_continues() throws Throwable {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeHardStopCallBackForm(email, mobileNumber);
    }

    @Then("^verify that the hardstop landing page is displayed$")
    public void verify_that_the_hardstop_landing_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyHardStopPageIsDisplayed();
    }

    @Then("^verify that the hardstop personal account page is displayed$")
    public void verify_that_the_hardstop_personal_account_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyHardStopPersonalAccountPageIsDisplayed();
    }


    @When("^hs landing page is displayed and user completes the hs specific callback request form \"([^\"]*)\" and \"([^\"]*)\" and continues$")
    public void hs_landing_page_is_displayed_and_user_completes_the_hs_specific_callback_request_form_and_continues(String email, String phone) throws Throwable {
        ineligibleLandingPage.verifyHardStopPageIsDisplayed();
        ineligibleLandingPage.completeHardStopCallBackForm(email, phone);
    }

    @Then("^verify the \"([^\"]*)\" is displayed on HS generic page$")
    public void verify_the_in_hs_generic_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSGenericInformationTextIsDisplayed(message);

    }

    @Then("^verify the \"([^\"]*)\" is displayed on HS specific page$")
    public void verify_the_in_hs_specific_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSSpecificInformationTextIsDisplayed(message);

    }


    @Then("^verify if welcome page is displayed$")
    public void verify_if_landing_page_is_displayed() throws Throwable {
        landingPage.verifyLandingPage();
    }

    @And("^verify the \"([^\"]*)\" is displayed on HS personal account page$")
    public void verify_text_is_displayed_on_hs_personal_account_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSPersonalAccountInformationTextIsDisplayed(message);
    }

    @And("^verify the \"([^\"]*)\" is displayed on AJ specific page$")
    public void verify_text_is_displayed_on_aj_specific_page(String message) throws Throwable {
        ineligibleLandingPage.verifyAJSpecificInformationTextIsDisplayed(message);
    }

    @And("^verify the \"([^\"]*)\" is displayed on AJ generic page$")
    public void verify_text_is_displayed_on_aj_generic_page(String message) throws Throwable {
        ineligibleLandingPage.verifyAJGenericInformationTextIsDisplayed(message);
    }
}
