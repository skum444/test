package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.BPMLendingDigitalSearchPage;
import com.rbs.automation.dj.pages.HomePage;
import com.rbs.automation.dj.testcontext.TestContext;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BPMLendingDigitalSearchStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	BPMLendingDigitalSearchPage bpmDigitalSearchScreen;
	HomePage homePage;
	
	public BPMLendingDigitalSearchStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		bpmDigitalSearchScreen = testContext.getPageObjectManager().BPMLendingDigitalSearchPage(context);		
		
	}	

	@Then("^user should be navigated to Lending Digital Search screen page$")
	public void user_should_be_navigated_to_Lending_Digital_Search_screen_page() throws Throwable {
		bpmDigitalSearchScreen.verifyBPMDigitalSearchPageIsDisplayed();
	}

	@When("^user enters Application Id and clicks on search button$")
	public void user_enters_Application_Id_and_clicks_on_search_button() throws Throwable {
		bpmDigitalSearchScreen.inputApplicationId();
		bpmDigitalSearchScreen.searchApplication();
	}

	@Then("^verify an entry is displayed with the correct \"([^\"]*)\"$")
	public void verify_an_entry_is_displayed_with_the_correct(String status) throws Throwable {
		bpmDigitalSearchScreen.verifyApplicationStatus(status);
	}
	
}