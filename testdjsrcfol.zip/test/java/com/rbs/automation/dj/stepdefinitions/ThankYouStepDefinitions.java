package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.ThankYouPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import org.openqa.selenium.WebDriver;

public class ThankYouStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    ThankYouPage thankYouPage;
    private HelperFunctions helper = new HelperFunctions();

    public ThankYouStepDefinitions(TestContext context){
        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        thankYouPage = testContext.getPageObjectManager().getthankYouPage(context);

         }


    @Then("^the callback request Thank you page is displayed$")
    public void the_callback_request_Thank_you_page_is_displayed() throws Throwable {
        thankYouPage.verifyThankYouPageIsDisplayed();
         }

    @Then("^I click the Save and Exit button$")
    public void i_click_the_Save_and_Exit_button() throws Throwable {
        thankYouPage.saveAndExit();
         }


    }

