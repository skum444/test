package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.BPMLoginPage;
import com.rbs.automation.dj.pages.BPMMyWorksPage;
import com.rbs.automation.dj.pages.HomePage;
import com.rbs.automation.dj.testcontext.TestContext;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BPMMyWorksStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	BPMMyWorksPage bpmMyWorksPage;
	HomePage homePage;
	
	private HelperFunctions helper = new HelperFunctions();

	public BPMMyWorksStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		bpmMyWorksPage = testContext.getPageObjectManager().BPMWorksTabPage(context);		
		
	}

	@Then("^user should navigate to works tab$")
	public void user_should_navigate_to_works_tab() throws Throwable {
		bpmMyWorksPage.verifyBPMWorksTabPageIsDisplayed();
	}

	/*@When("^user enters the works tab and searches the task based on application reference number$")
	public void user_enters_the_works_tab_and_searches_the_task_based_on_application_reference_number() throws Throwable {
		bpmMyWorksPage.claimTaskForApplicationID();
	}*/	
	
	@When("^user enters the works tab and searches the task based on application reference number as \"([^\"]*)\"$")
	public void user_enters_the_works_tab_and_searches_the_task_based_on_application_reference_number_as(String userID) throws Throwable {
		bpmMyWorksPage.claimTaskForApplicationID(userID);
	}
	
	@When("^user click on Lending Digital Search link$")
	public void user_click_on_Lending_Digital_Search_link() throws Throwable {
		bpmMyWorksPage.clickLendingDigitalSearchLink();
	}
	
	@When("^user selects the Digital pending applications tab and enters the application ID$")
	public void user_selects_the_Digital_pending_applications_tab_and_enters_the_application_ID() throws Throwable {
		bpmMyWorksPage.pendingTabValidation();
	}

	@Then("^application should be displayed in the tab$")
	public void application_should_be_displayed_in_the_tab() throws Throwable {
		bpmMyWorksPage.appValidationInPendingTab();
	}
	
}