package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.BPMLoginPage;
import com.rbs.automation.dj.pages.HomePage;
import com.rbs.automation.dj.testcontext.TestContext;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BPMLoginPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	BPMLoginPage bpmLoginPage;
	HomePage homePage;
	
	private HelperFunctions helper = new HelperFunctions();

	public BPMLoginPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		bpmLoginPage = testContext.getPageObjectManager().getBPMLoginPage(context);
		homePage = testContext.getPageObjectManager().getHomePage(context);
		
	}
	
	@When("^provided login credentials as \"([^\"]*)\"$")
	public void provided_login_credentials_as(String UserRole) throws Throwable {
		bpmLoginPage.loginToBPM(UserRole);
	}

	@When("^user click on Logout$")
	public void user_click_on_Logout() throws Throwable {
	   bpmLoginPage.logoutFromBPM();
	}

	@Then("^user should navigate to login page$")
	public void user_should_navigate_to_login_page() throws Throwable {
	    
	}
}