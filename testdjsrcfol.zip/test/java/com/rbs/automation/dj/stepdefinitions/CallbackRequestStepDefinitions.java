package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.requestCallBackPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CallbackRequestStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	requestCallBackPage callBackRequestPage;
	private HelperFunctions helper = new HelperFunctions();

	public CallbackRequestStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		callBackRequestPage = testContext.getPageObjectManager().getCallBackRequestPage(context);

	}

	/*
	@Then("^verify call back page is displayed$")
	public void verify_call_back_page_is_displayed() throws Throwable {

		callBackRequestPage.verifyCallBackFormIsDisplayed();
	}


	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\" and submits call back request$")
	public void user_enters_and_and_submits_call_back_request(String email, String phone) throws Throwable {

		callBackRequestPage.completeCallBackRequestForm(email, phone);
	}

	@When("^user clicks on the help and support link$")
	public void user_clicks_on_the_help_and_support_link() throws Throwable {
		callBackRequestPage.userClicksOnTheHelpandSupportLink();
	}

	@When("^Call back request tab is displayed$")
	public void call_back_request_tab_is_displayed() throws Throwable {
		callBackRequestPage.verifyCallBackFormIsDisplayed();
	}

	@When("^user completes the callback request form with \"([^\"]*)\" and \"([^\"]*)\" and submits$")
	public void user_completes_the_callback_request_form_with_and_and_submits(String email, String mobileNumber)
			throws Throwable {

		callBackRequestPage.userCompletesCallBackFormFromCustomerLinkAndSubmits(email, mobileNumber);
	}

	@When("^user clicks on the callback request link$")
	public void user_clicks_on_the_callback_request_link() throws Throwable {

		callBackRequestPage.userClicksOnTheCallBackRequestLink();
	}

	@When("^user clicks on the callback request tab$")
	public void user_clicks_on_the_callback_request_tab() throws Throwable {

		callBackRequestPage.callbackRequestOnTabClicked();
	}

	@When("^user completes the callback request tab form with \"([^\"]*)\" and \"([^\"]*)\" and submits$")
	public void user_completes_the_callback_request_tab_form_with_and_and_submits(String email, String mobileNumber)
			throws Throwable {

		callBackRequestPage.userCompletesCallBackTabFormAndSubmitsForm(email, mobileNumber);
	}
	*/
}
