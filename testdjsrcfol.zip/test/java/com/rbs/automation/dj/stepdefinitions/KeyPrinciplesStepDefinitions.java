package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.OracleBBC;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.KeyPrinciplesPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

public class KeyPrinciplesStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	KeyPrinciplesPage keyPrinciplesPage;
	private OracleBBC DBDetails = new OracleBBC();
	private HelperFunctions helper = new HelperFunctions();

	public KeyPrinciplesStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		keyPrinciplesPage = testContext.getPageObjectManager().getKeyPrinciplesPage(context);


	}

	@Then("^the key principles page is displayed$")
	public void the_key_principles_page_is_displayed() throws Throwable {
		keyPrinciplesPage.verifyKeyPrinciplesPageIsDiplayedPage();
	}



	@Then("^the Add KP link is not displayed$")
	public void the_Add_KP_link_is_not_displayed() throws Throwable {

		keyPrinciplesPage.verifyAddKPLinkNotDisplayed();
	}

	@Then("^Edit KP link is displayed$")
	public void edit_KP_link_is_displayed() throws Throwable {

		keyPrinciplesPage.verifyEditKPLinkDisplayed();
	}

	@When("^I click add Key principles and add values as below and perform \"([^\"]*)\"$")
	public void i_click_add_Key_principles_and_add_values_as_below_and_perform(String actionToPerform, DataTable KPValidation) throws Throwable {
		keyPrinciplesPage.clickAddKPLink();
		java.util.List<Map<String, String>> KPValidationList = KPValidation.asMaps(String.class, String.class);
		keyPrinciplesPage.KPValidation(KPValidationList,actionToPerform);
	}


	@Then("^I see the appropriate error messages against the relevant fields$")
	public void i_see_the_appropriate_error_messages_against_the_relevant_fields() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}
	@When("^I try to add all key Principle details correctly as follows and I Click Save$")
	public void i_try_to_add_all_key_Principle_details_correctly_as_follows_and_I_Click_Save(DataTable KPValues) throws Throwable {
		keyPrinciplesPage.clickAddKPLink();
		java.util.List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
		keyPrinciplesPage.toEnterKPValues(KPValuesToBeEntered);


	}
	@Then("^the newly validated key Prinicipal is added to the User interface and key principal name is displayed at the bottom of the key principals section with an '!'$")
	public void the_newly_validated_key_Prinicipal_is_added_to_the_User_interface_and_key_principal_name_is_displayed_at_the_bottom_of_the_key_principals_section_with_an() throws Throwable {
		keyPrinciplesPage.toVerifyIfKPIsAdded();

	}
	@When("^I try to add all key Principle details correctly as follows and I Click Cancel$")
	public void i_try_to_add_all_key_Principle_details_correctly_as_follows_and_I_Click_Cancel(DataTable KPValues) throws Throwable {
		keyPrinciplesPage.clickAddKPLink();
		java.util.List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
		keyPrinciplesPage.toEnterKPValues(KPValuesToBeEntered);
	}

	@Then("^I should be returned to 'Your key principals' screen$")
	public void i_should_be_returned_to_Your_key_principals_screen() throws Throwable {
		keyPrinciplesPage.buttonClick("Cancel");
		keyPrinciplesPage.verifyEditKPLinkDisplayed();
	}
	@When("^I see 'Your key principals' screen is displayed$")
	public void i_see_Your_key_principals_screen_is_displayed() throws Throwable {
		keyPrinciplesPage.toVerifyIfKPIsAdded();

	}


	@Then("^I Remove the KP added\\.$")
	public void i_Remove_the_KP_added() throws Throwable {
		keyPrinciplesPage.toRemoveKPAdded();
	}


	@Then("^I Click on 'Add a new key principal' button$")
	public void i_Click_on_Add_a_new_key_principal_button() throws Throwable {
		keyPrinciplesPage.clickAddKPLink();

	}
	@When("^I enter value in postcode field as follows$")
	public void i_enter_value_in_postcode_field_as_follows(DataTable postCodeField) throws Throwable {
		java.util.List<Map<String, String>> postCode = postCodeField.asMaps(String.class, String.class);
		keyPrinciplesPage.toEnterValueInPostCode(postCode);
	}

	@When("^I click Find address$")
	public void i_click_Find_address() throws Throwable {
		keyPrinciplesPage.buttonClick("Find address");
	}

	@Then("^I see address list displayed matching the Postcode$")
	public void i_see_address_list_displayed_matching_the_Postcode() throws Throwable {
		keyPrinciplesPage.addressDropDown.click();
		helper.addCurrentScreenCaptureWOScrolling(driver, testContext);

	}

	@Then("^I complete all the fields for the \"([^\"]*)\" I wish to remove and click Confirm$")
	public void i_complete_all_the_fields_for_the_I_wish_to_remove_and_click_Confirm(String KPToRemove) throws Throwable {
		keyPrinciplesPage.toExpandKPDetails(KPToRemove);
		keyPrinciplesPage.buttonClick("Confirm");
		keyPrinciplesPage.validateIfKPIsConfirmed(KPToRemove);
	}

	@When("^I select an address and I click 'Save'$")
	public void i_select_an_address_and_I_click_Save() throws Throwable {
		Thread.sleep(20000);
		keyPrinciplesPage.setDropDownValue("8 PARK ROAD");
		keyPrinciplesPage.PersonalDetails();
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		keyPrinciplesPage.selectMonth.click();
		keyPrinciplesPage.setDropDownValue("01");
		keyPrinciplesPage.selectYear.click();
		keyPrinciplesPage.setDropDownValue("2015");
		WebElement button = driver.findElement(By.xpath("//button[text()='Save']"));
		button.click();
	}

	@Then("^I see that the KP address detail is populated with selected address from postcode service$")
	public void i_see_that_the_KP_address_detail_is_populated_with_selected_address_from_postcode_service() throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	}

	@Then("^I Click on 'Edit' button$")
	public void i_Click_on_Edit_button() throws Throwable {
		keyPrinciplesPage.editKP1.click();
		//keyPrinciplesPage.linkEditDetails.click();

	}

	@When("^I click on 'Residential address look up' button$")
	public void i_click_on_Residential_address_look_up_button() throws Throwable {
		keyPrinciplesPage.postCodeLookup.click();
		//keyPrinciplesPage.countryDropDown.click();
		//keyPrinciplesPage.setDropDownValue("United Kingdom");

	}

	@Then("^'Postcode' field is displayed in screen$")
	public void postcode_field_is_displayed_in_screen() throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	}

	@When("^I select an address from the list of addresses and I click 'Save'$")
	public void i_select_an_address_from_the_list_of_addresses_and_I_click_Save() throws Throwable {

		keyPrinciplesPage.setDropDownValue("8 PARK ROAD");
		keyPrinciplesPage.selectMonth.click();
		keyPrinciplesPage.setDropDownValue("01");
		keyPrinciplesPage.selectYear.click();
		keyPrinciplesPage.setDropDownValue("2015");
		WebElement button = driver.findElement(By.xpath("//button[text()='Save']"));
		button.click();
	}


	@When("^I select Non UK country in the country dropdown$")
	public void i_select_Non_UK_country_in_the_country_dropdown() throws Throwable {
		keyPrinciplesPage.countryDropDown.click();
		keyPrinciplesPage.setDropDownValue("United States of America");

	}

	@Then("^display the manual address entry fields in the screen$")
	public void display_the_manual_address_entry_fields_in_the_screen() throws Throwable {
		keyPrinciplesPage.enterAddressManually();
	}

	@When("^I enter the address and I click 'Save'$")
	public void i_enter_the_address_and_I_click_Save() throws Throwable {
		// keyPrinciplesPage.buttonClick("Save");

		keyPrinciplesPage.selectMonth.click();
		keyPrinciplesPage.setDropDownValue("01");
		keyPrinciplesPage.selectYear.click();
		keyPrinciplesPage.setDropDownValue("2010");
		keyPrinciplesPage.button.click();
	}

	@When("^I see my address is not displayed and I click 'enter address manually' button$")
	public void i_see_my_address_is_not_displayed_and_I_click_enter_address_manually_button() throws Throwable {
		keyPrinciplesPage.enterAddressManually.click();
	}

	@When("^enter the following values in address lines$")
	public void enter_the_following_values_in_address_lines(DataTable addressFieldValues) throws Throwable {
		java.util.List<Map<String, String>> addressFieldValue = addressFieldValues.asMaps(String.class, String.class);
		keyPrinciplesPage.toEnterValuesInFields(addressFieldValue);

	}

	@Then("^I see that the KP address detail is populated with manually entered address$")
	public void i_see_that_the_KP_address_detail_is_populated_with_manually_entered_address() throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	}


	@Then("^I see Postcode field is highlighted and warning symbol is displayed adjacent to postcode label$")
	public void i_see_Postcode_field_is_highlighted_and_warning_symbol_is_displayed_adjacent_to_postcode_label() throws Throwable {
		keyPrinciplesPage.postCodeFieldValidation();
	}

	@When("^I click the 'Remove' hyperlink for \"([^\"]*)\"$")
	public void i_click_the_Remove_hyperlink_for(String KPName) throws Throwable {
		keyPrinciplesPage.removeKPPopup(KPName);
	}

	@Then("^the pop-up box should display text as per the \"([^\"]*)\"$")
	public void the_pop_up_box_should_display_text_as_per_the(String hyperlinkText) throws Throwable {
		System.out.println(hyperlinkText);
		keyPrinciplesPage.toValidatePopUpBox(hyperlinkText);

	}

	@When("^I click remove button on the Pop-up$")
	public void i_click_remove_button_on_the_Pop_up() throws Throwable {
		keyPrinciplesPage.buttonClick("Remove");
	}

	@Then("^I should see key principal has been removed from the user interface$")
	public void i_should_see_key_principal_has_been_removed_from_the_user_interface() throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver,testContext);
	}

	@Then("^I should see the Customer returning to 'Your key principals' screen$")
	public void i_should_see_the_Customer_returning_to_Your_key_principals_screen() throws Throwable {
		keyPrinciplesPage.verifyKeyPrinciplesPageIsDiplayedPage();
	}

	@When("^I try to add all key Principle details correctly as follows$")
	public void i_try_to_add_all_key_Principle_details_correctly_as_follows(DataTable KPValues) throws Throwable {
		keyPrinciplesPage.clickAddKPLink();
		java.util.List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
		keyPrinciplesPage.toEnterKPValues(KPValuesToBeEntered);
	}

	@Then("^I click save$")
	public void i_click_save() throws Throwable {
		keyPrinciplesPage.buttonClick("Save");
	}


	@When("^I Click Edit for Each Key Principal$")
	public void i_Click_Edit_for_Each_Key_Principal() throws Throwable {

	}

	@When("^I complete all the fields and click Confirm$")
	public void i_complete_all_the_fields_and_click_Confirm() throws Throwable {

		keyPrinciplesPage.buttonClick("Confirm");

	}

	@Then("^I see all the key principals are displayed with a tick mark for \"([^\"]*)\"$")
	public void i_see_all_the_key_principals_are_displayed_with_a_tick_mark(int expectedKPCount) throws Throwable {
		//Added by Alagammaii
		keyPrinciplesPage.valKPConfirmationMark(expectedKPCount);
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	}


	/***Changes made by Alagammaii****/
	@Then("^I Edit FirstName Field as \"([^\"]*)\"$")
	public void I_Edit_FirstName_Field(String nameToBeModified) throws Throwable {
		keyPrinciplesPage.firstName.sendKeys(nameToBeModified);
		helper.addfullScreenCaptureToExtentReport(driver,testContext);
	}

	@Then("^Validate application KP against expected KP \"([^\"]*)\"$")
	public void Validate_KP_Count(String expected_kpcount) throws Throwable {
		keyPrinciplesPage.KPCountValidation(expected_kpcount);

	}

	@Then("^\"([^\"]*)\" is displayed$")
	public void Validate_MaxInfo_ErrorMessage(String expectedErrorMessage) throws Throwable {
		keyPrinciplesPage.ErrorMessageValidation(expectedErrorMessage);

	}

	@Then("^Validate country dropdown values$")
	public void ValidateCountryDropdown() throws Throwable {
		keyPrinciplesPage.validateCountryDropdown();

	}

	@Then("^Validate default Value of Country Dropdown$")
	public void countryDropdownDefaultValueValidation() throws Throwable {
		keyPrinciplesPage.countryDropdownDefaultVal();

	}

	@Then("^Validate incomplete data error message$")
	public void incomplete_data_err_mess() throws Throwable {
		keyPrinciplesPage.incompleteDataErrorMessageVal();

	}

	@Then("^I see no incomplete data error message for 2nd KP$")
	public void incomplete_data_err_mess_2ndKP() throws Throwable {
		keyPrinciplesPage.incompleteDataErrorMessageVal();

	}

	@Then("^I see \"([^\"]*)\" on top of Your key principals screen if validation fails for some fields$")
	public void Validate_IncompletePage_ErrorMessage(String expectedErrorMessage) throws Throwable {
		keyPrinciplesPage.incompletePageErrVal(expectedErrorMessage);

	}


	@When("^I click on second KP$")
	public void secondKPClick() throws Throwable {
		Thread.sleep(5000);
		keyPrinciplesPage.secondKP.click();
		System.out.println("Clicking second KP");
		Thread.sleep(5000);
	}

	@And("^I see Intcode displayed with -$")
	public void Intcode_displayed_empty() throws Throwable {
		keyPrinciplesPage.intCodeValidation();
	}


	@Then("^I should see IntCode should be defaulted to +44 and Please complete Error Message is not displayed for this field$")
	public void IntCodeDefaultValue() throws Throwable {
		keyPrinciplesPage.intCodeDefaultValueValidation();
	}

	@Then("^display the country field with the \"([^\"]*)\"$")
	public void display_country_code(String expectedCountryCode) throws Throwable {
		keyPrinciplesPage.validateCountryCodeDisplay(expectedCountryCode);
	}


	@Then("^the Country value should be set to 'Please select'$")
	public void country_code_value_default() throws Throwable {
		keyPrinciplesPage.validateDefaultCountryCodeDD();
	}



	@Then("^I see 'Learn more about key principals' link displayed in screen$")
	public void Learn_more_about_key_principals_link_is_displayed() throws Throwable {

		keyPrinciplesPage.LearnMoreAboutKeyPrincipalsLink.isDisplayed();
	}



	@When("^I Click on 'Learn more about key principals' link$")
	public void Learn_more_about_key_principals_link_click() throws Throwable {

		keyPrinciplesPage.LearnMoreAboutKeyPrincipalsLink.click();
	}
	
	
	@Then("^I see 'Learn more about key principals' link displayed in screen for soletrader$")
	public void Learn_more_about_key_principals_link_is_displayed_ST() throws Throwable {

		keyPrinciplesPage.LearnMoreAboutKeyPrincipalsLink_ST.isDisplayed();
	}



	@When("^I Click on 'Learn more about key principals' link for sole trader$")
	public void Learn_more_about_key_principals_link_click_ST() throws Throwable {

		keyPrinciplesPage.LearnMoreAboutKeyPrincipalsLink_ST.click();
	}
	
	


	@Then("^I see the content as per \"([^\"]*)\"$")
	public void validateLinkInfo(String pageName) throws Throwable {
		keyPrinciplesPage.validateLinkInfo(pageName);
	}


	@Then("^I Edit each Key Principal and Confirm$")
	public void edit_each_keyPrincipal_Confirm(DataTable KPValues) throws Throwable {

		List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
		keyPrinciplesPage.editEachKeyPrincipalAndConfirm(KPValuesToBeEntered);
	}

	@Then("^I should not be allowed to delete Key Principal$")
	public void i_should_not_be_allowed_to_delete_Key_Principal() throws Throwable {

	}

	@When("^I try to Delete the KeyPrincipal details$")
	public void i_try_to_Delete_the_KeyPrincipal_details() throws Throwable {

	}

	@Then("^the following \"([^\"]*)\" must be displayed\\.$")
	public void the_following_must_be_displayed(String arg1) throws Throwable {

	}

	@Then("^I should see the removed Key principal \"([^\"]*)\" top of the 'Removed key principals' section and I see the removed Key principal is displayed as 'Removed'$")
	public void i_should_see_the_removed_Key_principal_top_of_the_Removed_key_principals_section_and_I_see_the_removed_Key_principal_is_displayed_as_Removed(String KPToRemove) throws Throwable {
		keyPrinciplesPage.toVerifyIfKPIsRemoved(KPToRemove);
	}

	@When("^I click Cancel button on the Pop-up$")
	public void i_click_Cancel_button_on_the_Pop_up() throws Throwable {
		keyPrinciplesPage.buttonClick("Cancel");
	}

	@Then("^I see no KeyPrincipals \"([^\"]*)\" are removed from the Userinterface$")
	public void i_see_no_KeyPrincipals_are_removed_from_the_Userinterface(String KPName) throws Throwable {
		keyPrinciplesPage.toVerifyIfKPIsRemoved(KPName);
	}

	@When("^I Click on removed key principal$")
	public void i_Click_on_removed_key_principal() throws Throwable {

	}

	@Then("^I should see read only greyed out version of the data for that key principal$")
	public void i_should_see_read_only_greyed_out_version_of_the_data_for_that_key_principal() throws Throwable {

	}

	@Then("^the data displayed should be the data prior to the Customer selecting  remove the key principal$")
	public void the_data_displayed_should_be_the_data_prior_to_the_Customer_selecting_remove_the_key_principal() throws Throwable {
		keyPrinciplesPage.toValidatePreviousAndAfterData();
	}




	@When("^I click the 'Remove' hyperlink for \"([^\"]*)\" and make note of data's before removal$")
	public void i_click_the_Remove_hyperlink_for_and_make_note_of_data_s_before_removal(String KPName) throws Throwable {
		keyPrinciplesPage.toExpandKPDetails(KPName);
		keyPrinciplesPage.toValidateDetailsBeforeRemoval();
		keyPrinciplesPage.removeKPPopup(KPName);
	}

	@When("^I have entered value for all the mandatory fields and the fields have passed the validations$")
	public void i_have_entered_value_for_all_the_mandatory_fields_and_the_fields_have_passed_the_validations() throws Throwable {

	}

	@Then("^the system sends a request to Raven to match the key principals against companies house data$")
	public void the_system_sends_a_request_to_Raven_to_match_the_key_principals_against_companies_house_data() throws Throwable {

	}

	@When("^the decision returned from the service is 'Pass' and there are no execptions returned$")
	public void the_decision_returned_from_the_service_is_Pass_and_there_are_no_execptions_returned() throws Throwable {

	}

	@Then("^the responses are stored and application will proceed to financial information section$")
	public void the_responses_are_stored_and_application_will_proceed_to_financial_information_section() throws Throwable {

	}

	@When("^I Select key Principle and Click on Edit for that key principal$")
	public void i_Select_key_Principle_and_Click_on_Edit_for_that_key_principal() throws Throwable {
		keyPrinciplesPage.linkEditDetails.click();
	}

	@Then("^I should see following data attributes\\(fields\\) retrieved and displayed as per the wireframe$")
	public void i_should_see_following_data_attributes_fields_retrieved_and_displayed_as_per_the_wireframe() throws Throwable {
		keyPrinciplesPage.toValidateFieldsinEditKP();
		keyPrinciplesPage.receiveIncomeYes.click();
	}

	@When("^I Click Add a new Key Principal button$")
	public void i_Click_Add_a_new_Key_Principal_button() throws Throwable {
		keyPrinciplesPage.clickAddKPLink();
	}

	@Then("^I should see new data attributes\\(fields\\) displayed as per the wireframe$")
	public void i_should_see_new_data_attributes_fields_displayed_as_per_the_wireframe() throws Throwable {
		keyPrinciplesPage.receiveIncomeYes.click();
		keyPrinciplesPage.toValidateFieldsinNewKP();
	}

	@When("^I enter the current address move in date less than (\\d+) years$")
	public void i_enter_the_current_address_move_in_date_less_than_years(int arg1) throws Throwable {
		keyPrinciplesPage.selectMonth.click();
		keyPrinciplesPage.setDropDownValue("01");
		keyPrinciplesPage.selectYear.click();
		keyPrinciplesPage.setDropDownValue("2017");
	}

	@When("^I select Add Previous address$")
	public void i_select_Add_Previous_address() throws Throwable {
		keyPrinciplesPage.previousAddressLink.click();
	}

	@Then("^I should see following data attribute fields to be entered by the customer as per wireframe for previous address fields$")
	public void i_should_see_following_data_attribute_fields_to_be_entered_by_the_customer_as_per_wireframe_for_previous_address_fields() throws Throwable {
		keyPrinciplesPage.toValidateFieldsinPreviousAddress();
	}

	@When("^I enter the current address move in date more than (\\d+) years$")
	public void i_enter_the_current_address_move_in_date_more_than_years(int arg1) throws Throwable {
		keyPrinciplesPage.selectMonth.click();
		keyPrinciplesPage.setDropDownValue("01");
		keyPrinciplesPage.selectYear.click();
		keyPrinciplesPage.setDropDownValue("2010");
	}

	@Then("^I should not see Previous address link$")
	public void i_should_not_see_Previous_address_link() throws Throwable {
		if(helper.isElementPresent(keyPrinciplesPage.previousAddressLink, driver)) {
			helper.failTest("Previous address link is not displayed for current address", "Previous address link should be displayed for current address", "Previous address link is not displayed for current address", driver, testContext);
		}
	}

	@When("^I select a KeyPrincipal from list of Keyprincipals$")
	public void i_select_a_KeyPrincipal_from_list_of_Keyprincipals() throws Throwable {
		keyPrinciplesPage.toExpandKPDetailsBasedOnPosition(1);
	}

	@Then("^I should see the \"([^\"]*)\" displayed$")
	public void i_should_see_the_displayed(String Question) throws Throwable {
		keyPrinciplesPage.toValidateQuestionsDisplayed(Question);

	}

	@Then("^I should see the \"([^\"]*)\" displayed for soletrader$")
	public void i_should_see_the_displayed_for_soletrader(String Question) throws Throwable {
		keyPrinciplesPage.toValidateQuestionfor1KP(Question);

	}

	@Then("^initial status of KP CONFIRMED FLAG is unconfirmed$")
	public void initial_status_of_KP_CONFIRMED_FLAG_is_unconfirmed() throws Throwable {
		
		/*String AppID = String.valueOf(TestData.ApplicationID);
		String statusOfKPConfirmedFlag = DBDetails.statusOfKP(AppID,"QA_04");*/

	}

	@When("^I click add key principles$")
	public void i_click_add_key_principles() throws Throwable {
		keyPrinciplesPage.linkAddNewKP.click();
	}


	@When("^user enters invalid data for a particular field and user tabs to the next field and then enters valid data$")
	public void user_enters_invalid_data_for_a_particular_field_and_user_tabs_to_the_next_field_and_then_enters_valid_data(DataTable KPDetails) throws Throwable {
		java.util.List<Map<String, String>> KPPersonalDetails = KPDetails.asMaps(String.class, String.class);
		keyPrinciplesPage.KPValidationForInvalidEntry(KPPersonalDetails,"Tab");
	}

	@When("^I Click Edit for Key Principal and edit either \"([^\"]*)\" or \"([^\"]*)\" or \"([^\"]*)\" or \"([^\"]*)\" or \"([^\"]*)\" and then user enters \"([^\"]*)\"$")
	public void i_Click_Edit_for_Key_Principal_and_edit_either_or_or_or_or_and_then_user_enters(String DOB, String Surname, String UKIntCode, String AddressLine3, String AddressLine4, String ValidData) throws Throwable {
		keyPrinciplesPage.toExpandKPDetailsBasedOnPosition(1);
		keyPrinciplesPage.verifyEditKPLinkDisplayed();
		keyPrinciplesPage.KPValidationForEditKP(DOB, Surname, UKIntCode, AddressLine3, AddressLine4, ValidData);
	}

	@Then("^I Edit each of the Key Principals displayed and Confirm$")
	public void i_Edit_each_of_the_Key_Principals_displayed_and_Confirm(DataTable KPValues) throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		java.util.List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
		keyPrinciplesPage.editEachKeyPrincipalAndConfirm(KPValuesToBeEntered);
	}


	@Then("^since mandatory fields are not filled Confirm button should not be enabled and status of given key principal should be unconfirmed\\(!\\)$")
	public void since_mandatory_fields_are_not_filled_Confirm_button_should_not_be_enabled_and_status_of_given_key_principal_should_be_unconfirmed() throws Throwable {
		helper.addfullScreenCaptureToExtentReport(driver,testContext);
		keyPrinciplesPage.validateUnconfirmedMark();

	}

	@Then("^I click continue button$")
	public void i_click_continue_button() throws Throwable {
		keyPrinciplesPage.buttonClick("Continue");
	}

	@When("^I click Continue$")
	public void click_continue() throws Throwable {
		keyPrinciplesPage.continueButton.click();
	}

	@Then("^the industry experience flag should be set to \"([^\"]*)\"$")
	public void the_industry_experience_flag_should_be_set_to(String IndustryExperienceFlag) throws Throwable {

		/*String AppID = String.valueOf(TestData.ApplicationID);
		String IndustryExperience = DBDetails.KPindustryExp(AppID,"QA_04");
		if(IndustryExperience.equalsIgnoreCase(IndustryExperienceFlag))
		{
			System.out.println("Industry experience flag is set as per need");
		}

		{
			helper.failTest("Industry experience field", "Industry experience field should be displayed", "Industry experience field is not displayed", driver, testContext);
		}*/
	}
	@When("^I click on \"([^\"]*)\" for KP and enter the \"([^\"]*)\" details againts respective fields and verify the \"([^\"]*)\" an enter \"([^\"]*)\"$")
	public void i_click_on_for_KP_and_enter_the_details_againts_respective_fields_and_verify_the_an_enter(String action, String fieldValue, String errorMessage, String ammendedData, DataTable KPValues) throws Throwable {
		String fieldNameAndValue[] = fieldValue.split("[\\-]");
		String field = fieldNameAndValue[0];
		String value = fieldNameAndValue[1].trim();

		String kpDetailsBeforeEdit = helper.KPDetailsFromDB(testContext, driver, field);
		System.out.println("KP value after edit" + kpDetailsBeforeEdit);
		
		if(action.contains("Add"))
		{
			
			keyPrinciplesPage.clickAddKPLink();
			java.util.List<Map<String, String>> KPValuesToBeEntered = KPValues.asMaps(String.class, String.class);
			keyPrinciplesPage.toEnterKPValues(KPValuesToBeEntered);
		}
		else
		{
			
		keyPrinciplesPage.editKP1.click();
		}

		keyPrinciplesPage.toValidateEditKPFields(field, value, errorMessage, ammendedData);

		Thread.sleep(10000);

		String kpDetailsAfterEdit = helper.KPDetailsFromDB(testContext, driver, field);

		String UIData = keyPrinciplesPage.updateFieldValue;

		if (kpDetailsAfterEdit.contentEquals(UIData)) {
			System.out.println("DB details are updated properly");
		} else {
			helper.failTest("DB details are not updated properly" + UIData + "!!!!!!!" + kpDetailsAfterEdit, "DB details should be updated properly",
					"DB details are not updated properly", driver, testContext);
		}
	}
	
	@When("^I click on edit details for KP and enter the \"([^\"]*)\" details againts respective fields and verify the \"([^\"]*)\" an enter \"([^\"]*)\"$")
	public void i_click_on_edit_details_for_KP_and_enter_the_details_againts_respective_fields_and_verify_the_an_enter(String fieldValue, String errorMessage, String ammendedData) throws Throwable {

		String fieldNameAndValue[] = fieldValue.split("[\\-]");
		String field = fieldNameAndValue[0];
		String value = fieldNameAndValue[1].trim();

		String kpDetailsBeforeEdit = helper.KPDetailsFromDB(testContext, driver, field);
		System.out.println("KP value after edit" + kpDetailsBeforeEdit);

		keyPrinciplesPage.editKP1.click();


		keyPrinciplesPage.toValidateEditKPFields(field, value, errorMessage, ammendedData);

		Thread.sleep(10000);

		String kpDetailsAfterEdit = helper.KPDetailsFromDB(testContext, driver, field);

		String UIData = keyPrinciplesPage.updateFieldValue;

		if (kpDetailsAfterEdit.contentEquals(UIData)) {
			System.out.println("DB details are updated properly");
		} else {
			helper.failTest("DB details are not updated properly" + UIData + "!!!!!!!" + kpDetailsAfterEdit, "DB details should be updated properly",
					"DB details are not updated properly", driver, testContext);
		}
	}

	@And("^\"([^\"]*)\" displayed and validated$")
	public void Validate_WarnMessage(String expectedErrorMessage) throws Throwable {
		keyPrinciplesPage.WarningMessageValidation(expectedErrorMessage);
	}

	@Then("^I see confirm button is enabled$")
	public void confirm_butt_enabled() throws Throwable {
		keyPrinciplesPage.continueButton.isEnabled();
	}
	

	@Then("^I am displayed with question, Do you have (\\d+) or more years experience in this industry\\?$")
	public void i_am_displayed_with_question_Do_you_have_or_more_years_experience_in_this_industry(int arg1) throws Throwable {
	    if(keyPrinciplesPage.industryExperienceFlagHeader.isDisplayed())
	    {
	    	if(keyPrinciplesPage.industryExperienceQuestionSingleKP.isDisplayed())
	    	{
	    		System.out.println("Industry experience flag is displayed with appropriate question");
	    	}
	    }
	    else {
	    	helper.failTest("Pop up box should be displayed", "Pop up box is displayed", "Pop up box is not displayed", driver, testContext);
	    	}
	}

	@When("^I select \"([^\"]*)\" to the above mentioned question$")
	public void i_select_to_the_above_mentioned_question(String industryExpValue) throws Throwable {
		
	    keyPrinciplesPage.industryExpFlag(industryExpValue);
	}
	    

	@Then("^I Click on 'Edit' button for second KP$")
	public void i_Click_on_Edit_button_for_second_KP() throws Throwable {
		keyPrinciplesPage.editKP2.click();
	}
	
	@Then("^\"([^\"]*)\" is not displayed$")
	public void Validate_MaxInfo_ErrorMessage_notDisplayed(String expectedErrorMessage) throws Throwable {
		keyPrinciplesPage.ErrorMessageNotDisplayed(expectedErrorMessage);

	}
	
	@Then("^income from this business question is displayed$")
	public void income_question_displayed() throws Throwable {
		if(keyPrinciplesPage.incomeQ.isDisplayed()) {
			System.out.println("income from this business question is displayed");
		}else {
	    	helper.failTest("income from this business question is displayed", "income from this business question is displayed", "income from this business question is not displayed", driver, testContext);
	    	}	

	}
	
	@And("^owner of this property question is not displayed$")
	public void owner_question_not_displayed() throws Throwable {
		if(keyPrinciplesPage.ownerQ.isDisplayed()) {
			helper.failTest("owner of this property question is displayed", "owner of this property question is displayed", "owner of this property question is not displayed", driver, testContext);
		}else {
			System.out.println("owner of this property question is displayed");
	    	}	

	}
	
	@Then("^income from this business question is not displayed$")
	public void income_question_not_displayed() throws Throwable {
		if(keyPrinciplesPage.incomeQ.isDisplayed()) {
			helper.failTest("income from this business question is displayed", "income from this business question is displayed", "income from this business question is not displayed", driver, testContext);
		}else {
			System.out.println("income from this business question is displayed");	    	
	    	}	

	}
	
	@And("^owner of this property question is displayed$")
	public void owner_question_displayed() throws Throwable {
		if(keyPrinciplesPage.ownerQ.isDisplayed()) {
			System.out.println("owner of this property question is displayed");
		}else {
			helper.failTest("owner of this property question is displayed", "owner of this property question is displayed", "owner of this property question is not displayed", driver, testContext);
	    	}	

	}
	
	@When("^I choose 'Yes' for income from this business question$")
	public void income_yes() throws Throwable {
		if(keyPrinciplesPage.receiveIncomeYes.isDisplayed()) {
			keyPrinciplesPage.receiveIncomeYes.click();
		}else {
			helper.failTest("income from this business question is displayed", "income from this business question is displayed", "income from this business question is not displayed", driver, testContext);
    	}

	}
	
	@When("^I choose 'No' for income from this business question$")
	public void income_no() throws Throwable {
		if(keyPrinciplesPage.receiveIncomeNo.isDisplayed()) {
			keyPrinciplesPage.receiveIncomeNo.click();
		}else {
			helper.failTest("income from this business question should not be displayed", "income from this business question should not be displayed", "income from this business question should not be not displayed", driver, testContext);
    	}

	}
	
	@Then("^owner of this property question is displayed in edit screen$")
	public void owner_displayed_edit_screen() throws Throwable {
		if(keyPrinciplesPage.ownerQ.isDisplayed()) {
			System.out.println("owner of this property question is displayed");
		}else {
			helper.failTest("owner of this property question is displayed", "owner of this property question is displayed", "owner of this property question is not displayed", driver, testContext);
	    	}	

	}
	
	@Then("^owner of this property question is not displayed in edit screen$")
	public void owner_not_displayed_edit_screen() throws Throwable {
		if(keyPrinciplesPage.ownerQ.isDisplayed()) {
			helper.failTest("owner of this property question should not be displayed", "owner of this property question should not be displayed", "owner of this property question is displayed", driver, testContext);
		}else {
			System.out.println("owner of this property question is displayed");
	    	}	

	}
	
	@Then("^income from this business question is not displayed in edit screen$")
	public void income_not_displayed_edit_screen() throws Throwable {
		if(keyPrinciplesPage.incomeQ.isDisplayed()) {
			System.out.println("income from this business question is displayed");
		}else {
			helper.failTest("income from this business question is displayed", "income from this business question is displayed", "income from this business question is not displayed", driver, testContext);
	    	}	

	}


	@And("^I Edit each Key Principal and Confirm with Minimal details$")
	public void iEditEachKeyPrincipalAndConfirmWithMinimalDetails() throws Exception {

		keyPrinciplesPage.editMinimalDetailsAndSaveForRCE("04", "2014");
	}
}