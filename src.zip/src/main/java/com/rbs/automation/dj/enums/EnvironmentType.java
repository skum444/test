package com.rbs.automation.dj.enums;

public enum EnvironmentType {
	LOCAL,
	REMOTE,
	MOBILE,
}
