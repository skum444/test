package com.rbs.automation.dj.pages;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.helpers.OracleBBC;
import com.rbs.automation.dj.helpers.TestRun;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;


public class KeyPrinciplesPage {

    private WebDriver driver;
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private OracleBBC DBDetails = new OracleBBC();

    private WaitUtils waitUtils;
    public static String ErrorMessage;
    String FirstName;
    String Title;
    String MiddleName;
    String SurName;
    String DateofBirth;
    String Email;
    String KPnameBeforeRemoval;
    String dateofBirthBeforeRemoval;
    String eMailBeforeRemoval;
    String IntCodeBeforeRemoval;
    String PhoneNumberBeforeRemoval;
    String addressBeforeRemoval;
    String DateMovedInToResedentialAddressBeforeRemoval;
    String KPnameAfterRemoval;
    String dateofBirthAfterRemoval;
    String eMailAfterRemoval;
    String IntCodeAfterRemoval;
    String PhoneNumberAfterRemoval;
    String addressAfterRemoval;
    String DateMovedInToResedentialAddressAfterRemoval;
    String popUpHeader;
    String line1Text;
    String line2Text;
    String actualFieldvalue;
    String errorMessageValidation;
    WebElement UIFieldName;
    public String updateFieldValue;
    WebElement labelElement;
    WebElement labelElementField;


    // initialise the page elements when the class is instantiated
    public KeyPrinciplesPage(WebDriver driver, TestContext context) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
    }

    // Key Principles page Header

    @FindBy(how = How.XPATH, using = "//h1[contains(text(),'Your key principal')]")

    public WebElement txtHeader;

    // Left Panel
    @FindBy(how = How.XPATH, using = "//span[text()='Add key principal']")
    public WebElement linkAddNewKP;


    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Edit details')]")
    public WebElement linkEditDetails;


    @FindBy(how = How.XPATH, using = "//input[@name='firstName']")
    public WebElement firstName;

    @FindBy(how = How.XPATH, using = "//button[text()='Save']")
    public WebElement button;

    @FindBy(how = How.XPATH, using = "//h2[text()='Personal information']")
    public WebElement txtHeaderAddKPScreen;
    //To edit first KP details
    @FindBy(how = How.XPATH, using = "//div[@class='KeyPrincipalView_EditButton__ErJQV']")
    public WebElement editKP1;
    
    @FindBy(how = How.XPATH, using = "//div[@class='KeyPrincipalView_EditButton__G07_G']")
    public WebElement editKP2;

    @FindBy(how = How.XPATH, using = "//div[text()='Name']//following-sibling::div[1]")
    public WebElement txtName;

    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Add previous address')]")
    public WebElement previousAddressLink;

    @FindBy(how = How.XPATH, using = "//div[text()='Date Of Birth']//following-sibling::div[1]")
    public WebElement txtDOB;

    @FindBy(how = How.XPATH, using = "//div[text()='Email']//following-sibling::div[1]")
    public WebElement txtEmail;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'phone number')]//following-sibling::div[1]")
    public WebElement txtNumber;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Residential')]//following-sibling::div[1]")
    public WebElement txtAddress;
    
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Date moved in')]//following-sibling::div[1]/span")
    public WebElement txtDateMovedIn;

    @FindBy(how = How.XPATH, using ="(//*[contains(text(),'receive an income')]//..//following-sibling::div//..//*[local-name() = 'span'])[6]")
    public WebElement receiveIncomeNo;
    
    @FindBy(how = How.XPATH, using ="(//*[contains(text(),'receive an income')]//..//following-sibling::div//..//*[local-name() = 'span'])[3]")
    public WebElement receiveIncomeYes;

    // details fields

    @FindBy(how = How.XPATH, using = "//input[@placeholder='Please Select']")
    public WebElement titlePleaseSelect;

    @FindBy(how = How.XPATH, using = "//input[@placeholder='Select month']")
    public WebElement selectMonth;

    @FindBy(how = How.XPATH, using = "//input[@placeholder='Select year']")
    public WebElement selectYear;

    //Country dropdown
    @FindBy(how = How.XPATH, using = "//input[@placeholder='Please Select'][@value='United Kingdom']")
    public WebElement countryDropDown;
    //post code look up link
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Postcode look up')]")
    public WebElement postCodeLookup;

    @FindBy(how = How.NAME, using = "title")
    public WebElement title;

    @FindBy(how = How.NAME, using = "firstName")
    public WebElement inputFirstName;

    @FindBy(how = How.NAME, using = "middleName")
    public WebElement inputMiddleName;

    @FindBy(how = How.NAME, using = "lastName")
    public WebElement inputLastName;

    @FindBy(how = How.NAME, using = "dateOfBirth")
    public WebElement inputDateOfBirth;

    @FindBy(how = How.NAME, using = "emailAddress")
    public WebElement inputEmailAddress;
    
    @FindBy(how = How.XPATH, using = "//div[@class='zb-lookup zb-select mobileDropDown']")
    public WebElement intCode;

    @FindBy(how = How.NAME, using = "contactNumber")
    public WebElement inputMobileNumber;

    @FindBy(how = How.NAME, using = "country")
    public WebElement inputCountry;

    // Address fields
    //XPath to click second KP
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Key principal')]//following-sibling::section[2]")
    public WebElement secondKP;

    @FindBy(how = How.NAME, using = "houseNumber")
    public WebElement inputHouseNumber;

    @FindBy(how = How.NAME, using = "addressLine1")
    public WebElement inputAddressLine1;

    @FindBy(how = How.NAME, using = "addressLine2")
    public WebElement inputAddressLine2;

    @FindBy(how = How.NAME, using = "city")
    public WebElement inputCity;

    @FindBy(how = How.NAME, using = "postcode")
    public WebElement inputPostcode;

    @FindBy(how = How.XPATH, using = "//a[text()='Enter address manually']")
    public WebElement enterAddressManually;


    @FindBy(how = How.XPATH, using = "//h2[contains(text(),'Previous address')]")
    public WebElement previousAddressHeader;


    @FindBy(how = How.XPATH, using = "//img[@alt='Exit']")
    public WebElement btnExit;
    //address dropdown
    @FindBy(how = How.XPATH, using = "//input[@placeholder='Please Select'][@value='Your address']")
    public WebElement addressDropDown;


    @FindBy(how = How.XPATH, using = "//button[@id='btnContinue']")
    public WebElement continueButton;

    //Save button
    @FindBy(how = How.XPATH, using = "//button[@type='button'][contains(text(),'Save')]")
    public WebElement SaveButton;
    //XPath to find if Kp is displayed in left panel
    @FindBy(how = How.XPATH, using = "//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'TestFName')]")
    public WebElement KPIsPresent;
    //XPath to verify if warnign symbol is displayed adjacent to the added KP
    @FindBy(how = How.XPATH, using = "//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'TestFName')]//..//*[local-name() = 'svg']")
    public WebElement warningSymbolIsPresent;

    //XPath to validate text in remove key principal pop up
    @FindBy(how = How.XPATH, using = "//h2[@id='zb-modal-title-1']")
    public WebElement removeKeyPrincipalHeader;


    //XPath to validate text in remove key principal pop up
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'MaxActionsInfo_text__3kSPm')]")
    public WebElement MaxActionErrorMessage;



    //View Int Code Value
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Int. code')]//following-sibling::div[1]")
    public WebElement viewIntCode;

    //Get IntCode Default Value
    @FindBy(how = How.XPATH, using = "//div[@class='zb-lookup zb-select mobileDropDown']/div/div/input")
    public WebElement IntCodeValue;


    @FindBy(how = How.XPATH, using = "//*[@aria-label='Select country']/input")
    public WebElement editCountryCodeDropdown;


    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Learn more about key principals')]")
    public WebElement LearnMoreAboutKeyPrincipalsLink;
    
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Learn more about a key principal')]")
    public WebElement LearnMoreAboutKeyPrincipalsLink_ST;

    @FindBy(how = How.XPATH, using = "//h2[contains(text(),'Key principal')]")
    public WebElement infoHelpHeader;

    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::li")
    public List<WebElement> linkKPPointers;

    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::h2[1]")
    public WebElement linkKPWhatAreKeyPrincipals;

    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::p")
    public List<WebElement> linkKPinformation;
    
    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//p")
    public List<WebElement> linkKPinformation_ST;

    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::h2[2]")
    public WebElement linkKPInfoWeNeed;

    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::h3")
    public WebElement linkKPKeyPrincipalsAre;
    
    
    @FindBy(how = How.XPATH, using = "(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span")
    public List<WebElement> ST_linkKPPointers;

    @FindBy(how = How.XPATH, using = "//input[@name='lastName']")
    public WebElement editSurName;

    @FindBy(how = How.XPATH, using = "//input[@name='dateOfBirth']")
    public WebElement editDateOfBirth;

    @FindBy(how = How.XPATH, using = "//input[@name='emailAddress']")
    public WebElement editEmailAddress;

    @FindBy(how = How.XPATH, using = "//*[contains(text(), 'Key principal')]//..//*[local-name() = 'svg']")
    public List<WebElement> keyPrincipalsLink;


    @FindBy(how = How.XPATH, using = "//*[contains(text(), 'Key principal')]//..//*[local-name() = 'title']")
    public List<WebElement> keyPrincipalsMark;


    @FindBy(how = How.XPATH, using = "//button[text()='Save']")
    public WebElement saveButton;


    @FindBy(how = How.XPATH, using = "//div[@class='zb-lookup zb-select mobileDropDown']//child::input")
    public WebElement editIntCodeDropdown;

    @FindBy(how = How.XPATH, using = "//input[@name='contactNumber']")
    public WebElement editMobilePhoneNumber;



    @FindBy(how = How.XPATH, using = "//input[@name='houseNumber']")
    public WebElement editAddressLine1;


    @FindBy(how = How.XPATH, using = "//input[@name='addressLine1']")
    public WebElement editAddressLine2;
    

    @FindBy(how = How.XPATH, using = "//h2[contains(text(),'Industry experience')]")
    public WebElement industryExperienceFlagHeader;
    
    @FindBy(how = How.XPATH, using = "//p[contains(text(),'Do you have 3 or more years experience in this industry?')]")
    public WebElement industryExperienceQuestionSingleKP;

    @FindBy(how = How.XPATH, using = "//*[contains(text(),'Your information')]//..//following::div[7]")
    public WebElement incompleteInfoHeader;
    
    @FindBy(how = How.XPATH, using = "//*[contains(text(),'Your information')]//..//following::div[8]")
    public WebElement incompleteInfoErrMess;
    
    @FindBy(how = How.XPATH, using = "//*[text()='Does this key principal receive an income from this business?']")
    public WebElement incomeQ;
    
    @FindBy(how = How.XPATH, using = "//*[text()='Is this key principal the owner of this property (i.e owns it or has mortgage on it)?']")
    public WebElement ownerQ;
    

    //To validate labels
    private void labelXPath(String labelName) throws Exception {
        try {
        	if(labelName.contains("previous"))
        	{
        		String label[] = labelName.split(":");
        		System.out.println("!!!!!!!!!!!!!!!!!!!!!!"+label[0]);
        		System.out.println("!!!!!!!!!!!!!!!!!!!!!!"+label[1]);
        		String previousAdress = label[1];
        		labelElement = driver.findElement(By.xpath("//label[@for='" + previousAdress + "'][1]"));
        	}
        	else {
            labelElement = driver.findElement(By.xpath("//label[@for='" + labelName + "']"));
        	}
        } catch (Exception ex) {
        	
        	helper.failTest(labelName+"field", labelName+"should be displayed", labelName+"is not displayed", driver, testContext);
            
        }
    }
    
    
    public void industryExpFlag(String Value) throws Exception {
    	try {
    		WebElement industryExpFlag = driver.findElement(By.xpath("//label[@class='zb-input-label-name'][@aria-label='"+Value+"']"));
    		
    		industryExpFlag.click();
    		
    		WebElement buttonClick = driver.findElement(By.xpath("//div[@class='IndustryExperience_continueButton__1Im86']//button[@type='button'][contains(text(),'Continue')]"));
    		
    		buttonClick.click();
    	}
    	catch(Exception ex) {
    		helper.failTest("Industry Experience Flag", "Industry experience flag value should be selected", "Industry experience flag value is not selected", driver, testContext);
    	}
    }

    //To Validate box adjacent to labels
    private void labelfollowingField(String labelName) throws Exception {
        try {
            // Select option
            labelElementField = driver.findElement(By.xpath("//input[@name='" + labelName + "']"));

        } catch (Exception ex) {
        	helper.failTest("Drop down field", "Drop down value should be selected", "Drop down value is not selected", driver, testContext);
        }
    }

    private void labelfollowingdropDown(String labelName) throws Exception {
        try {
            // Select option
            labelElementField = driver.findElement(By.xpath("//input[@name='" + labelName + "']"));

        } catch (Exception ex) {
        	helper.failTest("Drop down field", "Drop down value should be selected", "Drop down value is not selected", driver, testContext);
        }
    }

    // Return Number of KPs
    public int returnNumberOfKPs() {

        return driver.findElements(By.xpath("//a[text()='Remove']")).size() + 1;
        // (//div[@class='SideBarItem_container__3ZGMJ'])[1]/div[2]

    }


    // Set Date Moved in
    public void setDropDownValue(String textToSelect) throws Exception {
        //titlePleaseSelect.click();
        if(!(textToSelect.equals(""))) {

            try {
                // Select option
                WebElement option = driver.findElement(By.xpath("//li[@role='option']/div[contains(text(),'" + textToSelect + "')]"));
                option.click();
            } catch (org.openqa.selenium.StaleElementReferenceException ex) {
            	helper.failTest("Drop down field", "Drop down value should be selected", "Drop down value is not selected", driver, testContext);
            }
        }
    }

    public void validateIfKPIsAdded(String KPName) throws Exception {


        try {
            // Select option
            //WebElement KPNameIsDisplayed = driver.findElement(By.xpath("//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'"+KPName+"')]"));
            WebElement KPNameIsDisplayed = driver.findElement(By.xpath("//div[contains(text(),'"+KPName+"')]"));
            KPNameIsDisplayed.isDisplayed();
            System.out.println("Newly added key principal is displayed in the screen");
            if(KPNameIsDisplayed.isDisplayed()==true)
            {
                WebElement WarningSymbolIsDisplayed = driver.findElement(By.xpath("//div[contains(text(),'"+KPName+"')]//..//*[local-name() = 'svg']"));
                WarningSymbolIsDisplayed.isDisplayed();
                System.out.println("Warning symbol is displayed adjacent to the newly added key principal");
            }else{
                helper.failTest("Warning Symbol should be displayed", "Warning Symbol should be displayed",
                        "Warning Symbol was not displayed", driver, testContext);
            }
        } catch (Exception ex) {
        	helper.failTest("Addition of new KP", "Newly added KP should be displayed in the screen", "Newly added KP is not displayed in the screen", driver, testContext);
        }

    }
    public void removeKP(String textToSelect) throws Exception {

        if (!(textToSelect.equals(""))) {

            try {
                // Select option
                WebElement option = driver.findElement(By.xpath("//li[@role='option']/div[contains(text(),'" + textToSelect + "')]"));
                option.click();
            } catch (org.openqa.selenium.StaleElementReferenceException ex) {
            	helper.failTest("Remove KP", "Remove KP option should be displayed", "Remove KP option is not displayed", driver, testContext);
            }
        }
    }

    public void validateIfKPIsConfirmed(String KPName) throws Exception {


        try {
            // Select option
            WebElement KPNameIsDisplayed = driver.findElement(By.xpath("//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'" + KPName + "')]"));
            KPNameIsDisplayed.isDisplayed();
            System.out.println("Newly added key principal is displayed in the screen");
            if (KPNameIsDisplayed.isDisplayed() == true) {
                WebElement ConfirmSymbolIsDisplayed = driver.findElement(By.xpath("//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'" + KPName + "')]//..//*[local-name() = 'svg']"));
                ConfirmSymbolIsDisplayed.isDisplayed();
                if (ConfirmSymbolIsDisplayed.getText().equalsIgnoreCase("confirmation-small")) {
                    System.out.println("Confirm symbol is displayed adjacent to the newly added key principal");
                } else {
                    System.out.println("Confirm symbol is not displayed adjacent to the newly added key principal");
                }
            }
        } catch (Exception ex) {
        	helper.failTest("KP confirmation", "KP confirmed flag should be displayed", "KP confirmed flag is not displayed", driver, testContext);
        }


    }

    public void toVerifyIfKPIsRemoved(String KPName) throws Exception {


        try {
            // Remove link
            WebElement KPNameRemoval = driver.findElement(By.xpath("//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__3_qYl']//div[contains(text(),'"+KPName+"')]/../..//a"));
            KPNameRemoval.click();
            helper.addfullScreenCaptureToExtentReport(driver,testContext);
            buttonClick("Remove");

        } catch (Exception ex) {
            // Select option
            WebElement removalSection = driver.findElement(By.xpath("//span[contains(text(),\"Removed key principals\")]"));
            removalSection.isDisplayed();

            if (removalSection.isDisplayed() == true) {
                WebElement KPIsDisplayed = driver.findElement(By.xpath("//h2[contains(text()," + KPName + ")]//i[contains(text(),\"Removed\")]"));
                KPIsDisplayed.isDisplayed();
                if (KPIsDisplayed.isDisplayed() == true) {
                    System.out.println("KP name" + KPName + "is displayed in the removal section");
                } else {
                    System.out.println("KP name" + KPName + "is not displayed in the removal section");
                }
            }
            helper.failTest("Remove KP", "KP should be removed", "KP is not removed", driver, testContext);	
        }
    }

    //To validate KP details before KP removal and after KP removal

    public void toValidateDetailsbeforeRemoval() throws Exception {
        try {
            List<WebElement> KPDetails = driver.findElements(By.xpath("//div[@class='KeyPrincipalViewRow_info__2zHMj']"));

            WebElement KPName = KPDetails.get(0);
            String KPname = KPName.getText();
            WebElement dateOfBirth = KPDetails.get(1);
            String dateofBirth = dateOfBirth.getText();
            WebElement EMail = KPDetails.get(2);
            String eMail = EMail.getText();
            WebElement intCode = KPDetails.get(3);
            String IntCode = intCode.getText();
            WebElement phoneNumber = KPDetails.get(4);
            String PhoneNumber = phoneNumber.getText();
            WebElement Address = KPDetails.get(5);
            String address = Address.getText();
            WebElement dateMovedInToResedentialAddress = KPDetails.get(6);
            String DateMovedInToResedentialAddress = dateMovedInToResedentialAddress.getText();

            System.out.println("!!" + KPname + dateofBirth + eMail + IntCode + PhoneNumber + address + DateMovedInToResedentialAddress);


        } catch (Exception e) {
        	helper.failTest("Fetch details", "KP details should be fetched successfully", "KP details is not fetched successfully", driver, testContext);
        }
    }



    

    
    public void toValidateDetailsBeforeRemoval() throws Exception {
        try {
           
            List<WebElement> KPDetails = driver.findElements(By.xpath("//article[@id='kp_view']//div[@class='KeyPrincipalViewRow_title__2BMBE']"));

            KPnameBeforeRemoval = KPDetails.get(0).getText();
            System.out.println("!!!!!!" + KPnameBeforeRemoval);
            dateofBirthBeforeRemoval = KPDetails.get(1).getText();
            eMailBeforeRemoval = KPDetails.get(2).getText();
            IntCodeBeforeRemoval = KPDetails.get(3).getText();
            PhoneNumberBeforeRemoval = KPDetails.get(4).getText();
            addressBeforeRemoval = KPDetails.get(5).getText();
            DateMovedInToResedentialAddressBeforeRemoval = KPDetails.get(6).getText();



        } catch (Exception e) {
        	helper.failTest("Fetch details", "KP details should be fetched successfully", "KP details is not fetched successfully", driver, testContext);
        }
    }

    public void toValidateDetailsAfterRemoval() throws Exception {
        try {

            List<WebElement> KPDetails = driver.findElements(By.xpath("//article[@id='kp_view']//div[@class='KeyPrincipalViewRow_info__p_h5L']"));

            KPnameAfterRemoval = KPDetails.get(0).getText();
            dateofBirthAfterRemoval = KPDetails.get(1).getText();
            eMailAfterRemoval = KPDetails.get(2).getText();
            IntCodeAfterRemoval = KPDetails.get(3).getText();
            PhoneNumberAfterRemoval = KPDetails.get(4).getText();
            addressAfterRemoval = KPDetails.get(5).getText();
            DateMovedInToResedentialAddressAfterRemoval = KPDetails.get(6).getText();


        } catch (Exception e) {
        	helper.failTest("Fetch details", "KP details should be fetched successfully", "KP details is not fetched successfully", driver, testContext);
        }
    }

    public void toValidatePreviousAndAfterData() throws Exception {
    	try {
        toValidateDetailsAfterRemoval();
        if (KPnameBeforeRemoval.equals(KPnameAfterRemoval)) {
            System.out.println(KPnameBeforeRemoval + "!!!!!!" + KPnameAfterRemoval);
            System.out.print("KP Name details are the same before and after removal");
        } else {
            System.out.print("KP Name details are not the same before and after removal");
        }
        if (dateofBirthBeforeRemoval.equals(dateofBirthAfterRemoval)) {
            System.out.print("KP Date of Birth details are the same before and after removal");
        } else {
            System.out.print("KP Date of Birth details are not the same before and after removal");
        }
        if (eMailBeforeRemoval.equals(eMailAfterRemoval)) {
            System.out.print("KP eMail details are the same before and after removal");
        } else {
            System.out.print("KP eMail details are not the same before and after removal");
        }
        if (IntCodeBeforeRemoval.equals(IntCodeAfterRemoval)) {
            System.out.print("KP intCode details are the same before and after removal");
        } else {
            System.out.print("KP intCode details are not the same before and after removal");
        }
        if (PhoneNumberBeforeRemoval.equals(PhoneNumberAfterRemoval)) {
            System.out.print("KP phone number details are the same before and after removal");
        } else {
            System.out.print("KP phone number details are not the same before and after removal");
        }
        if (addressBeforeRemoval.equals(addressAfterRemoval)) {
            System.out.print("KP address details are the same before and after removal");
        } else {
            System.out.print("KP address details are not the same before and after removal");
        }
        if (DateMovedInToResedentialAddressBeforeRemoval.equals(DateMovedInToResedentialAddressAfterRemoval)) {
            System.out.print("KP date moved it to resedential address details are the same before and after removal");
        } else {
            System.out.print("KP date moved it to resedential address details are not the same before and after removal");
        }
    	}
    	catch(Exception ex) {
    		helper.failTest("Match KP details", "KP details should be matched successfully", "KP details is not matched successfully", driver, testContext);
    	}

    }
    


    public void toExpandKPDetails(String KPName) throws Exception {

        try {
            // Select option
            WebElement KPNameIsDisplayed = driver.findElement(By.xpath("//div[@class='KeyPrincipalsSideBar_KeyPrincipalsSideBar__8GGoo']//div[contains(text(),'" + KPName + "')]"));
            KPNameIsDisplayed.click();


        } catch (Exception ex) {
        	helper.failTest("To expand KP details", "KP details should be expanded successfully", "KP details is not expanded successfully", driver, testContext);
        }

    }

    //To click KP based on position

    public void toExpandKPDetailsBasedOnPosition(int KPNun) throws Exception {


        try {
            List<WebElement> KPName = driver.findElements(By.xpath("//div[@class='SideBarItem_text__31SO_']"));

            WebElement respectiveKP = KPName.get(KPNun);

            respectiveKP.click();


        } catch (Exception ex) {
        	helper.failTest("To expand KP details", "KP details should be expanded successfully", "KP details is not expanded successfully", driver, testContext);
        }

    }

    public void toValidateQuestionsDisplayed(String Questions) throws Exception{
       try {
    	String[] expectedText = Questions.split("[\\?]");


        String line1Expected = expectedText[0]+"?";

        String line2Expected = expectedText[1]+"?";
        //to fill with actual XPath in QA01
        WebElement KPNameRemoval = driver.findElement(By.xpath(""));
        String actualQuestion1 = KPNameRemoval.getText();
        String actualQuestion2 = KPNameRemoval.getText();

        if(!(line1Expected.equalsIgnoreCase("actualQuestion1")))
        {
            helper.failTest(actualQuestion1 +"is not displayed", actualQuestion1 + "should be displayed",
                    actualQuestion1 +"is not displayed", driver, testContext);
        }
        if(!(line2Expected.equalsIgnoreCase("actualQuestion2")))
        {
            helper.failTest(actualQuestion2 +"is not displayed", actualQuestion2 + "should be displayed",
                    actualQuestion2 +"is not displayed", driver, testContext);
        }
       }
       catch(Exception ex)
       {
    	   helper.failTest("To validte questions displayed", "Questions should be displayed", "Questions are not displayed", driver, testContext);
       }


    }

    public void toValidateQuestionfor1KP(String Questions) throws Exception{

        //to fill with actual XPath in QA01
        WebElement KPNameRemoval = driver.findElement(By.xpath(""));
        String actualQuestion1 = KPNameRemoval.getText();


        if(Questions.equalsIgnoreCase("actualQuestion1"))
        {
            helper.failTest(actualQuestion1 +"is not displayed", actualQuestion1 + "should be displayed",
                    actualQuestion1 +"is not displayed", driver, testContext);
        }

    }

    public void removeKPPopup(String KPName) throws Exception {


        try {
            // Remove link
            WebElement KPNameRemoval = driver.findElement(By.xpath("//div[contains(text(),'"+KPName+"')]/../..//a"));
            KPNameRemoval.click();
            helper.addfullScreenCaptureToExtentReport(driver,testContext);
            String EntityType = EntityType(testContext);

            if(EntityType.contains("SoleTrader")){
                System.out.println("Remove KP link is not present for KP if KP's entity is sole trader");
            }

        } catch (Exception ex) {
            // Select option
        	helper.failTest("KP Element to be removed should be displayed", "KP Element to be removed should be displayed", "KP Element to be removed "+KPName+" is not displayed", driver, testContext);

        }

    }
    private String EntityType(TestContext context)
    {
        String EntityTypet = String.valueOf(context.scenarioContext.getContext(TestData.EnityType));
        System.out.println(EntityTypet);
        return EntityTypet;
    }

    public void buttonClick(String buttonText) throws Exception{


        try {
            // Select option
            WebElement option = driver.findElement(By.xpath("//button[@type='button'][contains(text(),'"+buttonText+"')]"));
            option.click();
        } catch (Exception ex) {
            ex.printStackTrace();
            helper.failTest(buttonText+" is not displayed", buttonText+" should be displayed", buttonText+" is not displayed", driver, testContext);
        }

    }


    private void errorMessageValidation(String fieldToValidate) throws Exception {

        try {
            // Select option
            WebElement option = driver.findElement(By.xpath("//label[@for='"+fieldToValidate+"']//*[local-name() = 'svg']"));
            Boolean result = option.isDisplayed();
            System.out.println(result);
            helper.addfullScreenCaptureToExtentReport(driver, testContext);
            String actualErrorMessage = option.getText();
            if(result==true) {

                String Message = "Expected error message is displayed for field:";
                String failMessage = "Expected error message is not displayed for field:";

                //System.out.println(ErrorMessage);

                if(fieldToValidate.contains("title")) {
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultTitle = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultTitle = failMessage+fieldToValidate;
                    }

                }
                if(fieldToValidate.contains("firstName")) {

                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultFirstName = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultFirstName = failMessage+fieldToValidate;
                    }
                }
                if(fieldToValidate.contains("lastName")) {

                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultLastName = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultLastName = failMessage+fieldToValidate;
                    }
                }
                if(fieldToValidate.contains("dateOfBirth")) {

                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultDOB = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultDOB = failMessage+fieldToValidate;
                    }
                }
                if(fieldToValidate.contains("emailAddress")) {
                    System.out.println("!!!!!!!!"+ErrorMessage);
                    System.out.println("!!!!!!!!"+actualErrorMessage);
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultEmailAddress = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultEmailAddress = failMessage+fieldToValidate;
                    }
                }
                if(fieldToValidate.contains("postcode")) {
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {


                        helper.FieldValidationResultTitle = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultTitle = failMessage+fieldToValidate;

                        
                    }

                }
                if(fieldToValidate.contains("contactNumber")) {
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultTitle = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultTitle = failMessage+fieldToValidate;

                    }

                }
                if(fieldToValidate.contains("houseNumber")) {
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultTitle = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultTitle = failMessage+fieldToValidate;

                    }


                }
                if(fieldToValidate.contains("addressLine1")) {
                    if(ErrorMessage.equalsIgnoreCase(actualErrorMessage)) {

                        helper.FieldValidationResultTitle = Message+fieldToValidate;
                    }
                    else{
                        helper.FieldValidationResultTitle = failMessage+fieldToValidate;

                    }

                }

            }
            else
            {
                System.out.println("Expected error message is not displayed for field:"+fieldToValidate);

            }

        } catch (Exception ex) {
        	helper.failTest("Error messgae validation", "Appropriate error messages should be displayed", "Appropriate error message is not displayed", driver, testContext);

        }

    }

    public int returnNumberOfRemovedKPs() {

        return driver.findElements(By.xpath("//span[text()='Removed']")).size() + 1;

        // (//div[@class='SideBarItem_container__3ZGMJ'])[1]/div[2]

    }

    public void verifyAddKPLinkNotDisplayed() throws Exception {

        if(helper.isElementPresent(linkAddNewKP, driver))
            helper.failTest("Add Key Principle link page is not displayed", "Add Key Principle link is not displayed","Add Key Principle link IS displayed", driver, testContext);
        
        helper.addfullScreenCaptureToExtentReport(driver, testContext);


    }


    public void verifyEditKPLinkDisplayed() throws Exception {

        if(!helper.isElementPresent(linkEditDetails, driver))
            helper.failTest("Add Key Principle link page is not displayed", "Add Key Principle link is not displayed","Add Key Principle link IS displayed", driver, testContext);

        linkEditDetails.click();

        if(!helper.isElementPresent(inputFirstName, driver))
            helper.failTest("Add Key Principle edit details not working", "Add Key Principle edit details not working","edit details not working", driver, testContext);

    }


    public void verifyAddKPScreenDisplayed() throws Exception {

        if(!helper.isElementPresent(txtHeaderAddKPScreen, driver))
            helper.failTest("Add Key Principle page is not displayed", "Add Key Principle link is not displayed","Add Key Principle link IS displayed", driver, testContext);


    }



    public void clickKPToEdit(int kpPosition) {


        driver.findElement(By.xpath("(//div[@class='SideBarItem_container__3ZGMJ'])[" + kpPosition + "]/div[2]"))
                .click();
    }


    public void KPValidation(List<Map<String, String>> KPValidationList,String actionToPerform) throws Exception {

        int itemCount = KPValidationList.size();
        for(int i=0;i<itemCount;i++) {
            String Title = KPValidationList.get(i).get("Title");
            String FirstName = KPValidationList.get(i).get("First name");
            String MiddleName = KPValidationList.get(i).get("Middle name");
            String SurName = KPValidationList.get(i).get("Surname");
            String DateofBirth = KPValidationList.get(i).get("DateofBirth");
            String Email = KPValidationList.get(i).get("Email");
            ErrorMessage = KPValidationList.get(i).get("ErrorMessage");
            String postCode = KPValidationList.get(i).get("PostCode");
            String monthValue = KPValidationList.get(i).get("Month");
            String yearValue = KPValidationList.get(i).get("Year");

            titlePleaseSelect.click();
            setDropDownValue(Title);
            inputFirstName.sendKeys(FirstName);
            inputMiddleName.sendKeys(MiddleName);
            inputLastName.sendKeys(SurName);
            inputDateOfBirth.sendKeys(DateofBirth);
            inputEmailAddress.sendKeys(Email);
            inputPostcode.sendKeys(postCode);
            selectMonth.click();
            setDropDownValue(monthValue);
            selectYear.click();
            setDropDownValue(yearValue);

            if(actionToPerform.contains("Save")) {
                //buttonClick("Save");
                saveButton.click();
            }

            if (Title.equals("")) {
                errorMessageValidation("title");
            }


            if (FirstName.equals("")) {
                System.out.println("Inside FirstName");
                errorMessageValidation("firstName");
            }


            if (MiddleName.equals("")) {
                System.out.println("KP does not have middle name");
            }


            if (SurName.equals("")) {
                errorMessageValidation("lastName");
            }


            if (DateofBirth.equals("")) {
                errorMessageValidation("dateOfBirth");
            }


            if (Email.equals("")) {
                errorMessageValidation("emailAddress");
            }

            buttonClick("Cancel");
            clickAddKPLink();
        }
    }

    public void KPValidationForInvalidEntry(List<Map<String, String>> KPValidationList,String actionToPerform) throws Exception {

        int itemCount = KPValidationList.size();
        for(int i=0;i<itemCount;i++) {
            String Title = KPValidationList.get(i).get("Title");
            String FirstName = KPValidationList.get(i).get("First name");
            String MiddleName = KPValidationList.get(i).get("Middle name");
            String SurName = KPValidationList.get(i).get("Surname");
            String DateofBirth = KPValidationList.get(i).get("DateofBirth");
            String Email = KPValidationList.get(i).get("Email");
            ErrorMessage = KPValidationList.get(i).get("ErrorMessage");
            String postCode = KPValidationList.get(i).get("PostCode");
            String monthValue = KPValidationList.get(i).get("Month");
            String yearValue = KPValidationList.get(i).get("Year");
            String ammendedData = KPValidationList.get(i).get("ValidData");
            titlePleaseSelect.click();
            setDropDownValue(Title);
            inputFirstName.sendKeys(FirstName);
            inputMiddleName.sendKeys(MiddleName);
            inputLastName.sendKeys(SurName);
            inputDateOfBirth.sendKeys(DateofBirth);
            inputEmailAddress.sendKeys(Email);
            inputPostcode.sendKeys(postCode);
            selectMonth.click();
            setDropDownValue(monthValue);
            selectYear.click();
            setDropDownValue(yearValue);

            if(actionToPerform.contains("Save")) {
                buttonClick("Save");
            }
            System.out.println(ErrorMessage);
            if(ErrorMessage.contains("valid email address"))
            {
                errorMessageValidation("emailAddress");
                inputEmailAddress.clear();
                inputEmailAddress.sendKeys(ammendedData);
                inputPostcode.clear();
            }
            if(ErrorMessage.contains("valid postcode"))
            {
                errorMessageValidation("postcode");
                inputPostcode.clear();
                inputPostcode.sendKeys(ammendedData);
                buttonClick("Find address");
            }
            if (ErrorMessage.contains("first name")) {
                errorMessageValidation("firstName");
                inputFirstName.sendKeys(ammendedData);
                inputMiddleName.clear();
                inputMiddleName.sendKeys(MiddleName);

            }

        }
    }


    public void KPValidationForEditKP(String DOB, String Surname, String UKIntCode, String AddressLine3, String AddressLine4, String ValidData) throws Exception {
        if(Surname.contains("")){
            inputLastName.clear();
            inputLastName.sendKeys(Keys.TAB);
            //inputDateOfBirth.clear();
            //inputDateOfBirth.sendKeys("04/07/1992");
            //inputLastName.sendKeys(ValidData);

        }
        if((AddressLine3.contains(""))&&(AddressLine4.contains("")))
        {
			/*JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", inputHouseNumber);*/

            inputHouseNumber.clear();
            /*inputHouseNumber.sendKeys(Keys.TAB);*/
            Thread.sleep(7000);

            //inputAddressLine1.click();
            inputAddressLine1.clear();

        }

    }

    public void toEnterKPValues(List<Map<String, String>> KPValues) throws Exception {
        Title = KPValues.get(0).get("Title");
        FirstName = KPValues.get(0).get("First name");
        MiddleName = KPValues.get(0).get("Middle name");
        SurName = KPValues.get(0).get("Surname");
        DateofBirth = KPValues.get(0).get("DateofBirth");
        Email = KPValues.get(0).get("Email");

        titlePleaseSelect.click();
        setDropDownValue(Title);
        inputFirstName.sendKeys(FirstName);
        inputMiddleName.sendKeys(MiddleName);
        inputLastName.sendKeys(SurName);
        inputDateOfBirth.sendKeys(DateofBirth);
        inputEmailAddress.sendKeys(Email);
        intCode.click();
        setDropDownValue(KPValues.get(0).get("IntCode"));
        inputMobileNumber.sendKeys(KPValues.get(0).get("MobileNumber"));
        //inputPostcode.sendKeys("CH42 5NN");
        //buttonClick("Find address");
        enterAddressManually.click();
        inputHouseNumber.sendKeys("2");
        inputAddressLine1.sendKeys("ABC");
        inputCity.sendKeys("DEF");
        inputPostcode.sendKeys("CH42 5NN");
        selectMonth.click();
        setDropDownValue("01");
        selectYear.click();
        setDropDownValue("2007");
        receiveIncomeNo.click();
        helper.addfullScreenCaptureToExtentReport(driver, testContext);
    }

    public void PersonalDetails() throws Exception{
        titlePleaseSelect.click();
        setDropDownValue("Mr");

        if(inputFirstName.getText().contains("")) {
            inputFirstName.sendKeys("Nandini");
        }
        if(inputMiddleName.getText().contains("")) {
            inputMiddleName.sendKeys("Ravi");
        }
        if(inputLastName.getText().contains("")) {
            inputLastName.sendKeys("Ravi");
        }
        if(inputDateOfBirth.getText().contains("")) {
            inputDateOfBirth.sendKeys("04/07/1992");
        }
        if(inputEmailAddress.getText().contains("")) {
            inputEmailAddress.sendKeys("nandini.ravi@rbs.co.uk");
        }
        intCode.click();
        setDropDownValue("+44");
        if(inputMobileNumber.getText().contains("")) {
            inputMobileNumber.sendKeys("7448188832");
        }
    }

    public void toVerifyIfKPIsAdded() throws Exception{


        WebElement button = driver.findElement(By.xpath("//button[text()='Save']"));
        button.click();
        validateIfKPIsAdded(FirstName);
        String FullName = Title+' '+FirstName+' '+MiddleName+' '+SurName;
        //DBDetails.statusOfKP(FullName,"QA_04");
    }


    public void toVerifyIfKPIsConfirmed() throws Exception{
        validateIfKPIsConfirmed(FirstName);

    }


    public void toRemoveKPAdded() throws Exception {
        removeKP(FirstName);

    }
    public void clickAddKPLink() throws Exception {

        if(helper.isElementPresent(linkAddNewKP, driver))
            linkAddNewKP.click();

    }

    public void toEnterValueInPostCode(List<Map<String, String>> postCodeValue) throws Exception {
        String postCode = postCodeValue.get(0).get("PostCode");

        inputPostcode.getText();
        if(inputPostcode.getText()!=null) {
            inputPostcode.clear();
        }
        inputPostcode.sendKeys(postCode);
        helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
    }

    public void enterAddressManually()
    {	inputHouseNumber.clear();
        inputHouseNumber.sendKeys("2");
        inputAddressLine1.clear();
        inputAddressLine1.sendKeys("ABC");
        inputCity.clear();
        inputCity.sendKeys("DEF");
        inputPostcode.clear();
        inputPostcode.sendKeys("ch0034");

    }
    public void toEnterValuesInFields(List<Map<String, String>> AddressFields) throws Exception {
        String buildingName = AddressFields.get(0).get("Building name");
        String AddressLine1 = AddressFields.get(0).get("Address line 1");
        String AddressLine2 = AddressFields.get(0).get("Address line 2");
        String City = AddressFields.get(0).get("City");
        String Postcode	= AddressFields.get(0).get("Postcode");
        if(!(inputHouseNumber.getText().equals("")))
        {
            inputHouseNumber.clear();
        }
        inputHouseNumber.sendKeys(buildingName);
        if(!(inputAddressLine1.getText().equals("")))
        {
            inputAddressLine1.clear();
        }
        inputAddressLine1.sendKeys(AddressLine1);
        if(!(inputAddressLine2.getText().equals("")))
        {
            inputAddressLine2.clear();
        }
        inputAddressLine2.sendKeys(AddressLine2);
        if(!(inputCity.getText().equals("")))
        {
            inputCity.clear();
        }
        inputCity.sendKeys(City);
        if(!(inputPostcode.getText().equals("")))
        {
            inputPostcode.clear();
        }
        inputPostcode.sendKeys(Postcode);
        PersonalDetails();
        helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
    }

    public void postCodeFieldValidation() throws Exception
    {
        ErrorMessage = "Enter a valid postcode";
        errorMessageValidation("postcode");
    }


    public void toValidatePopUpBox(String hyperlinkText)
    {
        String[] expectedText = hyperlinkText.split("[.\\?]");

        String line1Expected = expectedText[1].trim();
        line1Expected = line1Expected+".";

        String line2Expected = expectedText[2].trim();
        line2Expected = line2Expected+"?";

        List<WebElement> poupBoxHeader = driver.findElements(By.xpath("(//h2[@class='zb-modal-card-title'])[2]"));

        popUpHeader = poupBoxHeader.get(0).getText();

        //List<WebElement> LineText = driver.findElements(By.xpath("//div[@class='RemoveKeyPrincipal_removeText__qA7B1']//p"));
      
        List<WebElement> LineText = driver.findElements(By.xpath("//h2[contains(text(),'Remove Key Principal')]//..//..//*[local-name() = 'p']"));

        line1Text = LineText.get(0).getText();

        line2Text = LineText.get(1).getText();

        if(expectedText[0].equalsIgnoreCase(popUpHeader)){
            System.out.println("Header text is displayed as per wireframe");
        }
        else
        {
            System.out.println("Header text is not displayed as per wireframe");
        }

        if(line1Expected.equalsIgnoreCase(line1Text)){
            System.out.println("Popup line 1 text is displayed as per wireframe");
        }
        else
        {
            System.out.println("Popup line 1 text is not displayed as per wireframe");
        }

        if(line2Expected.equalsIgnoreCase(line2Text)){
            System.out.println("Popup line 2 text is displayed as per wireframe");
        }
        else
        {
            System.out.println("Popup line 2 text is not displayed as per wireframe");
        }


    }
    public void toValidateFieldsinEditKP() throws Exception {
        String[] labelList={"title","firstName","middleName","lastName","dateOfBirth","emailAddress","telCountryCode","contactNumber","country","houseNumber","addressLine1","addressLine2","city","postcode"};
        for(int i=0;i<labelList.length;i++ ){
            labelXPath(labelList[i]);
            if(!helper.isElementPresent(labelElement, driver)) {
                helper.failTest(labelList[i]+" is not displayed", labelList[i]+" should be displayed", labelList[i]+" is not displayed", driver, testContext);
            }
        }
        WebElement moveInDate = driver.findElement(By.xpath("//label[contains(text(),'Move in date')]"));
        if(!helper.isElementPresent(moveInDate, driver)) {
            helper.failTest("Title field", "Title field should be displayed", "Title field is not displayed", driver, testContext);
        }

        String[] FieldList={"firstName","middleName","lastName","dateOfBirth","emailAddress","contactNumber","houseNumber","addressLine1","addressLine2","city", "postcode","houseNumber","addressLine1","addressLine2","city","postcode"};
        for(int i=0;i<FieldList.length;i++ ){
            labelfollowingField(FieldList[i]);
            if(!helper.isElementPresent(labelElementField, driver)) {
                helper.failTest(FieldList[i]+" is not displayed", FieldList[i]+" should be displayed", FieldList[i]+" is not displayed", driver, testContext);
            }
        }
        if(!helper.isElementPresent(intCode, driver)) {
            helper.failTest("International code dropdown is not displayed", "International code dropdown should be displayed", "International code dropdown is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(titlePleaseSelect, driver)) {
            helper.failTest("Title dropdown is not displayed", "Title dropdown should be displayed", "Title dropdown is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(selectMonth, driver)) {
            helper.failTest("Month dropdown is not displayed", "Month dropdown should be displayed", "Month dropdown is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(selectYear, driver)) {
            helper.failTest("Year dropdown is not displayed", "Year dropdown should be displayed", "Year dropdown is not displayed", driver, testContext);
        }
        /*if(!helper.isElementPresent(countryDropDown, driver)) {
            helper.failTest("Country dropdown is not displayed", "Country dropdown should be displayed", "Country dropdown is not displayed", driver, testContext);*/
        //}

    }

    public void toValidateFieldsinNewKP() throws Exception {
        String[] labelList={"title","firstName","middleName","lastName","dateOfBirth","emailAddress","telCountryCode","contactNumber","country"};
        for(int i=0;i<labelList.length;i++ ){
            labelXPath(labelList[i]);
            if(!helper.isElementPresent(labelElement, driver)) {
                helper.failTest(labelList[i]+" is not displayed", labelList[i]+" should be displayed", labelList[i]+" is not displayed", driver, testContext);
            }
        }

        String[] FieldList={"firstName","middleName","lastName","dateOfBirth","emailAddress","contactNumber"};
        for(int i=0;i<FieldList.length;i++ ){
            labelfollowingField(FieldList[i]);
            if(!helper.isElementPresent(labelElementField, driver)) {
                helper.failTest(FieldList[i]+" is not displayed", FieldList[i]+" should be displayed", FieldList[i]+" is not displayed", driver, testContext);
            }
        }
        if(!helper.isElementPresent(intCode, driver)) {
            helper.failTest("International code dropdown is not displayed", "International code dropdown should be displayed", "International code dropdown is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(titlePleaseSelect, driver)) {
            helper.failTest("Title dropdown is not displayed", "Title dropdown should be displayed", "Title dropdown is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(countryDropDown, driver)) {
            helper.failTest("Country dropdown is not displayed", "Country dropdown should be displayed", "Country dropdown is not displayed", driver, testContext);
        }

    }

    public void toValidateFieldsinPreviousAddress() throws Exception {

        if(!helper.isElementPresent(previousAddressHeader, driver)) {
            helper.failTest("Previous address header is not displayed", "Previous address header should be displayed", "Previous address header is not displayed", driver, testContext);
        }
        if(!helper.isElementPresent(enterAddressManually, driver)) {
            helper.failTest("Enter address manually link is not displayed", "Enter address manually link should be displayed", "Enter address manually link is not displayed", driver, testContext);
        }
        enterAddressManually.click();
        String[] labelList={"previous:country","previous:houseNumber","previous:addressLine1","previous:addressLine2","previous:city","previous:postcode"};
        for(int i=0;i<labelList.length;i++ ){
            labelXPath(labelList[i]);
            if(!helper.isElementPresent(labelElement, driver)) {
                helper.failTest(labelList[i]+" is not displayed", labelList[i]+" should be displayed", labelList[i]+" is not displayed", driver, testContext);
            }
        }

        List<WebElement> moveInDate = driver.findElements(By.xpath("//label[contains(text(),'Move in date')]"));

        WebElement KPCurrent = moveInDate.get(0);
        WebElement KPPrevious = moveInDate.get(1);
        if(!helper.isElementPresent(KPCurrent, driver)) {
            helper.failTest("Move in date is not displayed for current address", "Move in date should be displayed for current address", "Move in date is not displayed for current address", driver, testContext);
        }
        if(!helper.isElementPresent(KPPrevious, driver)) {
            helper.failTest("Move in date is not displayed for previous address", "Move in date should be displayed for previous address", "Move in date is not displayed for current address", driver, testContext);
        }

        List<WebElement> month = driver.findElements(By.xpath("//input[@placeholder='Select month']"));

        WebElement KPMonthCurrent = month.get(0);
        WebElement KPMonthPrevious = month.get(1);
        if(!helper.isElementPresent(KPMonthCurrent, driver)) {
            helper.failTest("Month is not displayed for current address", "Month should be displayed for current address", "Month is not displayed for current address", driver, testContext);
        }
        if(!helper.isElementPresent(KPMonthPrevious, driver)) {
            helper.failTest("Month is not displayed for previous address", "Month should be displayed for previous address", "Month is not displayed for current address", driver, testContext);
        }

        List<WebElement> year = driver.findElements(By.xpath("//input[@placeholder='Select year']"));

        WebElement KPYearCurrent = year.get(0);
        WebElement KPYearPrevious = year.get(1);
        if(!helper.isElementPresent(KPYearCurrent, driver)) {
            helper.failTest("Year is not displayed for current address", "Year should be displayed for current address", "Year is not displayed for current address", driver, testContext);
        }
        if(!helper.isElementPresent(KPYearPrevious, driver)) {
            helper.failTest("Year is not displayed for previous address", "Year should be displayed for previous address", "Year is not displayed for current address", driver, testContext);
        }


    }

    public void verifyKeyPrinciplesPageIsDiplayedPage() throws Exception {
    	//Thread.sleep(3000);

        // initiate page
        helper.initialisePage(driver, testContext, "Key Principles");

        try {

            if (!(txtHeader.getText().contains("Your key principal"))) {
                helper.failTest("Key Principles page is not displayed", "Key Principles page is not displayed", "",
                        driver, testContext);
                // Take a screen shot
                helper.addfullScreenCaptureToExtentReport(driver, testContext);

            }
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
            helper.failTest("Key Principles page is not displayed", "Key Principles page is not displayed",
                    e.getMessage(), driver, testContext);

        }

    }
    
    public void KPCountValidation(String expected_kpcount) throws Exception{
        try {
            int actual_kpcount = returnNumberOfKPs();

            if(Integer.parseInt(expected_kpcount)==actual_kpcount) {
                System.out.println("KP Count "+actual_kpcount+" in the application matches the expected count "+expected_kpcount);
                
            } else {
                System.out.println("KP Count "+actual_kpcount+" in the application did not match the expected count"+expected_kpcount);
                helper.failTest("KP Count in the application should match the expected count", "KP Count in the application should match the expected count",
                        "KP Count in the application did not match the expected count", driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }


    public void ErrorMessageValidation(String expectedErrorMessage) throws Exception{
        try {

            String actualErrorMessage = driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[1]")).getText().trim();

            if(actualErrorMessage.equals("You can’t add or remove any more key principals.")) {

            } else {
                System.out.println("Expected Errormessage Header is 'You can't add or remove any more key principals.' And the actual error message Header is "+actualErrorMessage);

                helper.failTest("Expected Error Message Header should match with the error message Header in the application", "Expected Error Message Header should match with the error message Header in the application",
                        "Expected Error Message Header did not match with the error message Header in the application", driver, testContext);
            }

            actualErrorMessage=driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[2]")).getText().trim();

            if(actualErrorMessage.equals(expectedErrorMessage)){
            	helper.addfullScreenCaptureToExtentReport(driver, testContext);
            } else{
                System.out.println("Expected Errormessage is "+expectedErrorMessage + "And the actual error message is "+actualErrorMessage);


                helper.failTest("Expected Error Message Header should match with the error message in the application", "Expected Error Message Header should match with the error message in the application",
                        "Expected Error Message Header did not match with the error message in the application", driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }




    public void validateCountryDropdown() throws Exception{
        try {

            String filePath = System.getProperty("user.dir");
            filePath=filePath;
            System.out.println("File path"+filePath);
            String[] expectedOptions = helper.readFromTextFile(filePath);


            List<String> actualOptions = new ArrayList<String>();
            editCountryCodeDropdown.click();

            List<WebElement> allElements = driver.findElements(By.xpath("//li[@class='zb-dropdown-list-item']/div"));

            for (WebElement element3 : allElements) {
                actualOptions.add(element3.getText());
            }
            String[] tempsArray = actualOptions.toArray(new String[0]);


            helper.writeToTextFile(tempsArray);
            System.out.println(expectedOptions.length);
            System.out.println(tempsArray.length);

            for (int i = 0; i < expectedOptions.length; i++){
                expectedOptions[i] =expectedOptions[i].replace('?', 'z');
            }
            for (int i = 0; i < tempsArray.length; i++){
                expectedOptions[i] =tempsArray[i].replace('?', 'z');
            }

            Arrays.sort(expectedOptions);
            Arrays.sort(tempsArray);
            for (int i=0;i<expectedOptions.length-1;i++) {

                if(expectedOptions[i].equals(tempsArray[i])){
                    System.out.println("If Loop Expected Value is "+expectedOptions[i] +"and Actual Value is "+tempsArray[i]+" And the value of i is "+i);
                }else{
                    System.out.println("Else Loop : Expected Value is "+expectedOptions[i] +"and Actual Value is "+tempsArray[i]+" And the value of i is "+i);
                    helper.failTest("Comparing Dropdown Values should be equal", "Comparing Dropdown Values should be equal",
                            "Comparing Dropdown Values was not equal was " +tempsArray[i], driver, testContext);
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }

    public void WarningMessageValidation(String expectedErrorMessage) throws Exception{
        try {
            String actualErrorMessage = driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[1]")).getText().trim();

            System.out.println("Error Message Header"+actualErrorMessage);

            if(actualErrorMessage.equals(expectedErrorMessage)) {
                System.out.println("Expected Errormessage Header is "+expectedErrorMessage+" And the actual error message Header is "+actualErrorMessage);

            } else {
                System.out.println("Expected Errormessage Header is "+expectedErrorMessage+" And the actual error message Header is "+actualErrorMessage);

                helper.failTest("Expected Error Message Header should match with the error message Header in the application", "Expected Error Message Header should match with the error message Header in the application",
                        "Expected Error Message Header did not match with the error message Header in the application", driver, testContext);
            }

            actualErrorMessage=driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[2]")).getText().trim();
            System.out.println("Error Message Header"+actualErrorMessage);

            if(actualErrorMessage.equals("If you need to add more, request a callback and we'll get in touch.")){
                System.out.println("Expected Errormessage is 'If you need to add more, request a callback and we'll get in touch.' And the actual error message is "+actualErrorMessage);

            } else{
                System.out.println("Expected Errormessage is 'If you need to add more, request a callback and we'll get in touch.' And the actual error message is "+actualErrorMessage);


                helper.failTest("Expected Error Message Header should match with the error message in the application", "Expected Error Message Header should match with the error message in the application",
                        "Expected Error Message Header did not match with the error message in the application", driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }


    public void countryDropdownDefaultVal() throws Exception{
        try{
            firstName.click();
            editCountryCodeDropdown.click();
            String actualDefaultValue = driver.findElement(By.xpath("//*[@class='zb-dropdown-list-item zb-select-dropdown-list-item-is-selected']/div")).getText();
            String expectedDefaultValue = "United Kingdom";
            if(expectedDefaultValue.equals(actualDefaultValue)){
            }else{
                System.out.println("Expected default value of country dropdown is "+expectedDefaultValue + "And the actual default value is "+actualDefaultValue);
                helper.failTest("Default Value of Country Dropdown should be 'United Kingdom'", "Default Value of Country Dropdown should be 'United Kingdom'",
                        "Default Value of Country Dropdown was not 'United Kingdom'", driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }

    public void incompleteDataErrorMessageVal() throws Exception{
        try{
            String expectedErrorMessage = "Please complete";

			if(expectedErrorMessage.equals(txtNumber.getText() )){
				System.out.println("If Loop : Expected Error Message of Phone Number is "+expectedErrorMessage + " And the actual value is "+txtNumber.getText());

			}else {
				System.out.println("Else Loop: Expected Error Message of Phone Number is "+expectedErrorMessage + " And the actual value is "+txtNumber.getText());
				helper.failTest("Expected Error Message of Phone Number should be 'Please complete'", "Expected Error Message of Phone Number should be 'Please complete'",
						"Expected Error Message was not displayed for Phone Number", driver, testContext);
			}

            if(expectedErrorMessage.equals(txtDateMovedIn.getText())){
                System.out.println("If Loop: Expected Error Message of Date Moved In Field is "+expectedErrorMessage + " And the actual default value is "+txtDateMovedIn.getText());

            }else{
                System.out.println("Else Loop: Expected Error Message of Date Moved In Field is "+expectedErrorMessage + " And the actual default value is "+txtDateMovedIn.getText());
                helper.failTest("Expected Error Message of Date Moved In Field should be 'Please complete'", "Expected Error Message of Date Moved In Field should be 'Please complete'",
                        "Expected Error Message of Date Moved In Field was not displayed", driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }

    public void incompletePageErrVal(String expectedErrorMessage) throws Exception{
        try{

            if("Incomplete information".equals(incompleteInfoHeader.getText())){
                System.out.println("Expected Error Message Title of Incomplete Data Page should be 'Incomplete information' And the actual Error Message is "+incompleteInfoHeader.getText());
            }else{
                System.out.println("Expected Error Message Title of Incomplete Data Page should be 'Incomplete information' And the actual Error Message is "+incompleteInfoHeader.getText());
                helper.failTest("Expected Error Message Title of Incomplete Data Page should be 'Incomplete information'", "Expected Error Message Title of Incomplete Data Page should be 'Incomplete information'",
                        "the actual Error Message Title is "+incompleteInfoHeader.getText(), driver, testContext);
            }
            
            if(expectedErrorMessage.equals(incompleteInfoErrMess.getText())){
                System.out.println("Expected Error Message of Incomplete Data Page should be '"+expectedErrorMessage+"' And the actual Error Message is "+incompleteInfoErrMess.getText());
            }else{
                System.out.println("Expected Error Message of Incomplete Data Page should be '"+expectedErrorMessage+"' And the actual Error Message is "+incompleteInfoErrMess.getText());
                helper.failTest("Expected Error Message of Incomplete Data Page should be: "+expectedErrorMessage, "Expected Error Message of Incomplete Data Page should be: "+expectedErrorMessage,
                        "the actual Error Message is "+incompleteInfoErrMess.getText(), driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext); 
        }
    }

    public void intCodeValidation() throws Exception{
        try{

            if(viewIntCode.getText().equals("-")){
                System.out.println("Expected value is '-' but actual value in Int Code is "+viewIntCode.getText());
                helper.addfullScreenCaptureToExtentReport(driver, testContext);
                
            }else {
            	System.out.println("Expected value is '-' but actual value in Int Code is "+viewIntCode.getText());
            	helper.failTest("Expected is '-' for Int Code Field", "Expected is '-' for Int Code Field",
                        "The actual value in Int Code Field is "+viewIntCode.getText(), driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }


    public void intCodeDefaultValueValidation() throws Exception{
        try{

            if(IntCodeValue.getAttribute("value").equals("+44")){
                System.out.println("Expected value is +44 but actual value in Int Code is "+IntCodeValue.getAttribute("value"));

            }else{
                helper.failTest("Expected is +44 for Int Code Field", "Expected is +44 for Int Code Field",
                        "The actual value in Int Code Field is "+IntCodeValue.getAttribute("value"), driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }


    public void validateCountryCodeDisplay(String expectedCountryCode) throws Exception{
        try{

            if(txtAddress.getText().contains(expectedCountryCode)){
                System.out.println("If Loop: Country Code "+expectedCountryCode + " should be displayed. The actual country code getting displayed is "+txtAddress.getText());
            }else{
                System.out.println("Else Loop : Country Code "+expectedCountryCode + " should be displayed. The actual country code getting displayed is "+txtAddress.getText());
                helper.failTest("Expected Country Code should be "+expectedCountryCode, "Expected Country Code should be "+expectedCountryCode,
                        "the actual country code getting displayed is "+txtAddress.getText(), driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }

    public void validateDefaultCountryCodeDD() throws Exception{
        try{

            if(editCountryCodeDropdown.getAttribute("value").contains("Please select")){
                System.out.println("If Loop: Country Code 'Please select' should be displayed. The actual country code getting displayed is "+editCountryCodeDropdown.getAttribute("value"));
            }else{
                System.out.println("Else Loop : Country Code 'Please select' should be displayed. The actual country code getting displayed is "+editCountryCodeDropdown.getAttribute("value"));
                helper.failTest("Expected Country Code should be 'Please select'", "Expected Country Code should be 'Please select'",
                        "the actual country code getting displayed is "+editCountryCodeDropdown.getAttribute("value"), driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }


    public void validateLinkInfo(String pageName) throws Exception{
        try{

            Boolean textValidationResult =false;
            if(pageName.contains("sole_trader")){
                //For Sole Trader
                if (driver.findElement(By.xpath("(//*[@class='zb-modal-card-title'])[2]")).getText().equals("What is a key principal?")) {
                	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-card-title'])[2]")).getText());
                    if (driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[1]")).getText().equals("For Sole Traders the \"Controller\"")) {
                    	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[1]")).getText());
                        if (driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[2]")).getText().equals("For Simple partnerships all \"Partners\"")) {
                        	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[2]")).getText());
                            if (driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[3]")).getText().equals("For Company's all \"Directors\"")) {
                            	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[3]")).getText());
                                if (driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[4]")).getText().equals("For Limited Liability Partnership (LLP) all \"Members/partners\"")) {
                                	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//child::span[4]")).getText());
                                    if (driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//p/text()[1]")).getText().equals("Associated parties such as Secretary, Beneficial Owner, Treasurer,")) {
                                    	System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//p/text()[1]")).getText());
                                    	if(driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//p/text()[2]")).getText().equals("Signatory are not key principals, unless they also hold a position listed above.")) {
                                    		System.out.println("This part of the text was correct"+driver.findElement(By.xpath("(//*[@class='zb-modal-body zb-modal-card-body zb-has-scrollbar'])[2]//p/text()[2]")).getText());
                                    		textValidationResult=true;
                                    		helper.addfullScreenCaptureToExtentReport(driver, testContext);
                                    	}
                                    }
                                }
                            }
                        }
                    }

                }
            }else{
                if(infoHelpHeader.getText().equals("Key principals")){
                    System.out.println("This part of the text was correct"+infoHelpHeader.getText());
                    if (linkKPWhatAreKeyPrincipals.getText().equals("What are key principals?")){
                        System.out.println("This part of the text was correct"+linkKPWhatAreKeyPrincipals.getText());
                        if(linkKPKeyPrincipalsAre.getText().equals("Key principals are:")){
                            System.out.println("This part of the text was correct"+linkKPKeyPrincipalsAre.getText());
                            if(linkKPPointers.get(0).getText().equals("for Sole Traders the \"Controller\"")) {
                                System.out.println("This part of the text was correct"+linkKPPointers.get(0).getText());
                                if (linkKPPointers.get(1).getText().equals("for Simple partnerships all \"Partners\"")){
                                    System.out.println("This part of the text was correct"+linkKPPointers.get(1).getText());
                                    if(linkKPPointers.get(2).getText().equals("for Company's all \"Directors\"")){
                                        System.out.println("This part of the text was correct"+linkKPPointers.get(2).getText());
                                        if(linkKPPointers.get(3).getText().equals("for Limited Liability Partnership (LLP) all \"Members/partners\"")){
                                            System.out.println("This part of the text was correct"+linkKPPointers.get(3).getText());
                                            if(linkKPinformation.get(0).getText().equals("Secretary, Beneficial Owner, Treasurer, Signatory are not key principals, unless they also hold a position listed above.")){
                                                System.out.println("This part of the text was correct"+linkKPinformation.get(0).getText());
                                                if(linkKPInfoWeNeed.getText().equals("Information we need from you")){
                                                    System.out.println("This part of the text was correct"+linkKPInfoWeNeed.getText());
                                                    if(linkKPinformation.get(1).getText().equals("Please complete all fields for each key principal; each key principal must have a unique email and mobile number.")){
                                                        System.out.println("This part of the text was correct"+linkKPinformation.get(1).getText());
                                                        if(linkKPinformation.get(2).getText().equals("You can add/or remove up to two key principals. If you removed a key principal in error, please create a new record for the key principal.")){
                                                            System.out.println("This part of the text was correct"+linkKPinformation.get(2).getText());
                                                            if(linkKPinformation.get(3).getText().equals("If your business has more than six key principals or you need to make add/remove more than two key principals, please request a callback.")){
                                                                System.out.println("This part of the text was correct"+linkKPinformation.get(3).getText());
                                                                textValidationResult=true;
                                                                helper.addfullScreenCaptureToExtentReport(driver, testContext);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }

            if(textValidationResult==false){
                helper.failTest("Expected help link text to be as per the wireframe", "Expected help link text to be as per the wireframe",
                        "Help link text was not as per the wireframe", driver, testContext);
                helper.addfullScreenCaptureToExtentReport(driver, testContext);
            }

        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }
    }

    public void editEachKeyPrincipalAndConfirm(List<Map<String, String>> KPValuesToBeEntered) throws Exception{
        try{
        	Thread.sleep(5000);
            int i=0;
            for (WebElement kpLinkElement : keyPrincipalsLink){
                System.out.println("no of KP s is"+i);
                if(kpLinkElement.getAttribute("class").contains("confirmation-small") || kpLinkElement.getAttribute("class").contains("warning-small")) {
                    System.out.println("no of KP s is" + i);
                    kpLinkElement.click();
                    linkEditDetails.click();
                    editDetailsMandatoryFieldsAndSave(KPValuesToBeEntered, i);
                    saveButton.click();
                    helper.clickAnyButtonInDigitalJourney("Confirm", driver, testContext);
                    i++;
                }
            }

            helper.addfullScreenCaptureToExtentReport(driver, testContext);

        }catch(Exception e) {
            e.printStackTrace();
            helper.addfullScreenCaptureToExtentReport(driver, testContext);
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }

    }

    public void editDetailsMandatoryFieldsAndSave(List<Map<String, String>> KPValuesToBeEntered, int i) throws Exception{
        Thread.sleep(10000);
        //Boolean editResult=false;
        if(titlePleaseSelect.getAttribute("value")== null || titlePleaseSelect.getAttribute("value").isEmpty()){
            titlePleaseSelect.click();
            setDropDownValue(KPValuesToBeEntered.get(i).get("Title"));
            System.out.println("Title set"+titlePleaseSelect.getAttribute("value"));
        }else {
            System.out.println("Else loop: Title set "+titlePleaseSelect.getAttribute("value"));
        }
        if (firstName.getAttribute("value")== null || firstName.getAttribute("value").isEmpty()){
            firstName.sendKeys(KPValuesToBeEntered.get(i).get("First name"));
            System.out.println("First Name sent"+firstName.getAttribute("value"));
        }else{
            System.out.println("Else loop: First Name sent "+firstName.getAttribute("value"));
        } if (editSurName.getAttribute("value")== null || editSurName.getAttribute("value").isEmpty()){
            editSurName.sendKeys(KPValuesToBeEntered.get(i).get("Surname"));
            System.out.println("Last Name sent"+editSurName.getAttribute("value"));
        }else {
            System.out.println("Else loop Last Name sent"+editSurName.getAttribute("value"));
        }if(editDateOfBirth.getAttribute("value")== null || editDateOfBirth.getAttribute("value").isEmpty()){
            editDateOfBirth.sendKeys(KPValuesToBeEntered.get(i).get("DateofBirth"));
            System.out.println("DOB sent"+editDateOfBirth.getAttribute("value"));
        }else {
            System.out.println("Else loop DOB sent"+editDateOfBirth.getAttribute("value"));
        }if (editEmailAddress.getAttribute("value")== null || editEmailAddress.getAttribute("value").isEmpty()){
            editEmailAddress.sendKeys(KPValuesToBeEntered.get(i).get("Email"));
            System.out.println("Email Address sent"+editEmailAddress.getAttribute("value"));
        }else {
            System.out.println("Else loop Email Address sent"+editEmailAddress.getAttribute("value"));
        }if (editIntCodeDropdown.getAttribute("value")== null || editIntCodeDropdown.getAttribute("value").isEmpty()){
            intCode.click();
            setDropDownValue(KPValuesToBeEntered.get(i).get("IntCode"));
            System.out.println("Int Code sent"+editIntCodeDropdown.getAttribute("value"));
        }else {
            System.out.println("Else loop Int code"+editIntCodeDropdown.getAttribute("value"));
        }if (editMobilePhoneNumber.getAttribute("value")== null || editMobilePhoneNumber.getAttribute("value").isEmpty()){
            editMobilePhoneNumber.sendKeys(KPValuesToBeEntered.get(i).get("Mobile"));
            System.out.println("Phone NUmber sent"+editMobilePhoneNumber.getAttribute("value"));
        }else {
            System.out.println("Phone NUmber sent else loop"+editMobilePhoneNumber.getAttribute("value"));
        }if (editAddressLine1.getAttribute("value")== null || editAddressLine1.getAttribute("value").isEmpty()){
            editAddressLine1.sendKeys("Address Line1");
            System.out.println("Address line 1 sent"+editAddressLine1.getAttribute("value"));
        }else {
            System.out.println("Else loop Address line 1 sent"+editAddressLine1.getAttribute("value"));
        }if(editAddressLine2.getAttribute("value")== null || editAddressLine2.getAttribute("value").isEmpty()){
            editAddressLine2.sendKeys("Address Line2");
            System.out.println("Address Line 2 sent"+editAddressLine2.getAttribute("value"));
        }else System.out.println("Else loop Address line 2 sent"+editAddressLine2.getAttribute("value"));
        if(inputPostcode.getAttribute("value")== null || inputPostcode.getAttribute("value").isEmpty()){
            inputPostcode.sendKeys(KPValuesToBeEntered.get(i).get("PostCode"));
            System.out.println("post code sent"+inputPostcode.getAttribute("value"));
        }else System.out.println("Else loop post code sent"+inputPostcode.getAttribute("value"));
        if(selectMonth.getAttribute("value")== null || selectMonth.getAttribute("value").isEmpty() ){
            selectMonth.click();
            setDropDownValue(KPValuesToBeEntered.get(i).get("MovedInMonth"));
            System.out.println("Month Clicked"+selectMonth.getAttribute("value"));
        }else System.out.println("Else loop Month Clicked"+selectMonth.getAttribute("value"));
        if(selectYear.getAttribute("value")== null || selectYear.getAttribute("value").isEmpty()){
            selectYear.click();
            setDropDownValue(KPValuesToBeEntered.get(i).get("MovedInYear"));
            System.out.println("Year sent"+selectYear.getAttribute("value"));
        }else System.out.println("Else loop Year sent"+selectYear.getAttribute("value"));


        receiveIncomeNo.click();


    }
    
    //helper.addfullScreenCaptureToExtentReport(driver, testContext);

    //}



    public void valKPConfirmationMark(int numberOfKPs) throws Exception{
        try{

            //int numberOfKPs = returnNumberOfKPs();
            int actualMarkCount =0;
            for (WebElement kpMarkElement : keyPrincipalsMark){
                System.out.println("kpMarkElement.getText() iss     "+kpMarkElement.getText());
                if(kpMarkElement.getText().equals("confirmation-small")){
                    actualMarkCount++;
                }
            }
            if(actualMarkCount==numberOfKPs){
                System.out.println("No. of confirmation marks available is "+actualMarkCount+ "and expected no. of marks was "+numberOfKPs);
            }else{
                System.out.println("No. of confirmation marks available is "+actualMarkCount+ "and expected no. of marks was "+numberOfKPs);
                helper.failTest("Expected no. of marks was "+numberOfKPs, "Expected no. of marks was "+numberOfKPs,
                        "No. of confirmation marks available is "+actualMarkCount, driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }

    }

    public void validateUnconfirmedMark() throws Exception{
        try{

            int numberOfKPs = returnNumberOfKPs();
            System.out.println("No. of KP's inside the application is "+numberOfKPs);
            int actualMarkCount =0;
            for (WebElement kpMarkElement : keyPrincipalsMark){
                System.out.println("kpMarkElement.getText() iss     "+kpMarkElement.getText());
                if(kpMarkElement.getText().equals("warning-small")){
                    actualMarkCount++;
                }
            }
            if(actualMarkCount==numberOfKPs){
                System.out.println("No. of unconfirmation marks available is "+actualMarkCount+ "and expected no. of marks was "+numberOfKPs);
            }else{
                System.out.println("No. of unconfirmation marks available is "+actualMarkCount+ "and expected no. of marks was "+numberOfKPs);
                helper.failTest("Expected no. of marks was "+numberOfKPs, "Expected no. of marks was "+numberOfKPs,
                        "No. of unconfirmation marks available is "+actualMarkCount, driver, testContext);
            }
        }catch(Exception e) {
            e.printStackTrace();
            helper.failTest("Element should be found", "Element should be found",
                    e.getMessage(), driver, testContext);
        }

    }

    public void toValidateEditKPFields(String fieldName, String Value,String errorMessage,String ammendedData) throws Exception {
    	try {
        if(fieldName.contains("Email"))
        {
            UIFieldName = inputEmailAddress;
            errorMessageValidation = "emailAddress";

        }
        if(fieldName.contains("DOB"))
        {
            UIFieldName = inputDateOfBirth;
            errorMessageValidation = "dateOfBirth" ;
        }
        if(fieldName.contains("surname"))
        {
            UIFieldName = inputLastName;
            errorMessageValidation = "lastName" ;
        }
        if(fieldName.contains("Addresspostcode"))
        {
            UIFieldName = inputPostcode;
            errorMessageValidation = "postcode" ;
        }
        if(fieldName.contains("MobilePhoneNumber"))
        {
            UIFieldName = inputMobileNumber;
            errorMessageValidation = "contactNumber" ;
        }
        if(fieldName.contains("FirstName"))
        {
            UIFieldName = inputFirstName;
            errorMessageValidation = "firstName" ;

        }
        if(fieldName.contains("AddressLine1"))
        {
            UIFieldName = inputHouseNumber;
            errorMessageValidation = "houseNumber" ;

        }

        if(fieldName.contains("AddressLine2"))
        {
            UIFieldName = inputAddressLine1;
            errorMessageValidation = "addressLine1" ;

        }

        KPEditDBValidations(fieldName, Value,errorMessage,UIFieldName,errorMessageValidation,ammendedData);
    	}
    	catch(Exception ex) {
    	helper.failTest("Error message validation", "Proper error messages should be displayed", "Proper error messages are not displayed", driver, testContext);
    	}

    }
    private void KPEditDBValidations(String fieldName, String Value,String errorMessage,WebElement UIfieldName,String errorMessageValidation,String ammendedData) throws Exception {
    	try {
        System.out.println(UIFieldName);
        actualFieldvalue = UIfieldName.getAttribute("Value");

        if(ammendedData.contains("NA"))
        {
            updateFieldValue = actualFieldvalue.toUpperCase();
        }
        else
        {
            updateFieldValue = ammendedData;
        }
        Thread.sleep(3000);

        if(fieldName.contains("MobilePhoneNumber"))
        {
            intCode.click();
            setDropDownValue("+44");
        }

        UIfieldName.click();
        Thread.sleep(5000);
        UIfieldName.clear();
        Thread.sleep(5000);
        if(!(Value.contains("Blank")))
        {
            UIfieldName.sendKeys(Value);
        }
        UIfieldName.sendKeys(Keys.TAB);
        if(fieldName.contains("AddressLine"))
        {
            inputAddressLine2.sendKeys("opt1");
            inputCity.sendKeys("opt2");

        }
        if(fieldName.contains("FirstName"))
        {
            inputMiddleName.sendKeys("middleName");
        }
        ErrorMessage = errorMessage;
        if(!(fieldName.contains("postcode")))
        {

            errorMessageValidation(errorMessageValidation);
        }

        if(fieldName.contains("postcode"))
        {
            WebElement button = driver.findElement(By.xpath("//button[text()='Save']"));
            button.click();
            errorMessageValidation(errorMessageValidation);
        }




        Thread.sleep(3000);
        UIfieldName.click();
        Thread.sleep(5000);
        UIfieldName.clear();
		/*if(fieldName.contains("surname")) {
			updateFieldValue = "Jean_RW";
		}
		if(fieldName.contains("Addresspostcode")) {
			updateFieldValue = "TW7 4HY";
		}*/

        UIfieldName.sendKeys(updateFieldValue);

       /* selectMonth.click();
        setDropDownValue("01");
        selectYear.click();
        setDropDownValue("2010");*/

       /* WebElement button = driver.findElement(By.xpath("//button[text()='Save']"));
        button.click();*/

        buttonClick("Cancel");
    }
    

    catch(Exception ex)
    {
    	helper.failTest("Error message validation", "Proper error messages should be displayed", "Proper error messages are not displayed", driver, testContext);
    }
    }

    
    public void ErrorMessageNotDisplayed(String expectedErrorMessage) throws Exception{
        try {

            if(driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[1]")).isDisplayed()) {
            	if(!driver.findElement(By.xpath("//div[contains(@class, 'MaxActionsInfo_text_')]//child::div[1]")).getText().equals(expectedErrorMessage))
            	helper.failTest("Element should be found", "Element should be found",
                       "Element is not displayed", driver, testContext);
            	System.out.println("Error message was displayed");

            }

            
        }catch(Exception e) {
           
        	System.out.println("Error message is not displayed");
        }
    }



}
