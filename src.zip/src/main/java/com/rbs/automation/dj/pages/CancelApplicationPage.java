package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

public class CancelApplicationPage {
    private WebDriver driver;
    private String sDataSheetName = "ThankYou";
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    public CancelApplicationPage(WebDriver driver, TestContext context){
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
    }

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'The condition')]")
    public WebElement radioBtnConditions;

    @FindBy(how = How.XPATH,using = "//label[contains(text(),'The cost of borrowing')]")
    public WebElement radioBtnCostOfBorrowing;

    @FindBy(how =How.XPATH,using = "//label[contains(text(),'Other')]")
    public WebElement radioBtnOther;

    @FindBy(how = How.XPATH, using = "//h1")
    public WebElement textCancelApplication;

    @FindBy(how = How.CSS, using = "#zb-lending-card div:nth-child(2)  textarea")
    public WebElement textReasonOther;



    public void verifyCancelApplicationIsDisplayed()throws Exception{

        try{

            helper.initialisePage(driver, testContext, "cancelapplication");


            if(!textCancelApplication.getText().contains("Cancel application")){
                helper.failTest("Cancel Application Page","Cancel application","" ,driver,testContext);
            }
        }catch (Exception e){
            helper.failTest("Cancel Application Page","Cancel application",e.getMessage(),driver,testContext);
        }

    }

    public void borrowingConditions() throws Exception {
        radioBtnConditions.click();
    }

    public void costOfBorrowing() throws Exception {
        driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
        radioBtnCostOfBorrowing.click();
    }

    public void otherReason() throws Exception {
        radioBtnOther.click();
        textReasonOther.sendKeys("Test message");
    }

    public void confirmCancellation() throws Exception {
        helper.clickAnyButtonInDigitalJourney("Confirm Cancellation",driver,testContext);
    }
}
