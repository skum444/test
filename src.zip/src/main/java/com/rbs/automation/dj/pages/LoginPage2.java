package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class LoginPage2 {

	private WebDriver driver;
	private String sTestDataSheetName = "Login2";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public LoginPage2(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		this.testContext = context;

	}

	@FindBy(how = How.XPATH, using = "//button[text()='Login']")
	public WebElement btnLogin;

	@FindBy(how = How.XPATH, using = "//h4")
	public WebElement txtH4Header;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Customer number')]")
	public WebElement txtDevHeader;

	@FindBy(how = How.XPATH, using = "//h2")
	public WebElement txtH2Header;

	@FindBy(how = How.XPATH, using = "//span[@class='pageError-message']")
	public WebElement txtPageErrorMsg;

	public void inputValuesInBBlogin2Page() throws Exception {
		try {

			String secid = genricUtils.getProperty("secid");

			// get security pin number and update the fields
			int i = 1;
			for (i = 1; i <= 3; i++) {

				String secpin = genricUtils.getlabeltext(driver, "pin" + i, "pin-pass-label");

				String pinpos = secpin.replaceAll("[^0-9]+", "").trim();
				int pinposnum = Integer.parseInt(pinpos);

				char secvalue = secid.charAt(pinposnum - 1);

				genricUtils.updateSecPin(driver, "pin" + i, "pin-pass-input", secvalue);

			}
			
			

			String secpwd = GenericUtils.getProperty("secpwd");

			int j = 1;

			for (j = 1; j <= 3; j++) {

				// String secpwd1 = commoncomps.getlabeltext("pin-pass-label",
				// "pwd"+j);
				String secpwd1 = genricUtils.getlabeltext(driver, "pwd" + j, "pin-pass-label");
				String pinpos = secpwd1.replaceAll("[^0-9]+", "").trim();
				int pinposnum = Integer.parseInt(pinpos);
				char secvalue = secpwd.charAt(pinposnum - 1);

				// System.out.println("pin position:" + pinpos);

				if (pinposnum > 6)
					throw new IllegalArgumentException("invalid pin number");

				// System.out.println(" The value of secpwd"+" at pwdposition "+
				// pinposnum+ " is " +secvalue);
				genricUtils.updateSecPin(driver, "pwd" + j, "pin-pass-input", secvalue);

			}

			helper.clickAnyButtonInDigitalJourney("Login", driver, testContext);

			// btnLogin.click();
			Thread.sleep(1000);

			if (WaitUtils.isElementPresentWithoutImplicitWait(driver,
					By.xpath("//span[@class= 'pageError-message']"))) {
			
				helper.failTest("Login page not displayed", "Login page not displayed", "", driver, testContext);
			}

			// System.out.println("Login PIN details are entered");

		} catch (Exception e) {
			helper.failTest("Login page 2 not displayed", "Login page 2 not displayed", "", driver, testContext);

		}

	}

	public void verifyLoginPage2IsDisplayed() throws Exception {

		helper.initialisePage(driver, testContext, "Login2");

		try {
			
			String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
			String header = "";
			
			if(brand.contains("DEV"))
			{
				header = txtDevHeader.getText();  
			
			}else
			
			{
				header = txtH4Header.getText();
			}
			
			
			if (!(header.contains("Customer number"))) {
				helper.failTest("Login page 2 not displayed", "Login page 2 not displayed", "", driver, testContext);
			} 

		} catch (Exception e) {
			
			helper.failTest("Enter Pin page not displayed", "Enter Pin page not displayed", "", driver, testContext);
		}

	}

}
