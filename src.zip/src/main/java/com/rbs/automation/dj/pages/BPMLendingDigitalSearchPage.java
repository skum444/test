package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.testcontext.TestContext;

public class BPMLendingDigitalSearchPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	

	// initialise the page elements when the class is instantiated
	public BPMLendingDigitalSearchPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
		testContext.scenarioContext.setContext(TestData.PageName, "BPMLendingDigitalSearchPage");
	}
		
	@FindBy(how = How.XPATH, using = "(//h2)[2]")
	public WebElement txtH2Header;
	
	@FindBy(how = How.XPATH, using = "(//iframe)[2]")
	public WebElement swithFrame;
	
	@FindBy(how = How.XPATH, using = "//input[@id='text-input-InputApplicationId']")
	public WebElement txtApplicationId;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Search')]")
	public WebElement btnSearch;
	
	@FindBy(how = How.XPATH, using = "//table//tr/td[7]//span")
	public WebElement appStatus;
	//
	
	
	
	public void verifyBPMDigitalSearchPageIsDisplayed() throws Exception {		
		helper.initialisePage(driver, testContext, "LendingDigitalSearchPage");		
		try {	
			boolean result = driver.findElement(By.xpath("//span[contains(text(),'‪Lending Digital Search Screen‬')]")).isDisplayed();
			if(result==true)
			{
				System.out.println("Lending digital search screen is displayed");
			}
		}catch (Exception e) {
			e.printStackTrace();
			helper.failTest("BPM - Lending Digital Search page", "BPM Lending Digital Search page is not displayed", e.getMessage(), driver,testContext);
		}
	}
	
			
	public void inputApplicationId() throws Exception {
		try {		
			Thread.sleep(5000);
			driver.switchTo().frame(swithFrame);
			//String appId = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
			
			String appId = "DJ000404772";
			txtApplicationId.sendKeys(appId);			
			txtApplicationId.sendKeys(Keys.TAB);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}
	
	public void searchApplication() throws Exception {
		try {			
			btnSearch.click();
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}
	
	public void verifyApplicationStatus(String status) throws Exception {		
		helper.initialisePage(driver, testContext, "LendingDigitalSearchPage");		
		try {	
			helper.waitForLoadingElementInvisibility(driver);
			helper.waitForPageLoaded(driver);

			if(status.contains("Referred")){
				status = "LEAD REFERRED";
			}
			else if(status.contains("Application cancelled")){
				status = "APPLICATION CANCELLED";
			}
			else if(status.contains("Application declined")){
				status = "APPLICATION DECLINED";
			}
			else if(status.contains("Application fulfilled")){
				status = "APPLICATION ASSISTED FULFILLED";
			}
			System.out.println("==== EXPECTED STATUS: "+status);
			Thread.sleep(2000);
			String getApplicationStatus = appStatus.getText();		
			System.out.println("====  ACTUAL STATUS: "+getApplicationStatus);
			boolean expectedStatus=false;			
			if(getApplicationStatus.equalsIgnoreCase(status))
				expectedStatus = true;				
			if(expectedStatus == false)
				helper.failTest("BPM - Lending Digital Search page", "BPM - Application status is not displayed as expected", "", driver,testContext);				
		} catch (Exception e) {
			helper.failTest("BPM - Lending Digital Search page", "BPM - Application status is not displayed as expected", e.getMessage(), driver,testContext);
		}
	}

		
}

