package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.apache.tools.ant.taskdefs.condition.IsFileSelected;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class UB_LandingPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public UB_LandingPage(WebDriver driver, TestContext context) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	//Ulster-Welcome page Header
	@FindBy(how = How.XPATH, using = "//div[contains(@class, 'zb-heading1')]")
	public WebElement txtHeaderWithCustomerFN;

	@FindBy(how = How.XPATH, using = "//div[contains(@class, 'entity-company')]")
	public WebElement txtHeaderWithBusinessName;

	@FindBy(how = How.XPATH, using = "//div[contains(@class, 'zb-heading2 welcome-landing-item')]")
	public WebElement textHeaderSecondHeadingText;

	@FindBy(how = How.XPATH, using = "//div[contains(@class, 'zb-heading1')]")
	public WebElement txtHeaderTextMsg;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class, 'welcome-landing-item')])[2]")
	public WebElement textHeaderWelComeLandingItem;

	// Welcome page mid section
	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[1]")
	public WebElement txtViewYourQuotes;

	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[2]")
	public WebElement txtCallbackToDiscuss;


	@FindBy(how = How.XPATH, using = "(//div[starts-with(@class,'NextSteps_subText')])[3]")
	public WebElement txtAccessFundsIn24Hours;

	@FindBy(how = How.XPATH, using = "//div[starts-with(@class,'NextSteps_suitableText')]")
	public WebElement txtOnlineLEndingSuitableFor;


	@FindBy(how = How.XPATH, using = "//div[starts-with(@class,'NextSteps_applyText')]")
	public WebElement txtWhatYouMayNeedToApply;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class, 'contact-details-column')]/div)[2]")
	public WebElement customerEmail;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class, 'contact-details-column')]/div)[4]")
	public WebElement intCodedefault;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class, 'contact-details-column')]/div)[6]")
	public WebElement mobilePhoneNumber;

	@FindBy(how = How.XPATH, using = "//button[contains(text(), 'Edit details')]")
	public WebElement editdetails;

	@FindBy(how = How.XPATH, using = "//button[contains(text(), 'Get Started')]")
	public WebElement getStartedBtn;

	@FindBy(how = How.XPATH, using = "//input[contains(@class, 'confirm-to-continue-checkbox form-check-input')]")
	public WebElement confirmCheckBox;

	@FindBy(how = How.XPATH, using = "//label[@class='form-check-label']")
	public WebElement confirmCheckboxText;

	@FindBy(how = How.XPATH, using = "(//div[@class='validation-message']) [1]")
	public WebElement CheckboxValdationMsg;

	@FindBy(how = How.LINK_TEXT, using = "Business Banking Terms and Conditions")
	public WebElement businessBankingTermsandCondtionsLink;

	@FindBy(how = How.TAG_NAME, using = "a")
	public List<WebElement> allPdfDoclinks;

	@FindBy(how = How.LINK_TEXT, using = "A Guide to Business Banking Fees")
	public WebElement guidetoBusinessBankingFeesLink;

	@FindBy(how = How.LINK_TEXT, using = "Terms of Business")
	public WebElement termsOfBusinessLink;

	@FindBy(how = How.LINK_TEXT, using = "Central Credit Register Information")
	public WebElement centralCreditRegisterInfoLink;

	@FindBy(how = How.LINK_TEXT, using = "GDPR Privacy Booklet")
	public WebElement gDPRPrivacyBookletLink;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Invalid email address')]")
	public WebElement emailFieldValidationMessage;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Invalid phone number')]")
	public WebElement phoneFieldValidationMessage;

	// Welcome Page update details

	@FindBy(how = How.XPATH, using = "//button[text()='Try again']")
	public WebElement btnRetry;

	@FindBy(how = How.XPATH, using = "//button[text()='Get started']")
	public WebElement btnGetStarted;

	@FindBy(how = How.XPATH, using = "//button[text()='Update']")
	public WebElement btnUpdate;

	@FindBy(how = How.NAME, using = "emailAddress")
	public WebElement inputEmail;

	@FindBy(how = How.NAME, using = "phoneNumber")
	public WebElement inputMobileNumber;

	@FindBy(how = How.XPATH, using = "//a[text()='Request a callback']")
	public WebElement linkRequestCallback;

	@FindBy(how = How.XPATH, using = "//a[text() = 'Contact us']")
	public WebElement linkContactUs;

	@FindBy(how = How.XPATH, using = "//img[@alt='Exit']")
	public WebElement btnExit;

	// Added locators update dialog 120819
	@FindBy(how = How.ID, using = "email")
	public WebElement updateDialogMEmail;

	//@FindBy(how = How.XPATH, using = "//div[@class=' css-e56m7-control']/div[2]/div[@class=' css-tlfecz-indicatorContainer']")
	@FindBy(how = How.XPATH, using = "//div[@class=' css-e56m7-control']/div[1]")
	public WebElement IntCodeDropDownBtn;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Code')]/following::input[1]")
    public WebElement codeInput;

	@FindBy(how = How.XPATH, using = "//div[@class =' css-iosyzg-menu']")
	public WebElement intCodeList;

	@FindBy(how = How.ID, using = "phone")
	public WebElement updateDialogPhonetxtbox;

	@FindBy(how = How.ID, using = "//div[contains(@class,'css-1uccc91-singleValue')]")
	public WebElement defaultPopulatedIntCode;

	@FindBy(how = How.XPATH, using = "(//button[@class='zb-button zb-button-primary']) [2]")
	public WebElement updateDilaogUpdateBtn;

	@FindBy(how = How.XPATH, using = "//button[@class='close']")
	public WebElement updateDialogCloseBtn;

	@FindBy(how = How.XPATH, using = "//h5[contains(text(), 'Update contact details')]")
	public WebElement dialogHeader;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Personalise your quote')]")
	public WebElement quotePageHeader;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'+353')]")
	public WebElement defaultIntCode;

	@FindBy(how = How.XPATH, using = "//div[contains(text(), 'abc@test.com')]")
	public WebElement updatedEmail;

	@FindBy(how = How.XPATH, using = " //div[contains(text(), '345678121')]")
	public WebElement updatedContactNumber;

	@FindBy(how = How.XPATH, using = "//div[@class='zb-heading1 appendix-header']")
	public WebElement inProgressPageHeader;

	@FindBy(how = How.XPATH, using = "//div[@class='zb-heading3 existing-application-number']")
	public WebElement applicationNumber;

	public void updateDetailsOnLandingPage(String email, String mobileNumber) throws Exception {

		try {

//			JavascriptExecutor jse = (JavascriptExecutor) driver;
//			jse.executeScript("arguments[0].scrollIntoView(true);", linkRequestCallback);
//			Thread.sleep(2000);

			if (helper.isElementPresent(editdetails, driver)) {
				helper.clickAnyButtonInDigitalJourney("Editdetails", driver, testContext);

			} else {


				Thread.sleep(1000);
				helper.enterValue(inputEmail, email);

				// Select the country code from drop downlist
				driver.findElement(By.xpath("//div[@class='zb-dropdown-list zb-has-scrollbar']/ul/li/div[contains(text(),'+30')]")).click();

				helper.enterValue(inputMobileNumber, mobileNumber);

				btnUpdate.click();
				helper.clickAnyButtonInDigitalJourney("Get started", driver, testContext);

			}
		} catch (Exception e) {
			e.printStackTrace();
			helper.failTest("Landing Page", "Landing Page", e.getMessage(), driver, testContext);
		}

	}
    public void enterValidEmail(String ValidEmail) throws Exception {

        try {
            helper.waitForWebElementToBeVisible(driver, updateDialogMEmail);
            updateDialogMEmail.clear();
            updateDialogMEmail.sendKeys(ValidEmail);

        } catch (Exception e) {
            helper.failTest("Email ", "Failed to enter emailId into contact details dialog email field ", e.getMessage(), driver, testContext);
        }
    }

	public void enterInValidEmail(String InValidEmailID) throws Exception {

		try {
			helper.waitForWebElementToBeVisible(driver, updateDialogMEmail);
			updateDialogMEmail.clear();
			updateDialogMEmail.sendKeys(InValidEmailID);
			Thread.sleep(1000);

		} catch (Exception e) {
			helper.failTest("Email ", "Failed to enter emailId into contact details dialog email field ", e.getMessage(), driver, testContext);
		}

	}
     public void editIntCodeAndEnterValidNumber(String IntCode, String ValidPhoneNumber) throws Exception {
	 	try {

	 		helper.waitForWebElementToBeVisible(driver, IntCodeDropDownBtn);
            IntCodeDropDownBtn.click();
			Thread.sleep(1000);
            driver.findElement(By.xpath("//div[text()='+44']")).click();
            Thread.sleep(1000);
			updateDialogPhonetxtbox.clear();
			updateDialogPhonetxtbox.sendKeys("1234567890");
			Thread.sleep(1000);
			updateDilaogUpdateBtn.click();

		    } catch (Exception e)
		    {
				helper.failTest("IntCode ", "Failed to select intcode into contact details dialog IntCode field ", e.getMessage(), driver, testContext);
			}
		}



	public void enterPhoneNumber(String PhoneNumber) throws Exception {

		try {
			//helper.waitForWebElementToBeVisible(driver, updateDialogPhonetxtbox);
			updateDialogPhonetxtbox.click();
			updateDialogPhonetxtbox.clear();
			Thread.sleep(1000);
			updateDialogPhonetxtbox.sendKeys(PhoneNumber);

		} catch (Exception e) {
			helper.failTest("phonenumber ", "Failed to enter phonenumber into contact details dialog phoneNumber field ", e.getMessage(), driver, testContext);
		}

	}

	public void initialiseLandingPage() throws Exception {
		helper.waitForLoadingElementInvisibility(driver);

		//capture BIN
		helper.captureBIN(testContext, driver);

		// Read Application ID and write to excel
		Thread.sleep(1000);
		helper.captureApplicationID(testContext, driver);

		// initiate page
		helper.initialisePage(driver, testContext, "Landing");
	}


	public void verifyPalMessageOnLandingPage() throws Exception {
		initialiseLandingPage();

		String msg = txtHeaderTextMsg.getText();

		if (!msg.contains("we could lend your business"))
			helper.failTest("Landing Page", "Landing Page Pal message displayed", "Landing Page Pal message NOT displayed", driver, testContext);


		String palAmount = msg.substring(msg.indexOf("£") + 1, msg.length() - 1).replace(",", "").trim();
		if (!(Integer.parseInt(palAmount) > 0))
			helper.failTest("Landing Page", "Landing Page Pal Amount is displayed", "Landing Page Pal Amount is NOT displayed", driver, testContext);


	}

	public void verifyNonPalMessageOnLandingPage() throws Exception {

		initialiseLandingPage();

		if (!txtHeaderTextMsg.getText().contains("your business could get a borrowing quote in 3 minutes "))
			helper.failTest("Landing Page", "Landing Page PAL message not displayed", "Landing Page Pal message IS displayed", driver, testContext);


	}


	public void VerifyWelcomePageDisplayElements() throws Exception {
		boolean elementDisplayError = false;
		String ErrorString = "";

		try {

			//header text based on dev mock build -08082019
			if (!txtHeaderWithCustomerFN.getText().contains("Hello Dave")) {
				elementDisplayError = true;
				ErrorString += "Welcome page first header mising customer first name";
			}
			if (!txtHeaderWithBusinessName.getText().contains("Uppercutts ltd")) {
				elementDisplayError = true;


				ErrorString += "Welcome page header text missing business name";
			}
			if (!textHeaderSecondHeadingText.getText().contains("We have a variety of borrowing options, ranging from €500 to €50,000 for up to a period of 7 years. Borrowing amounts have to be in increments of €50.")) {
				elementDisplayError = true;
				ErrorString += "Welcome page second header missing text";
			}
			if (!customerEmail.getText().contains("dave@email.com")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing with customer email";
			}
			if (!intCodedefault.getText().contains("+353")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing with Int code";
			}
			if (!mobilePhoneNumber.getText().contains("345678121")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing mobile phone number";

			}
			if (!textHeaderWelComeLandingItem.getText().contains("You can apply for lending larger than €50,000 and for longer than 7 years. To do that you will need to contact us on: 1850 211 690")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing landing item text ";
			}
			if (!editdetails.getText().contains("Edit details")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing edit details button";
			}

			if (!confirmCheckboxText.getText().contains("I confirm that I have printed or downloaded and saved a copy of the above documents and that on completing this application I will be bound by the terms contained in these documents")) {
				elementDisplayError = true;
				ErrorString += "Welcome page missing text of checkbox txt'";

			}


			if (elementDisplayError == true)
				helper.failTest("Welcome Page", "Welcome Page elements or text not present", ErrorString, driver, testContext);

		} catch (Exception e) {

			helper.failTest("Welcome Page", "Landing Page", e.getMessage(), driver, testContext);
		}

	}


	public void verifyUpdateDetailsDialogDisplayed() throws Exception {

		helper.getLatestWindowFocused(driver);
		//helper.getURLLink();
		driver.switchTo().activeElement();
		Thread.sleep(1000);
		{
			if (!dialogHeader.isDisplayed())
				helper.failTest("update details dialog", "update details dialog displayed", "update details dialog doesn't displayed", driver, testContext);
		}


	}
	public void verifyDisplayedUpdateDetailsDialogElements() throws Exception {
       helper.waitForLoading(driver);
		helper.getLatestWindowFocused(driver);
		//helper.getURLLink();
		driver.switchTo().activeElement();
		Thread.sleep(1000);
		{
			if (!dialogHeader.isDisplayed())
				helper.failTest("update details dialog", "update details dialog displayed", "update details dialog doesn't displayed", driver, testContext);
		}
		boolean elementDisplayError = false;
		String ErrorString = "";

		try {

			if (!updateDialogMEmail.isDisplayed()) {
				elementDisplayError = true;
				ErrorString += "Welcome Page update contact details dialog missing email field";
			}
			if (!IntCodeDropDownBtn.isDisplayed() && !defaultPopulatedIntCode.getText().contains("+353")) {
				elementDisplayError = true;
				ErrorString += "Welcome Page update contact details dialog missing Int Code field and default code";
			}
			if (!updateDialogPhonetxtbox.isDisplayed()) {
				elementDisplayError = true;
				ErrorString += "Welcome Page update contact details dialog missing phone field";
			}
			if (!updateDilaogUpdateBtn.getText().contains("Update")) {
				elementDisplayError = true;
				ErrorString += "Welcome Page update contact details dialog missing update button";
			}
			if (!updateDialogCloseBtn.isDisplayed()) {
				elementDisplayError = true;
				ErrorString += "Welcome Page update contact details dialog missing close button";
			}
			if (elementDisplayError == true)
				helper.failTest("Update contact details ", "Welcome Page update contact details dialog missing elements", ErrorString, driver, testContext);

		} catch (Exception e) {

			helper.failTest("Update contact details", "Welcome page Update conatct details dialog", e.getMessage(), driver, testContext);
		}
	}

	/*
	Below method will delete all files in given directory path
	 */
	public void deleteAllFilesFromDir() {
		Arrays.stream(new File("D:\\Users\\kumaspd\\AppData\\Local\\Temp\\Downloads\\").listFiles()).forEach(File::delete);
	}

	/*
     Download all files and print them in console

     */
	public void verifydownloadedguideDocuments() throws Exception {
		try {

			deleteAllFilesFromDir();
			helper.waitForLoading(driver);
			//for (WebElement link : allPdfDoclinks) {
			//if ((link.getText().contains("Business Banking Terms and Conditions") && link.getText().contains("A Guide to Business Banking Fees") &&  (link.getText().contains("Terms of Business") && (link.getText().contains("Central Credit Register Information") && (link.getText().contains("GDPR Privacy Booklet"))))))
			//{
					businessBankingTermsandCondtionsLink.click();
					Thread.sleep(1000);
					guidetoBusinessBankingFeesLink.click();
					Thread.sleep(1000);
					termsOfBusinessLink.click();
					Thread.sleep(1000);
					centralCreditRegisterInfoLink.click();
					Thread.sleep(1000);
					gDPRPrivacyBookletLink.click();
					Thread.sleep(1000);

				//}

				File[] files = new File("D:\\Users\\kumaspd\\AppData\\Local\\Temp\\Downloads").listFiles();
				showFiles(files);


		} catch (Exception e) {

			helper.failTest("Landing Page", "Landing Page failed to download documents", e.getMessage(), driver, testContext);
		}

	}

	public void showFiles(File[] files) {
		for (File file : files) {
			if (file.isDirectory()) {
				System.out.println("Directory: " + file.getName());
				showFiles(file.listFiles());
			} else {
				System.out.println("File: " + file.getName());
			}
		}
	}


//		//String fileName = getLatestFile.getName();
//		File file2 = new File("D:\\Users\\kumaspd\\AppData\\Local\\Temp\\Downloads\\business-banking-terms-and-conditions-ULST7884RI.pdf");
//		if(file2.delete())
//			System.out.println("file2 deleted");
//		if(file2.exists())
//			System.out.println("file exists");
//		Thread.sleep( 1000);
//		if(helper.isElementPresent(guidetoBusinessBankingFeesLink,driver))
//			helper.clickAnyLinkInDigitalJourney(  " A Guide to Business Banking Fees", driver, testContext);
//		Thread.sleep(1000);
//		if(helper.isElementPresent(termsOfBusinessLink,driver))
//			helper.clickAnyLinkInDigitalJourney( "Terms of Business", driver, testContext);
//		Thread.sleep(1000);
//		if(helper.isElementPresent(centralCreditRegisterInfoLink,driver))
//			helper.clickAnyLinkInDigitalJourney("Central Credit Register Information", driver, testContext);
//		Thread.sleep(1000);
//		if(helper.isElementPresent(gDPRPrivacyBookletLink,driver))
//			helper.clickAnyLinkInDigitalJourney( "GDPR Privacy Booklet", driver, testContext);
//		Thread.sleep(1000);


	//System.out.println("file not deleted");
		/*if(helper.isElementPresent(guidetoBusinessBankingFeesLink,driver))
 	helper.clickAnyLinkInDigitalJourney( "A Guide to Business Banking Fees", driver, testContext);*/

	public void verifyMessageOnLandingPage(String messageToVerify) throws Exception {
		helper.waitForLoading(driver);

		initialiseLandingPage();

		if (driver.getCurrentUrl().contains("welcome")) {

			String LandingPageText = driver.findElement(By.xpath("//h1")).getText();
			String PALText = driver.findElement(By.xpath("(//h2)[2]")).getText();


			helper.resetImplicitTimeoutToDefault(driver);

			if (!(PALText.toLowerCase().contains(messageToVerify.toLowerCase()))) {
				helper.failTest("Correct landing page message should be displayed", PALText, messageToVerify, driver, testContext);
			}

		} else if (driver.getCurrentUrl().contains("error")) {
			helper.failTest("Sorry, something's gone wrong page is displayed",
					"Sorry, something's gone wrong page is displayed", "", driver, testContext);
		} else if (driver.getCurrentUrl().contains("welcome")) {
			helper.failTest("Welcome page is displayed", "Welcome page is displayed", "", driver, testContext);
		} else if (driver.getCurrentUrl().contains("ineligibleDJ")) {
			helper.failTest("Ineligible page is displayed", "Ineligible page is displayed", "", driver, testContext);
		}
	}

	public void VerifyInprogressPageHeaderDisplayed() throws Exception {

		if (!inProgressPageHeader.getText().equalsIgnoreCase("Your Application is in progress"))
			helper.failTest("Application In Progress Page not displayed", "Application In Progress Page not displayed",
					"", driver, testContext);

		//helper.clickAnyButtonInDigitalJourney("Continue application", driver, testContext);

	}

	public void verifyApplicationNumber() throws Exception
	{
		String TxtWithAppNumber =  applicationNumber.getText();
		String AppNumber = TxtWithAppNumber.substring(21, 33);
		if(applicationNumber != null)
		{
			System.out.println("Application number---->"+AppNumber);
		}
		else
		{
			helper.failTest("Application number doesn't displayed", "Application number doesn't displayed",
					"", driver, testContext);
		}
	}
	public void continueApplicationScreenDisplayedAndClickCancel() throws Exception {

		if (!driver.findElement(By.xpath("//span[@class='zb-card-header-title']")).getText()
				.equalsIgnoreCase("Application in progress"))
			helper.failTest("Application In Progress Page not displayed", "Application In Pro+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++gress Page not displayed",
					"", driver, testContext);


		driver.findElement(By.id("manualBusiness")).click();

		driver.findElement(By.xpath("//button[@class='zb-button zb-button-secondary' and text()='Confirm cancellation']")).click();

		driver.findElement(By.xpath("//*[text()='Other']")).click();

		driver.findElement(By.xpath("//textarea")).sendKeys("test");

		helper.clickAnyButtonInDigitalJourney("Confirm cancellation", driver, testContext);

		driver.findElement(By.xpath("//button[@class='zb-button zb-button-secondary']")).click();

		Thread.sleep(1000);

		driver.findElement(By.xpath("//h1")).click();

		Thread.sleep(1000);

		driver.findElement(By.xpath("//button[text()='Start new application']")).click();


	}

	public void verifyLandingPage() throws Exception {
		if (!txtHeaderTextMsg.isDisplayed())
			helper.failTest("Landing Page", "Landing Page is Expected", "Landing Page is not displayed", driver, testContext);
		initialiseLandingPage();

	}

	public void verifyLandingPageCheckbox() throws Exception {
		{
			if (!confirmCheckBox.isDisplayed())
				helper.failTest("LandingPage", "Landing Page checkbox displayed", "Landing Page checkbox doesnot displayed", driver, testContext);
		}
	}

	public void verifyUncheckCheckboxValidationMsg() throws Exception {
		{
			if (!CheckboxValdationMsg.isDisplayed())
				helper.failTest("LandingPage", "Landing Page uncheckbox Validation message displayed", "Landing Page uncheckbox validation message doesn't displayed", driver, testContext);
		}
	}

	public void verifyEmailFiledValidationMsg(String EmailFieldValMsg) throws Exception {
		{
			if (!emailFieldValidationMessage.getText().equalsIgnoreCase(EmailFieldValMsg))
				helper.failTest("update contact details dialog", "Update contact details phone field validation message displayed", "Update contact details email field validation message doesn't displayed", driver, testContext);
		}
	}
    public void verifyUpdateddetails() throws Exception {
        helper.waitForLoading(driver);
        helper.waitForWebElementToBeVisible(driver, editdetails);
        helper.scrollToElement(driver, editdetails);
        if (!updatedEmail.getText().equalsIgnoreCase("abc@test.com") && (!updatedContactNumber.getText().equalsIgnoreCase("345678121"))) {
            helper.failTest("updated contact details", "Updated contact details email and phonenumber are not displayed", "Updated contact details email and phonenumber are not displayed", driver, testContext);

        }
    }


	public void verifyPhoneFieldValidationMsg(String ValMsg) throws Exception {
		{
			Thread.sleep(1000);
			if (!phoneFieldValidationMessage.getText().equalsIgnoreCase(ValMsg))
				helper.failTest("update contact details dialog", "Update contact details phone field validation message displayed", "Update contact details phone field validation message doesn't displayed", driver, testContext);
		}
	}

	public void selectConfirmCheckBox() throws Exception {

		try {
			helper.waitForWebElementToBeVisible(driver, confirmCheckBox);
			Thread.sleep(2000);
			confirmCheckBox.click();

		} catch (Exception e) {
			helper.failTest("checkbox failed to select ", "landing page confirm to continue checkbox failed to select ", e.getMessage(), driver, testContext);
		}
	}

	public void clickonGetStartedBtn() throws Exception {

		try {
			helper.waitForWebElementToBeVisible(driver, getStartedBtn);
			helper.scrollToElement(driver, getStartedBtn);
			Thread.sleep(2000);
			getStartedBtn.click();

		} catch (Exception e) {
			helper.failTest("Get started button click failed ", "Landing page get started button failed to click ", e.getMessage(), driver, testContext);
		}
	}

	public void verifyDisplayedQuotePage() throws Exception {

		if (quotePageHeader.isDisplayed()) {
			String headerText = quotePageHeader.getText();
			Assert.assertEquals(headerText, "Personalise your quote");
		} else {
			Assert.fail("quote page header doesn't displayed");
		}
		//driver.quit();
	}

	public void clickEditDetails() throws Exception {

		try {
			helper.scrollToElement(driver,editdetails);
			helper.waitForWebElementToBeVisible(driver, editdetails);
			Thread.sleep(1000);
			editdetails.click();

		} catch (Exception e) {
			helper.failTest("edit details button click failed ", "Landing page edit details button failed to click ", e.getMessage(), driver, testContext);
		}
	}

	public void verifyDisplayedPage(String rptpage) throws Exception {

		initialiseLandingPage();

		String segment = (String) testContext.scenarioContext.getContext(TestData.Segment);

		String page = null;
		String url = driver.getCurrentUrl();
		if (rptpage.contains("welcome")) {
			page = "welcome";
		} else if (rptpage.contains("landing")) {
			page = "welcomeDJ";
		} else if (rptpage.contains("AJ")) {
			page = "ineligible";
		} else if (rptpage.contains("hardstop")) {
			page = "inEligible";
		}

		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);

		if (url.contains(page)) {

			if (url.contains("error")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
					// commoncomps.failTest("Technical error page is displayed
					// incorrectly instead of " + rptpage + " page", "Technical
					// error page is displayed incorrectly instead of " +
					// rptpage + " page", "", driver);
				}
			} else if (url.contains("ineligible")) {
				if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail("Page is displayed incorrectly instead of " + rptpage + " page");
					// commoncomps.failTest("Page is displayed incorrectly
					// instead of " + rptpage + " page", "Page is displayed
					// incorrectly instead of " + rptpage + " page", "",
					// driver);
				}
			} else if (url.contains("inEligible?reason=personal")) {
				Assert.fail("Sorry - for business account holders only page is displayed incorrectly instead of "
						+ rptpage + "page");
				// commoncomps.failTest("Sorry - for business account holders
				// only page is displayed incorrectly instead of " + rptpage +
				// "page", "Sorry - for business account holders only page is
				// displayed incorrectly instead of " + rptpage + "page", "",
				// driver);
			} else {
				if (segment.equalsIgnoreCase("ONECONNECT")) {
					if (url.contains("welcomeDJ")) {
						Assert.fail("Landing page is displayed incorrectly instead of " + rptpage + " page");
						// commoncomps.failTest("Landing page is displayed
						// incorrectly instead of " + rptpage + " page",
						// "Landing page is displayed incorrectly instead of " +
						// rptpage + " page", "", driver);
					}
				} else if (!(segment.equalsIgnoreCase("ONECONNECT"))) {
					if (!(url.contains("welcome"))) {
						Assert.fail("Welcome page is displayed incorrectly instead of " + rptpage + " page");
						// commoncomps.failTest("Welcome page is displayed
						// incorrectly instead of " + rptpage + " page",
						// "Welcome page is displayed incorrectly instead of " +
						// rptpage + " page", "", driver);
					}
				}
			}
			System.out.println(rptpage + " page is displayed as expected for the " + segment);
		} else if (url.contains("inEligibleInprogress")) {
			Assert.fail("Application in progress page is displayed incorrectly instead of " + rptpage + " page");
		} else {
			System.out.println("Incorrect page is displayed - " + url + "\nExpected page is  - " + rptpage + " for the "
					+ segment + " Customer");
			if (url.contains("welcomeDJ")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("Landing page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("welcome")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("welcome page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("ineligible")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("ineligible page is displayed incorrectly instead of " + rptpage + " page");
				}
			} else if (url.contains("error")) {
				if (driver.findElement(By.xpath("//h1")).getText().equalsIgnoreCase("Sorry, something's gone wrong")) {
					Assert.fail("Technical error page is displayed incorrectly instead of " + rptpage + " page");
				} else if (driver.findElement(By.xpath("//h1")).getText()
						.equalsIgnoreCase("Your application is in progress")) {
					Assert.fail(
							"Application in progress page is displayed incorrectly instead of " + rptpage + " page");
				} else {
					Assert.fail("error page is displayed incorrectly instead of " + rptpage + " page");
				}
			}
		}

		//btnExit.click();

	}

	public void editIntCodeAndEnterValidNumber(String validPhoneNumber) throws Exception {
		try {

			helper.waitForWebElementToBeVisible(driver, IntCodeDropDownBtn);
			updateDialogPhonetxtbox.clear();
			updateDialogPhonetxtbox.sendKeys(validPhoneNumber);
			Thread.sleep(1000);
			updateDilaogUpdateBtn.click();

		} catch (Exception e)
		{
			helper.failTest("IntCode ", "Failed to enter phone no into contact details dialog  ", e.getMessage(), driver, testContext);
		}

	}
}

