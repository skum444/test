package com.rbs.automation.dj.pages;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.testcontext.TestContext;

public class AccountDetailsPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();

	// initialise the page elements when the class is instantiated
	public AccountDetailsPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	
	// Personalised Quote Row headers
		@FindBy(how = How.XPATH, using = "//div/p[contains(text(),'Which account would you like')]/following::input[1]")
		public WebElement inputAccountDD;
		
		
		

		
	
	
	public void selectBankAccount(String accountString) throws InvalidFormatException
	{
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		inputAccountDD.click();
		driver.findElement(By.xpath("//div[contains(text(),'"+accountString+"')]")).click();
		
	}
	
	
	public void AccountDetails_ClickContinue() 	throws Exception {
		try
		{
						
			helper.setImplicitTimeout(driver, 1);
			
			if(driver.findElements(By.xpath("//Button[text() = 'Complete Application']")).size()!=0)
			{
				helper.clickAnyButtonInDigitalJourney("Complete Application",driver,testContext);
			}
		
			helper.resetImplicitTimeoutToDefault(driver);

		}
		catch ( Exception e)
		{
			helper.failTest("Account details page", "Complete Application Button is not displayed", e.getMessage(), driver,testContext);
		}
		
	}

	
	
	public void verifyAccountDetailsPageIsDisplayed() throws Exception {
		
		helper.initialisePage(driver, testContext, "AccountDetails");
		
	
		
		try {
			String accountDetailHeader = driver.findElement(By.xpath("//h1")).getText();		
			helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
			
			if(!accountDetailHeader.contains("Account details"))
				helper.failTest("Account details page", "Account details page is not displayed", "", driver,testContext);
		
				
		} catch (Exception e) {

			helper.failTest("Account details page", "Account details page is not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	
	
	
	
	

}
