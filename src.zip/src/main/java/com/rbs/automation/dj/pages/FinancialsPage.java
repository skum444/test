package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.enums.TestData;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.FileReaderManager;

import java.util.*;
import java.text.SimpleDateFormat;

public class FinancialsPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	public static String tooltipValidationStatus = "";
	public static String validationStatus = "";
	public static String latestFinancialsStatus = "";
	public static String reportDateStatus = "";
	public static String applStatusReasonVal = "";
	public static String consentTextValidation = "";
	private static Map<String, String> actualDesciptions = new HashMap<>();
	private static String updatedTurnover;
	private static String updatedCOS;
	private static String updatedOverheads;
	private static String prevCos;
	private static String prevOverheads;
	private static String prevTurnover;
	private static boolean criteriaA = false;
	private static boolean criteriaB = true;
	Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();

	// initialise the page elements when the class is instantiated
	public FinancialsPage(WebDriver driver, TestContext context) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	// Financials page Header
	@FindBy(how = How.XPATH, using = "(//h1)")
	public WebElement txtHeader;

	@FindBy(how = How.XPATH, using = "(//span[@class='zb-card-header-title'])")
	public WebElement blockCustomerHeader;

	@FindBy(how = How.XPATH, using = "(//h3)")
	public WebElement fiSubHeader;

	@FindBy(how = How.XPATH, using = "//h2[contains(text(),\"What you'll need to supply\")]")
	public WebElement modalHeader;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'Turnover')]/following::input[2]")
	public WebElement turnover;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'cell FinancialTableRow_finacialValue')]//a[contains(text(),'Edit')]")
	public List<WebElement> linkEdit;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'TotalRemuneration')]/following::input[2]")
	public WebElement totalRemuneration;

	@FindBy(how = How.XPATH, using = "//button[text()='Check eligibility']")
	public WebElement btnCheckEligibility;

	@FindBy(how = How.XPATH, using = "//button[text()='Confirm and continue']")
	public WebElement btnConfirmandContine;

	@FindBy(how = How.XPATH, using = "//button[text()='Calculate projected financials']")
	public WebElement btnCalcProjFin;

	@FindBy(how = How.XPATH, using = "//section[@role='tooltip']//p")
	public WebElement tooltip1;

	@FindBy(how = How.XPATH, using = "//section[@role='tooltip']")
	public WebElement tooltip2;

	@FindBy(how = How.XPATH, using = "//div[@class='cell FinancialTableRow_finacialValue__2EuQE FinancialTableRow_hideCell__2QChu cellView']")
	public List<WebElement> latestFinancials;

	@FindBy(how = How.XPATH, using = "//div[text()='Projected financials']//following::div[2]")
	public WebElement reportingDate;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'FinancialConfirmConsent_consentContainer')]//p")
	public List<WebElement> consentConfirmationText;

	@FindBy(how = How.XPATH, using = "section//span//p")
	public List<WebElement> modalText;

	@FindBy(how = How.XPATH, using = "//button[contains(@aria-label,'need to supply')]//*[local-name() = 'svg']")
	public WebElement btnCloseModal;

	@FindBy(how = How.XPATH, using = "//ul[@class='zb-select-dropdown-list']//li")
	public List<WebElement> updateReasonDropDown;

	@FindBy(how = How.NAME, using = "additionalDetails")
	public WebElement txtAreaAdditionalDetails;

	@FindBy(how = How.XPATH, using = "//header//span")
	public WebElement emailSentHeader;

	@FindBy(how = How.XPATH, using = "//a[@class='zb-flyout-close-button']//*[local-name() = 'svg']")
	public WebElement closeDescModal;

	@FindBy(how = How.NAME, using = "emailAddress")
	public WebElement email;

	@FindBy(how = How.NAME, using = "phoneNumber")
	public WebElement phone;

	@FindBy(how = How.XPATH, using = "//div[@class='countryCodeContainer']//div[@class='mobileDropDown']//input")
	public WebElement countryCode;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'need to supply')]")
	public WebElement needToSupplyLink;

	public void inputProjectedFinancials(String turnoverVal) throws Exception {
		turnover.sendKeys(turnoverVal);
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		// Thread.sleep(60000);
		btnCalcProjFin.click();
		// helper.clickAnybuttonInDigitalJourney("Calculate projected financials",
		// driver, testContext);

	}

	public void isTurnoverDisplayed() throws Exception {
		if (!turnover.isDisplayed()) {
			helper.failTest("Projected Financial-Turnover is not displayed",
					"Projected Financial-Turnover is displayed", "Projected Financial-Turnover is not displayed",
					driver, testContext);
		}
	}

	public void validateProjectedFinancials(String turnoverVal) throws Exception {
		// Validate Project Turnover
		String expProjTurnover = "£" + turnoverVal.substring(0, indexOfDot(turnoverVal));
		String actualProjTurnover = returnProjectedFiancials("Turnover").replaceAll(",", "");
		if (!actualProjTurnover.equals(expProjTurnover)) {
			helper.failTest("Projected Turnover is incorrect", expProjTurnover, actualProjTurnover, driver,
					testContext);
		}
		Double projTurnover = new Double(actualProjTurnover.replaceAll("[,£]", ""));
		Double latTurnover = new Double(returnLatestFiancials("Turnover").replaceAll("[,£]", ""));
		Double scalingFactor = projTurnover / latTurnover;
		// System.out.println("--------Trunover---"+expProjTurnover);
		// Cost of Sale
		Double expProjSaleCostVal = (new Double((returnLatestFiancials("Cost of sales").replaceAll("[,£]", ""))))
				* scalingFactor;
		String expProjSaleCost = (expProjSaleCostVal.toString().substring(0,
				indexOfDot(expProjSaleCostVal.toString())));
		String actProjSaleCost = (returnProjectedFiancials("Cost of sales").replaceAll("[,]", ""));
		if (!actProjSaleCost.equals("£" + expProjSaleCost)) {
			helper.failTest("Projected Cost of sales is incorrect", expProjSaleCost, actProjSaleCost, driver,
					testContext);
		}
		// System.out.println("--------COS---"+expProjSaleCostVal);
		// Overheads
		Double expOverheadsVal = (new Double(returnLatestFiancials("Overheads").replaceAll("[,£]", "")))
				* scalingFactor;
		String expOverheads = (expOverheadsVal.toString().substring(0, indexOfDot(expOverheadsVal.toString())));
		String actOverheads = (returnProjectedFiancials("Overheads").replaceAll("[,]", ""));
		if (!actOverheads.equals("£" + expOverheads)) {
			helper.failTest("Projected Overheads is incorrect", expOverheads, actOverheads, driver, testContext);
		}
		// System.out.println("--------Overhead---"+expOverheadsVal);
		calcNonEditableFinancials(projTurnover, new Double(expProjSaleCost), new Double(expOverheads));
	}

	public void checkEditableFields() throws Exception {
		isEditable("Turnover", true);
		isEditable("Net profit margin", false);
		isEditable("Overheads", true);
		isEditable("Net profit/(Loss)", false);
		isEditable("Cost of sales", true);
		isEditable("Gross profit/(Loss)", false);
		isEditable("Gross profit margin", false);
	}

	private int indexOfDot(String value) {
		return value.indexOf('.') != -1 ? value.indexOf('.') : value.length();

	}

	private String returnLatestFiancials(String field) {
		WebElement option = driver.findElement(By.xpath("//*[contains(text(), '" + field + "')]/following::div[1]"));
		return option.getText();
	}

	private String returnProjectedFiancials(String field) {
		WebElement option = driver
				.findElement(By.xpath("//*[contains(text(), '" + field + "')]//.//following::div[2]//span"));
		return option.getText().split("Edit")[0];
	}

	private void isEditable(String field, boolean expVal) throws Exception {
		By by = By.xpath("//*[contains(text(), '" + field + "')]/following::div[2]//span//a[contains(text(),'Edit')]");
		boolean found = helper.isElementPresent(by, driver);

		if (found != expVal)
			if (!expVal)
				helper.failTest(field + " Editable options are incorrect", field + " is not editable",
						field + " is editable", driver, testContext);
			else
				helper.failTest(field + " Editable options are incorrect", field + " is editable",
						field + " is not editable", driver, testContext);
		else
			System.out.println("Edit Option As Expected for " + field);
	}

	public void verifyFinancialsPageIsDiplayedPage() throws Exception {
		// initiate page
		helper.initialisePage(driver, testContext, "Your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			Thread.sleep(5000);
			if (!(txtHeader.getText().contains("Your financials"))) {
				helper.failTest("Financials page is not displayed", "Financials page should be displayed",
						"Financials page is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Financials page is not displayed", "Financials page is displayed", e.getMessage(), driver,
					testContext);
		}
	}

	public void verifyNoFIHeaderIsDisplayed() throws Exception {
		// initiate page
		helper.initialisePage(driver, testContext, "Your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			if (!(fiSubHeader.getText()
					.contains("Unfortunately we do not hold any valid financials for your company"))) {
				helper.failTest("No FI Message is not displayed", "No FI Message should be displayed",
						"No FI Message is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("No FI Message is not displayed", "No FI Message is displayed", e.getMessage(), driver,
					testContext);
		}
	}

	public void verifyStaleoFIHeaderIsDisplayed() throws Exception {
		// initiate page
		helper.initialisePage(driver, testContext, "Your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			if (!(fiSubHeader.getText()
					.contains("We need up to date financials on your company to progress this application."))) {
				helper.failTest("Stale FI Message is not displayed", "Stale FI Message should be displayed",
						"Stale FI Message is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Staleo FI Message is not displayed", "Stale FI Message is displayed", e.getMessage(),
					driver, testContext);
		}
	}

	public void verifyCustBlockedIsDisplayed() throws Exception {
		helper.waitForLoadingElementInvisibility(driver);
		helper.captureBIN(testContext, driver);
		Thread.sleep(1000);
		helper.captureApplicationID(testContext, driver);

		helper.initialisePage(driver, testContext, "Your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			if (!(blockCustomerHeader.getText().contains("We need information from you"))) {
				helper.failTest("Block Customer Screen is not displayed", "Block Customer Screen should be displayed",
						"Block Customer Screen is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Block Customer Screen is not displayed", "Block Customer Screen is displayed",
					e.getMessage(), driver, testContext);
		}
	}

	public void clickIcon(List<String> fieldsList) throws Exception {

		for (String field : fieldsList) {
			try {
				// System.out.println("Getting Actual Deescription for "+field);
				WebElement option = driver
						.findElement(By.xpath("//span[contains(text(),'" + field + "')]/..//*[local-name() = 'svg']"));
				if (helper.isElementPresent(option, driver)) {
					option.click();
					helper.addfullScreenCaptureToExtentReport(driver, testContext);
				} else {
					helper.failTest("Question mark icon on Financials page is not displayed",
							"Question mark icon on Financials page IS displayed",
							"Question mark icon on Financials page is not displayed", driver, testContext);
				}

			} catch (Exception ex) {
				helper.failTest("Error clicking question mark icon of " + field, "Question mark icon is clicked",
						"Error clicking question mark icon", driver, testContext);
			}
			if (field.equals("Turnover") || field.equals("Cost of sales") || field.equals("Overheads"))
				actualDesciptions.put(field, tooltip1.getText());
			else
				actualDesciptions.put(field, tooltip2.getText());
			closeDescModal.click();
		}
	}

	public void validateFieldDescription() throws Exception {
		Map<String, List<String>> fieldDescValidation = new HashMap<>();
		for (Map.Entry<String, String> entry : actualDesciptions.entrySet()) {
			List<String> expectedDescription = new ArrayList<>();
			if (entry.getKey().equals("Turnover")) {
				expectedDescription.add("Turnover (also referred to as Revenue/Income/Sales)");
				expectedDescription.add("The total value of goods or services sold by the business during the year.");
				expectedDescription.add("Exclude:");
				expectedDescription.add("- VAT");
				expectedDescription.add("- Discounts received");
				expectedDescription.add(
						"- Income not related to principal activity of the business (for example, gains from sales of assets or rent)");
			} else if (entry.getKey().equals("Cost of sales")) {
				expectedDescription.add("Cost of sales (also referred to as variable or direct costs)");
				expectedDescription
						.add("Costs attributable to the production of goods sold by the business during the year.");
				expectedDescription.add("Exclude:");
				expectedDescription.add("- VAT");
				expectedDescription.add(
						"- Operating expenses (overheads/fixed or indirect) including distribution, marketing, administration and salaries");
			} else if (entry.getKey().equals("Gross profit/(Loss)")) {
				expectedDescription.add("Gross profit/(loss) is turnover less cost of sales.");
			} else if (entry.getKey().equals("Gross profit margin")) {
				expectedDescription.add(
						"Gross profit margin is calculated by dividing gross profit/(loss) by turnover, shown as a percentage.");
			} else if (entry.getKey().equals("Overheads")) {
				expectedDescription.add("Overheads (also referred to as operating expenses/fixed or indirect costs)");
				expectedDescription
						.add("Costs incurred through activity not associated with production of goods or services.");
				expectedDescription.add("Include general business costs such as:");
				expectedDescription.add("- Distribution costs");
				expectedDescription.add("- Marketing expenses");
				expectedDescription.add("- Administration expenses");
				expectedDescription.add("- Wages/salaries (including directors salaries)");
				expectedDescription.add("- Bad debt write offs");
				expectedDescription.add("- Corporation tax (limited companies only)");
				expectedDescription.add("- Depreciation/amortisation");
				expectedDescription.add("- Interest");
				expectedDescription.add("Exclude:");
				expectedDescription.add("- VAT");
			} else if (entry.getKey().equals("Net profit/(Loss)")) {
				expectedDescription.add("Net profit/(loss) is Gross profit/(loss) less overheads");
			} else if (entry.getKey().equals("Net profit margin")) {
				expectedDescription.add(
						"Net profit margin is calculated by dividing net profit/(loss) by turnover, shown as a percentage");
			}
			List<String> missing = new ArrayList<>();
			for (int i = 0; i < expectedDescription.size(); i++) {
				String expFragment = expectedDescription.get(i);
				if (!entry.getValue().contains(expFragment)) {
					missing.add(expFragment);
				}
			}
			if (missing.size() != 0)
				fieldDescValidation.put(entry.getKey(), missing);
		}
		if (fieldDescValidation.size() != 0) {
			for (Map.Entry<String, List<String>> incorrecrField : fieldDescValidation.entrySet()) {
				tooltipValidationStatus += "Field - " + incorrecrField.getKey() + "\nMissing:"
						+ incorrecrField.getValue() + "\nActual:" + actualDesciptions.get(incorrecrField.getKey())
						+ "\n\n";
			}
			helper.failTest("Financial Fiels description Failed", tooltipValidationStatus, "", driver, testContext);
		}
	}

	public void validateLatestFinancialsIsDisplayed() throws Exception {
		WebElement fieldName;
		for (WebElement item : latestFinancials) {
			if (!item.getText().isEmpty()) {
				fieldName = item.findElement(By.xpath("//preceding-sibling::div/span"));
				Double value = new Double(item.getText().replaceAll("[%,£]", ""));
				if (value.isNaN()) {
					latestFinancialsStatus += fieldName + " Latest Financial Data is not numeric:" + item.getText()
							+ "\n";
				}
			} else {
				latestFinancialsStatus += item.getText() + " Latest Financial Data is empty\n";
			}
		}
		if (latestFinancialsStatus.equals("")) {
			latestFinancialsStatus = "Latest Financials are displayed and are numeric";
		} else {
			helper.failTest(latestFinancialsStatus, "Latest Financial Data is numeric and not empty", "", driver,
					testContext);
		}
	}

	public void reportingPeriodIsDisplayed() throws Exception {
		if (!reportingDate.getText().isEmpty()) {
			String[] dates = reportingDate.getText().split("-");

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date todayDate = new Date();

			String today = sdf.format(todayDate);
			System.out.println(dates[0]);
			System.out.println(today);
			// Start date is today
			if (!today.equals(dates[0].trim())) {
				reportDateStatus = "Projected Financial Reporting Start Date is not today";
				helper.failTest("Projected Financial Reporting Start Date is not today", today, dates[0], driver,
						testContext);

			} else {
				Calendar c = Calendar.getInstance();
				c.setTime(sdf.parse(dates[0]));
				c.add(Calendar.DAY_OF_MONTH, 364);
				String newDate = sdf.format(c.getTime());
				if (!newDate.equals(dates[1].trim())) {
					reportDateStatus = "Projected Financial Reporting To Date is incorrect";
					helper.failTest("Projected Financial Reporting To Date is incorrect", newDate, dates[1], driver,
							testContext);
				}
			}
		} else {
			reportDateStatus = "Projected Financial Reporting Date Range is not displayed\n";
			helper.failTest("Projected Financial Reporting Date Range is not displayed",
					"Projected Financial Reporting Date Range should be displayed",
					"Projected Financial Reporting Date Range is not displayed", driver, testContext);
		}
		if (reportDateStatus.equals("")) {
			reportDateStatus = "Projected Financial Reporting Date is displayed as expected";
		}
	}

	public void clickConfirmAndContinue() throws Exception {
		// helper.clickAnyButtonInDigitalJourney("Confirm and continue", driver,
		// testContext);
		if (btnConfirmandContine.isDisplayed())
			btnConfirmandContine.click();
		else {
			helper.failTest("Projected Financial-Confirm and continue is not displayed",
					"Projected Financial-Confirm and continue is displayed",
					"Projected Financial-Confirm and continue is not displayed", driver, testContext);
		}
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	}

	public void confirmProjectedFinancials(String remuneration) throws Exception {
		try {
			if (totalRemuneration.isDisplayed()) {
				totalRemuneration.clear();
				totalRemuneration.sendKeys(remuneration);
				helper.clickAnyButtonInDigitalJourney("Confirm and continue", driver, testContext);
			} else {
				helper.failTest("Projected Financial-TotalRemuneration is not displayed",
						"Projected Financial-TotalRemuneration is displayed",
						"Projected Financial-TotalRemuneration is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Error confirming projected financials", "", e.getMessage(), driver, testContext);
		}

	}

	public void financialConsentIsDisplayed() throws Exception {
		if (btnCheckEligibility.isDisplayed()) {
			String expConsentMsg1 = "By selecting 'check eligibility' you confirm that the information presented to you and provided by you is correct. We'll use this to run a soft credit check to confirm your eligibility and provide your personalised products.";
			String expConsentMsg2 = "This soft search isn't visible to other companies and has no impact on your credit score or any future credit applications you might make.";

			String consentMsg1 = (consentConfirmationText.get(0)).getText();
			String consentMsg2 = (consentConfirmationText.get(1)).getText();
			System.out.println("---------------" + consentMsg1.trim().equals(expConsentMsg1));
			if (!consentMsg1.trim().equals(expConsentMsg1)) {
				consentTextValidation = "Consent Text Validation FAILED:Expected:" + consentMsg1 + ";Actual:"
						+ consentMsg1 + "\n";
			} else if (!consentMsg2.trim().equals(expConsentMsg2)) {
				consentTextValidation += "Consent Text Validation FAILED:Expected:" + consentMsg2 + ";Actual:"
						+ consentMsg2;
			} else {
				consentTextValidation += "Consent Text Validation PASSED";
			}
			if (consentTextValidation.contains("FAILED")) {
				helper.failTest("Financial Consent Text Validation Failed", consentTextValidation, "", driver,
						testContext);
			}
		} else {
			helper.failTest("Financial Consent Screen is not displayed", "Financial Consent Screen is displayed",
					"Financial Consent Screen is not displayed", driver, testContext);
		}
	}

	public void clickCheckEligibility() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Check eligibility", driver, testContext);
	}

	public void selectUpdateFinancials() throws Exception {
		helper.clickAnyLinkInDigitalJourney("Find out how", driver, testContext);

	}

	public void verifyUpdateFIScreenIsDisplayed() throws Exception {
		// initiate page
		helper.initialisePage(driver, testContext, "Update your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			if (!(txtHeader.getText().contains("Update your financials"))) {
				helper.failTest("Update your financials page is not displayed",
						"Update your financials page should be displayed",
						"Update your financials page is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Update your financials page is not displayed", "Update your financials page is displayed",
					e.getMessage(), driver, testContext);
		}
	}

	public void clickForInfoNeeded() throws Exception {

		try {
			needToSupplyLink.click();

		} catch (Exception e) {

			helper.failTest("What you'll need to supply Link click failed", "Link expected:What you'll need to supply",
					e.getMessage(), driver, testContext);
		}
	}

	public void verifyModalIsDisplayed() throws Exception {
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		if (!(modalHeader.getText().contains("What you'll need to supply"))) {
			helper.failTest("What you ll need to supply modal is not displayed",
					"What you'll need to supply modal should be displayed",
					"What you'll need to supply modal is not displayed", driver, testContext);
		}
	}

	public void validateModalText(String entity) throws Exception {
		List<String> expModalText = new ArrayList();
		expModalText.add("full balance sheet");
		expModalText.add("profit and loss statement");
		expModalText.add("These are usually prepared by your accountant, tax advisor or bookkeeper.");

		expModalText.add("If you only prepare abridged accounts, supply accountant's confirmation of:");
		expModalText.add("breakdown of debtors");
		expModalText.add("turnover");
		expModalText.add("cost of sales");
		expModalText.add("breakdown of operating expenses");
		expModalText.add("other operating income");

		if (entity.equals("PTN") || entity.equals("ST"))
			expModalText.add(
					"We require financials that are within 365 number of days from your company's most recent years end.");
		else if (entity.equals("LTD") || entity.equals("LLP"))
			expModalText.add(
					"We require financials that are within 270 number of days from your company's most recent years end.");

		for (int i = 0; i < expModalText.size(); i++) {
			WebElement modalTxtElement = null;
			String expText = expModalText.get(i);
			System.out.println(expText);
			try {
				if ((i == 0) || (i == 1)) {
					List<WebElement> liElement = driver.findElements(
							By.xpath("//section[contains(@class,'zb-modal-body')]//span//li[" + (i + 1) + "]"));
					modalTxtElement = liElement.get(0);
				} else if ((i == 4) || (i == 5)) {
					List<WebElement> liElements = driver.findElements(
							By.xpath("//section[contains(@class,'zb-modal-body')]//span//li[" + (i - 3) + "]"));
					modalTxtElement = liElements.get(1);
				} else if ((i == 6) || (i == 7) || (i == 8)) {
					List<WebElement> liElement = driver.findElements(
							By.xpath("//section[contains(@class,'zb-modal-body')]//span//li[" + (i - 3) + "]"));

				} else if (i == 9) {
					modalTxtElement = driver.findElement(
							By.xpath("//section[contains(@class,'zb-modal-body')]//span//p[" + (i - 6) + "]"));
				} else {
					modalTxtElement = driver.findElement(
							By.xpath("//section[contains(@class,'zb-modal-body')]//span//p[" + (i - 1) + "]"));
				}
			} catch (Exception e) {
				validationStatus = "Modal Text Missing:Expected:" + expText + ";Actual:" + e.getMessage();
				helper.failTest("Modal Text Missing", expText, e.getMessage(), driver, testContext);
			}
			if (modalTxtElement != null) {
				String actualText = modalTxtElement.getText();
				if (!actualText.equals(expText)) {
					validationStatus = "Modal Text Validation Failed:Expected:" + expText + ";Actual:" + actualText;
					helper.failTest("Modal Text Validation Failed", expText, actualText, driver, testContext);
				}
			}
		}
	}

	public void closeModal() throws Exception {
		if (helper.isElementPresent(btnCloseModal, driver)) {
			btnCloseModal.click();
		} else {
			helper.failTest("X - Close Modal  is not displayed", "Close Modal is displayed",
					"X - Close Modal  is not displayed", driver, testContext);
		}
	}

	public void validateFinUpdateReasons(List<String> expFinUpdateValues) throws Exception {

		WebElement expListFrame = returnUpdateFinancialInputs("Reason for updating financials");
		expListFrame.click();

		if (!expListFrame.getText().equals("")) {
			helper.failTest("No option should be selected by default - Failed", "", expListFrame.getText(), driver,
					testContext);
		}
		// Remove First entry of Datatable as they are the header
		List<String> modifiedExpReasons = new ArrayList<>();
		for (int i = 1; i < expFinUpdateValues.size(); i++) {
			modifiedExpReasons.add(expFinUpdateValues.get(i));
		}
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].scrollIntoView(true);",
				updateReasonDropDown.get(updateReasonDropDown.size() - 1));
		List<String> actReasons = new ArrayList<>();
		for (WebElement we : updateReasonDropDown) {
			actReasons.add(we.getText());
		}
		if (!modifiedExpReasons.equals(actReasons)) {
			helper.failTest("Update Financial reasons Validation Failed", modifiedExpReasons.toString(),
					actReasons.toString(), driver, testContext);
		}
		expListFrame.click();

	}

	private WebElement returnUpdateFinancialInputs(String field) {
		return driver.findElement(By.xpath("//*[@aria-label=\'" + field + "\']//.//following::div//input"));

	}

	public void isProvideAdditionalDetailsDisplayed() throws Exception {
		if (!txtAreaAdditionalDetails.isDisplayed()) {
			helper.failTest("Provide Additional Details Text Area not displayed",
					"Provide Additional Details Text Area should be displayed", "", driver, testContext);
		}
	}

	public void clickRequestEmail() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Request email", driver, testContext);
	}

	public void enterReasonAndDetails(String reason, String details) {
		WebElement dropDown = returnUpdateFinancialInputs("Reason for updating financials");
		dropDown.click();
		WebElement reasonElement = driver
				.findElement(By.xpath("//ul[@class='zb-select-dropdown-list']//li//div[text()='" + reason + "']"));
		reasonElement.click();
		txtAreaAdditionalDetails.sendKeys(details);
	}

	public void isEmailSentScreenDisplayed() throws Exception {
		// initiate page
		helper.initialisePage(driver, testContext, "Your financials");
		// Take a screen shot
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		try {
			System.out.println(emailSentHeader.getText());
			if (!(emailSentHeader.getText().contains("Thank You"))) {
				helper.failTest("Update FIs - Email sent screen is not displayed",
						"Update FIs - Email sent page should be displayed",
						"Update FIs - Email sent page is not displayed", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Update FIs - Email sent screen. is not displayed",
					"Update FIs - Email sent screen should be displayed", e.getMessage(), driver, testContext);
		}
	}

	public void clickCancelButton() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Cancel", driver, testContext);
	}

	public void editProjectedTurnover(String turnover) throws Exception {
		prevTurnover = returnProjectedFiancials("Turnover");
		prevCos = returnProjectedFiancials("Cost of sales");
		prevOverheads = returnProjectedFiancials("Overheads");
		WebElement editLink = driver.findElement(
				By.xpath("//*[contains(text(), 'Turnover')]/following::div[2]//span//a[contains(text(),'Edit')]"));
		editLink.click();
		WebElement textBox = driver.findElement(By.xpath("//*[contains(text(), 'Turnover')]/following::input[2]"));
		if (textBox.isDisplayed()) {
			textBox.sendKeys(turnover);
			updatedTurnover = turnover;
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
		} else {
			helper.failTest("Turnover TextBox for editing is not displayed",
					"Turnover Text box for editing should be displayed", "", driver, testContext);
		}
	}

	public void editProjectedCOS(String cos) throws Exception {
		WebElement editLink = driver.findElement(
				By.xpath("//*[contains(text(), 'Cost of sales')]/following::div[2]//span//a[contains(text(),'Edit')]"));
		editLink.click();
		WebElement textBox = driver.findElement(By.xpath("//*[contains(text(), 'Cost of sales')]/following::input[2]"));
		if (textBox.isDisplayed()) {
			textBox.sendKeys(cos);
			updatedCOS = cos;
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
		} else {
			helper.failTest("Cost of sales TextBox for editing is not displayed",
					"Cost of sales Text box for editing should be displayed", "", driver, testContext);
		}
	}

	public void editProjectedOverheads(String overhead) throws Exception {

		WebElement editLink = driver.findElement(
				By.xpath("//*[contains(text(), 'Overheads')]/following::div[2]//span//a[contains(text(),'Edit')]"));
		editLink.click();
		WebElement textBox = driver.findElement(By.xpath("//*[contains(text(), 'Overheads')]/following::input[2]"));
		if (textBox.isDisplayed()) {
			textBox.sendKeys(overhead);
			updatedOverheads = overhead;
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
		} else {
			helper.failTest("Overheads TextBox for editing is not displayed",
					"Overheads Text box for editing should be displayed", "", driver, testContext);
		}
	}

	public void rerunProjFinCalc() throws Exception {
		Double projTurnover = new Double(updatedTurnover);
		Double latTurnover = new Double(returnLatestFiancials("Turnover").replaceAll("[,£]", ""));
		Double scalingFactor = projTurnover / latTurnover;
		// Gross Profit Loss
		Double expProjSaleCostVal;
		if (updatedCOS.equals(""))
			expProjSaleCostVal = (new Double((prevCos.replaceAll("[,£]", "")))) * scalingFactor;
		else
			expProjSaleCostVal = (new Double(updatedCOS)) * scalingFactor;
		Double expOverheadsVal;
		if (updatedOverheads.equals(""))
			expOverheadsVal = (new Double(prevOverheads));
		else
			expOverheadsVal = (new Double(updatedOverheads)) * scalingFactor;
		calcNonEditableFinancials(projTurnover, expProjSaleCostVal, expOverheadsVal);
		calcEditableFinancials();
	}

	private void calcNonEditableFinancials(Double projTurnover, Double expProjSaleCostVal, Double expOverheadsVal)
			throws Exception {
		Double expGrossPLVal = Math.abs(projTurnover - expProjSaleCostVal);
		String expGrossPL = "£" + (expGrossPLVal.toString().substring(0, indexOfDot(expGrossPLVal.toString())));
		String actGrossPL = (returnProjectedFiancials("Gross profit/(Loss)").replaceAll("[,()]", ""));
		if (!actGrossPL.equals(expGrossPL)) {
			helper.failTest("Projected Gross profit/(loss) is incorrect", expGrossPL, actGrossPL, driver, testContext);
		}
		// Gross Profit Margin

		Double expGrossProfitMarginVal = (expGrossPLVal / projTurnover) * 100;
		String expGrossProfitMargin = String.format("%1.1f", expGrossProfitMarginVal) + "%";
		String actGrossProfitMargin = returnProjectedFiancials("Gross profit margin").replaceAll("[,()]", "");
		if (!actGrossProfitMargin.equals(expGrossProfitMargin)) {
			helper.failTest("Projected Gross Profit Margin is incorrect", expGrossProfitMargin, actGrossProfitMargin,
					driver, testContext);
		}

		// Net profit/(loss)
		Double expNetPLVal = Math.abs(expGrossPLVal - expOverheadsVal);
		String expNetPL = "£" + (expNetPLVal.toString().substring(0, indexOfDot(expNetPLVal.toString())));
		String actNetPL = (returnProjectedFiancials("Net profit/(Loss)").replaceAll("[,()]", ""));
		if (!actNetPL.equals(expNetPL)) {
			helper.failTest("Projected Net profit/(loss) is incorrect", expNetPL, actNetPL, driver, testContext);
		}
		// NetProfit Margin
		Double expNetProfitMarginVal = (expNetPLVal / projTurnover) * 100;
		String expNetProfitMargin = String.format("%1.1f", expNetProfitMarginVal) + "%";
		String actNetProfitMargin = returnProjectedFiancials("Net profit margin").replaceAll("[,()]", "");
		if (!actNetProfitMargin.equals(expNetProfitMargin)) {
			helper.failTest("Projected Net Profit Margin is incorrect", expNetProfitMargin, actNetProfitMargin, driver,
					testContext);
		}
	}

	private void calcEditableFinancials() throws Exception {
		String expProjSaleCost;
		String actProjSaleCost;
		String expProjTurnover;
		String actProjTurnover;
		String expOverheads;
		String actOverheads;
		expProjTurnover = updatedTurnover.equals("") ? prevTurnover : updatedTurnover;
		actProjTurnover = updatedTurnover.equals("") ? returnProjectedFiancials("Turnover")
				: (driver.findElement(By.xpath("//*[contains(text(), 'Turnover')]/following::input[2]"))).getText();
		if (!actProjTurnover.equals(expProjTurnover)) {
			helper.failTest("Projected Turnover is incorrect", expProjTurnover, actProjTurnover, driver, testContext);
		}
		expProjSaleCost = updatedCOS.equals("") ? prevCos : updatedCOS;
		actProjSaleCost = updatedCOS.equals("") ? returnProjectedFiancials("Cost of sales")
				: (driver.findElement(By.xpath("//*[contains(text(), 'Cost of sales')]/following::input[2]")))
						.getText();
		if (!actProjSaleCost.equals(expProjSaleCost)) {
			helper.failTest("Projected Cost of sales is incorrect", expProjSaleCost, actProjSaleCost, driver,
					testContext);
		}
		expOverheads = updatedOverheads.equals("") ? prevOverheads : updatedOverheads;
		actOverheads = updatedOverheads.equals("") ? returnProjectedFiancials("Overheads")
				: (driver.findElement(By.xpath("//*[contains(text(), 'Overheads')]/following::input[2]"))).getText();
		if (!actProjSaleCost.equals(expProjSaleCost)) {
			helper.failTest("Projected Overheads is incorrect", expOverheads, actOverheads, driver, testContext);
		}
	}

	public void verifyEmailPhoneField() throws Exception {

		try {

			if (email.isDisplayed()) {
				String biEmail = prop.getProperty("EmailAddress");
				String actualemail = email.getAttribute("value");
				if (!actualemail.equals(biEmail)) {
					helper.failTest("Update FI - Default Email as entered in BI Page is not displayed", biEmail,
							email.getText(), driver, testContext);
				}
			} else {
				helper.failTest("Update FI - Email field is not displayed",
						"Email field with default email address expected", "", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Update FI - Email field is not displayed",
					"Email field with default email address expected", e.getMessage(), driver, testContext);
		}

		try {
			if (phone.isDisplayed()) {
				String biPhone = prop.getProperty("MobileNumber");
				String actualPhone = phone.getAttribute("value");
				if (!actualPhone.equals(biPhone)) {
					helper.failTest("Update FI - Default Phone Number as entered in BI Page is not displayed", biPhone,
							phone.getText(), driver, testContext);
				}
			} else {
				helper.failTest("Update FI -Phone Number is not displayed",
						"Phone Number field with default phone number expected", "", driver, testContext);
			}
		} catch (Exception e) {
			helper.failTest("Update FI - Phone Number field is not displayed",
					"Phone Number field with default phone number address expected", e.getMessage(), driver,
					testContext);
		}
	}

	public void clickGlossaryOfTermsLink() throws Exception {
		helper.clickAnyLinkInDigitalJourney("Glossary of terms", driver, testContext);
	}

	public void validateEmailSentText() {

	}

	public void verifyappExpiryDate() throws Exception {
		String dbExpDate = helper.returnApplicationExpiryDate(testContext, driver);
		String expMsg = "This application is valid until " + dbExpDate + ".";
		String msg = getBlockedCustomerScreenMsg(3);
		if (!expMsg.equals(msg)) {
			validationStatus = "Application Expiry message is incorrect.Expected:" + expMsg + ";Actual:" + msg;
			helper.failTest("Application Expiry message is incorrect", expMsg, msg, driver, testContext);

		}

	}

	public void verifyEmailOnBlockedScreen() throws Exception {
		String emailAddress = helper.returnFinUpdEmailAddr(testContext);
		String expMsg = "To continue with this application, please respond to the email sent to [" + emailAddress
				+ "] and submit your up-to-date financials. We'll confirm receipt of this by email. You'll then be able to resume your application.";
		String msg = getBlockedCustomerScreenMsg(2);
		if (!expMsg.equals(msg)) {
			validationStatus = "Email sent to message is incorrect.Expected:" + expMsg + ";Actual:" + msg;
			helper.failTest("Email sent to message is incorrect", expMsg, msg, driver, testContext);
		}
	}

	public void verifyDateOFEmailOnBlockedScreen() throws Exception {
		String dbUpdatedDate = helper.returnAppLastUpdatedDate(testContext);
		String expMsg = "We have found an existing application where you requested an email on " + dbUpdatedDate
				+ " to provide us with updated financial records and are awaiting this information from you.";
		String msg = getBlockedCustomerScreenMsg(1);
		if (!expMsg.equals(msg)) {
			validationStatus = "Financial Update Requested Date message is incorrect.Expected:" + expMsg + ";Actual:"
					+ msg;
			helper.failTest("Financial Update Requested Date message is incorrect.", expMsg, msg, driver, testContext);
		}

	}

	private String getBlockedCustomerScreenMsg(int position) {
		WebElement option = driver.findElement(By.xpath("//div[@class='zb-card-body']//p[" + position + "]"));
		return option.getText();
	}

	public void validateCriteria(String liabilities) throws Exception {

		String reportingDate = helper.returnReportingDate(testContext);
		String entityType = (String) testContext.scenarioContext.getContext(TestData.EnityType);

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar lastestValidFIDate = Calendar.getInstance();
		lastestValidFIDate.setTime(sdf.parse(reportingDate));
		if (entityType.equals("LTD") || entityType.equals("LLP")) {
			lastestValidFIDate.add(Calendar.DAY_OF_MONTH, 649);
		} else {
			lastestValidFIDate.add(Calendar.DAY_OF_MONTH, 740);
		}
		;
		try {
			String startDate = helper.returnApplicationStartDate(testContext, driver);
			Calendar appStartDate = Calendar.getInstance();
			appStartDate.setTime(sdf.parse(startDate));

			if (lastestValidFIDate.equals(appStartDate) || appStartDate.before(lastestValidFIDate)) {

				criteriaA = true;
			}
			validationStatus = "Latest Valid FI Date:" +sdf.format(lastestValidFIDate.getTime()) + "\tApplication Start Date:" + startDate
					+ "\t" + "Criteria A :" + criteriaA;

		} catch (Exception e) {
			helper.failTest("Error while validating Criteria A", "", e.getMessage(), driver, testContext);
		}

		computeCriteriaB(liabilities);
	}

	public void validateFIFlagWithCriteria() throws Exception {
		String expValidFI;
		if (criteriaA && criteriaB) {
			expValidFI = "V";
		} else if (criteriaB && !criteriaA) {
			expValidFI = "S";
		} else {
			expValidFI = "M";
		}

		try {
			String actualValidFIFlag = helper.returnFIFlag(testContext);
			if (!actualValidFIFlag.equalsIgnoreCase(expValidFI)) {
				helper.failTest("Check consent flag:FAILED", expValidFI, actualValidFIFlag, driver, testContext);
			validationStatus += "\nCheck Valid FI Flag FAILED: Expected:" + expValidFI + ";Actual:" + actualValidFIFlag;
			}
		} catch (Exception e) {
			helper.failTest("Error during Valid FI Flag Validation in DB", "", e.getMessage(), driver, testContext);
		}
		validationStatus += "\nValid FI Flag in LND_APP_OWNER.LND_BDT_CUST_FI_TB is as expected: " + expValidFI;

	}

	public void computeCriteriaB(String liabilities) throws Exception {
		try {
			Map<String, Double> fiFields = helper.returnFIFields(testContext);
			fiFields.put("TOTAL_LIABILITIES", new Double(liabilities));

			if (fiFields.get("TURNOVER_AMT") == null || fiFields.get("NET_ASSET_AMT") == null
					|| fiFields.get("TOTAL_LIABILITIES") == null || fiFields.get("TURNOVER_AMT") == 0
					|| fiFields.get("NET_ASSET_AMT") == 0 || fiFields.get("TOTAL_LIABILITIES") == 0) {
				criteriaB = false;
			} else if ((fiFields.get("COST_OF_SALES_AMT") == null || fiFields.get("COST_OF_SALES_AMT") == 0)
					&& (fiFields.get("OVERHEADS_AMT") == null || fiFields.get("OVERHEADS_AMT") == 0)) {
				criteriaB = false;
			}
			validationStatus += "\nCriteria B:" + criteriaB;
		} catch (Exception e) {
			e.printStackTrace();
			helper.failTest("Error while fetching FI details for validating Criteria B", "", e.getMessage(), driver,
					testContext);
		}
	}

}
