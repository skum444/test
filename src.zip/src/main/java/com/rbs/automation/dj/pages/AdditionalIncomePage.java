package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

    public class AdditionalIncomePage {
    private WebDriver driver;
    private String sDataSheetName = "Application cancelled";
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    public AdditionalIncomePage(WebDriver driver,TestContext context) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;

    }

        @FindBy(how = How.CSS,using = "#zb-lending-card .AdditionalIncomeSideBar_sideBarItem__1_ut-.AdditionalIncomeSideBar_active__24W06")
        public WebElement firstKP;

        @FindBy(how =How.CSS,using = ".AdditionalIncomeSideBar_sideBarItem__1_ut-.AdditionalIncomeSideBar_inactive__5-d-O")
        public WebElement secondKP;

        @FindBy (how = How.XPATH,using = "//h1")
        public WebElement textAdditionalincome;

        @FindBy(how = How.XPATH,using = "//div[contains(text(),'Source of income')]")
        public WebElement textSourceOfIncome;

        @FindBy(how = How.XPATH,using = "//div[contains(text(),'Buy to Let income')]")
        public WebElement textBuyToLet;

        @FindBy(how =How.XPATH,using = "//div[contains(.,'Documented value')]/following::input[1]")
        public WebElement selectDocumentValue;

        @FindBy(how = How.XPATH,using = "//div[contains(.,'Documented value')]/following::input[2]")
        public WebElement selectDocumentValue2;


    public void verifyAdditionalIncomeIsDisplayed() throws Exception{
        try {
            helper.initialisePage(driver,testContext,"Additional Income");
            if (!textAdditionalincome.getText().contains("Additional Income"))
                    helper.failTest("Additional Income Page","Additional Income","",driver,testContext);
        }catch (Exception e){
            helper.failTest("Additional Income Page","Additional Income",e.getMessage(),driver,testContext);
        }
    }

    public void firstKP()throws Exception{
        firstKP.click();
    }

    public void secondKP() throws Exception{
        secondKP.click();
    }

    public void verifySourceOfIncomeIsDisplayed() throws Exception{
        try{
            helper.initialisePage(driver,testContext,"Source of income");
            if(!textSourceOfIncome.getText().contains("Source of income"))
                helper.failTest("Source Of Income Page","Source of income","",driver,testContext);
        }catch (Exception e){
            helper.failTest("Source Of Income Page","Source of income",e.getMessage(),driver,testContext);
        }
    }

    public void verifyBuyToLetIncomeIsDisplayed() throws Exception{
        try{
            helper.initialisePage(driver,testContext,"Buy to Let income");
            if (!textBuyToLet.getText().contains("Buy to Let income"))
                helper.failTest("Buy To Let Income","Buy to Let income","",driver,testContext);
           }catch (Exception e){
            helper.failTest("Buy To Let Income","Buy to Let income",e.getMessage(),driver,testContext);
        }
    }

    public void selectDocumentValueCheckbox() throws Exception{
        selectDocumentValue.click();
        selectDocumentValue2.click();

    }

    public void kpNextButton() throws Exception{
       helper.clickAnyButtonInDigitalJourney("Next",driver,testContext);

    }

    public void kpContinueButton() throws Exception{
        helper.clickAnyButtonInDigitalJourney("Continue",driver,testContext);
    }
}
