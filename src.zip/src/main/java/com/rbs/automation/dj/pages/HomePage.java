package com.rbs.automation.dj.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.configreader.ConfigFileReader;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.FileReaderManager;
import com.rbs.automation.dj.testcontext.TestContext;
 
public class HomePage {
	WebDriver driver;
	//ConfigFileReader configFileReader;
	HelperFunctions helper = new HelperFunctions();
	TestContext testContext;
	
	// initialise the page elements when the class is instantiated
	public HomePage(WebDriver driver, TestContext context)
	{
		
		PageFactory.initElements(driver,  this);
		this.driver = driver;	
		testContext =context;
		
		
		
	}
	
 
	public void navigateTo_HomePage(String site) throws Exception {
		
		// get url for test environment from config for all tests if you don't to change line by line in feature file
		//Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
		//String testRunEnvironment = prop.getProperty("testRunEnvironment");
		
		//if(testRunEnvironment!= null && !testRunEnvironment.isEmpty() )
		//	site = testRunEnvironment;
		
		
		// clear apps for BINs for save resume & Exit
		// get BINS from config1	
		/*String binsForApplicationTraceRemoval = prop.getProperty("BINSForApplicationTraceRemoval");
		String brand = prop.getProperty("testRunEnvironment");
				
		String [] bins = binsForApplicationTraceRemoval.split(",");
				
		for (String b : bins)
		{
			helper.removeApplicationsForBIN(b, site);
		}
				
		*/
		
		String url = helper.getURLLink(site);
		driver.get(url);
		
	}
	
public void navigateTo_BPMHomePage(String site) {
		
		String url = helper.getBPMURLLink(site);
		
		//String testName = (String)testContext.scenarioContext.getContext(TestData.TestName);
		//Properties prop =  FileReaderManager.getInstance().getConfigReader().getProperties();       
        //String currentTestreportSnapshotDir =System.getProperty("user.dir")  + prop.getProperty("snapshotPath")  +"\\" +testName + "_"+GenericUtils.getDateTime();       
        //testContext.scenarioContext.setContext(TestData.TestSnapShotDir,currentTestreportSnapshotDir);
		
		driver.get(url);
		
	}
	
	
	
	
	
	
}


