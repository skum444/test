package com.rbs.automation.dj.pages;

import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.helpers.ExcelUtils;

public class BPMLoginPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;
	private String sTestDataSheetName = "Done";

	// initialise the page elements when the class is instantiated
	public BPMLoginPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
		testContext.scenarioContext.setContext(TestData.PageName, "BPMLoginPage");
	}

	/*@FindBy(how = How.XPATH, using = "//button[text()='Login']")
	public WebElement btnLogin;*/

	@FindBy(how = How.XPATH, using = "//h4")
	public WebElement txtH4Header;

	@FindBy(how = How.XPATH, using = "//h2")
	public WebElement txtH2Header;

	@FindBy(how = How.XPATH, using = "//span[@class='pageError-message']")
	public WebElement txtPageErrorMsg;
	
	@FindBy(how = How.ID, using = "username")
	public WebElement txtUserName;
	
	@FindBy(how = How.ID, using = "password")
	public WebElement txtPassword;
	
	@FindBy(how = How.XPATH,using = "//span[contains(text(),'Continue')]")
	public WebElement btnLogin;

	@FindBy(how = How.XPATH, using = "//a[@id='processPortalUserDropdownId']")
	public WebElement btnUserDropdown;
	
	//@FindBy(how = How.XPATH, using = "//td[text()='Logout']")
	@FindBy(how = How.XPATH, using = "//a[text()='Log Out']")
	public WebElement btnLogOut;
	
	
	
	@FindBy(how = How.XPATH, using = "//div[@role='presentation']")
	public WebElement txtLoginPage;
	
	
	public void logoutFromBPM()
	{
		//btnUserDropdown.click();		
		btnLogOut.click();			

	}

	public void loginToBPM(String username)	
	{
		try {
			String password = genricUtils.getProperty("RMPassword");
			txtUserName.sendKeys(username);
			txtPassword.sendKeys(password);		
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
			btnLogin.click();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void verifyLoginPage() throws Exception{
		
		try {				
			String text = txtLoginPage.getText();			
			boolean headerNotFound=false;			
			if(text.contains("Process Portal"))
				headerNotFound = true;				
			if(headerNotFound == false)
				helper.failTest("BPM - Login page", "BPM Login page is not displayed", "", driver,testContext);				
		} catch (Exception e) {
			helper.failTest("BPM - Login page", "BPM Login page is not displayed", e.getMessage(), driver,testContext);
		}
	}
	
}

