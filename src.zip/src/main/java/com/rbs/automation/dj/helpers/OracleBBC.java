package com.rbs.automation.dj.helpers;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class OracleBBC {

    public static String applid = null;
    public static String CIN = null;
    public static String BIN = null;
    public static Connection connection = null;
    private static TestContext testContext = null;
    private HelperFunctions helper = new HelperFunctions();

    public OracleBBC(TestContext context) {
        testContext = context;
    }

    public OracleBBC() {

    }

    public static ResultSet getStatement(final Connection connection, final String sql) throws Exception {
        ResultSet resultSet = null;
        try {
            Statement stmt = connection.createStatement();
            resultSet = stmt.executeQuery(sql);
        } catch (SQLException e) {
        }
        return resultSet;
    }

    public static void closeConnection(Statement statement, Connection conn) {
        try {
            statement.close();
            conn.close();
        } catch (SQLException e) {

        }
    }

    /**
     * @param args
     * @throws Exception
     */

    public static Connection getConnection(String Reg) throws Exception {

        // Logger.LogMessage("Creating oracle connection");
        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");
            // Logger.LogMessage("Oracle JDBC Driver Registered!");

            // connection string to go to property file

            // QA Connection String
            if (Reg.contains("QA_01")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstcogb02d.server.rbsgrp.mde:1535:COGBLN2",
                        "LND_APP_USER_RO", "L3nd09z3rR0#2346");
                // connection =
                // DriverManager.getConnection("jdbc:oracle:thin:@vstcogb02d.server.rbsgrp.mde:1535:COGBLN2",
                // "LND_APP_TEST_USER", "Ka035pcaP6");

            } else if (Reg.contains("QA_04")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstuogb01d.server.rbsgrp.mde:1535:UOGBLN1",
                        "LND_APP_USER_RO", "L3nd09z3rR0#1881");
            } else if (Reg.contains("QA_02")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstuogb01d.server.rbsgrp.mde:1535/UOGBLN1",
                        "LND_APP_USER", "L3nd7ser#1991");
            } else if (Reg.contains("QA_03")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstsogb01d.server.rbsgrp.mde:1535/SOGBLN1",
                        "LND_APP_USER_RO", "L3nd09z3rR0#22");

            } else if (Reg.contains("DEV_01")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstblsd01d.server.rbsgrp.mde:1535:DOGBDWH1",
                        "LND_APP_USER_RO", "L3nd09z3rR0#6767");
                // connection =
                // DriverManager.getConnection("jdbc:oracle:thin:@vstcogb02d.server.rbsgrp.mde:1535:COGBLN2",
                // "LND_APP_TEST_USER", "Ka035pcaP6");
            } else if (Reg.contains("DEV_02")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstdogb01d.server.rbsgrp.mde:1535/DOGBLN1",
                        "LND_APP_USER", "L3nd7ser#1881");
            } else if (Reg.contains("DEV_03")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstbpmf03d.server.rbsgrp.mde:1535/LFBD.oradb.rbsgrp.net",
                        "LND_APP_USER_RO", "5ucakgK1");

            } else if (Reg.contains("PSE")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstblod01n.server.rbsgrp.mde:1535/DOGBBPD1",
                        "LND_APP_USER_RO", "L3nd09z3rR0#9881");
            } else if (Reg.contains("NFT")) {
                connection = DriverManager.getConnection(
                        "jdbc:oracle:thin:@scan-st-n-285.server.rbsgrp.mde:1565/NOGBLEN1NFTE", "LND_APP_USER_RO",
                        "L3nd09z3rR0#0001");

            } else if (Reg.contains("PRE-NFT")) {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@vstlenb01n.server.rbsgrp.mde:1569/LEN2NFTE.ORADB.RBSGRP.NET",
                        "LND_APP_USER_RO", "Lap194ufAC");
            }

        } catch (ClassNotFoundException e) {

        } catch (Exception e) {

        }

        return connection;

    }

    public void callBackDBFetch(String sTestName, String rownum) throws Exception {
        // Map<String, String> tdlpRow = ExcelUtils.getTestDataRow_BB(
        // lpTestDataSheetName, sTestName);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
        Map<String, String> tdlpRow = ExcelUtils.getTestDataRow_DJ1("Done", sTestName, brand);

        String sql = "SELECT APPL_ID FROM (select APPL_ID from LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB where DBID='"
                + tdlpRow.get("Customer Number") + "'  order by LAST_UPD_TS desc) WHERE ROWNUM = 1 ";
        String appli_id = null;
        String regBrand = "";
        connection = getConnection(regBrand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appli_id = resultSet.getString("appl_id");
        }
        String sql1 = "select APPL_ID,CALL_BACK_FLAG,PREFERRED_CONTACT_NO,CALL_BACK_REASON from LND_APP_OWNER.LND_Application_TB where APPL_ID = '"
                + appli_id + "'";
        ResultSet resultSet1 = getStatement(connection, sql1);
        while (resultSet1.next()) {
            appli_id = resultSet1.getString("appl_id");
            String CBFlag = resultSet1.getString("CALL_BACK_FLAG");
            String CBPrefContno = resultSet1.getString("PREFERRED_CONTACT_NO");
            String CBReason = resultSet1.getString("CALL_BACK_REASON");
            // System.out.println("CBFlag: "+ CBFlag);
            // System.out.println("CBPrefContno: "+ CBPrefContno);
            // System.out.println("CBReason: "+ CBReason);

        }
        int rownum1 = Integer.parseInt(rownum);
        appIdUpdate(appli_id, sTestName, rownum1);
    }

    public void callBackDBFetchDJ1(String DBID, String brand, WebDriver driver) throws Exception {

    	// capture BIN for DBID
    	returnBIN( DBID,  brand,  driver);
    	
    	
        String sql = "SELECT APPL_ID FROM (select APPL_ID from LND_APP_OWNER.LND_APP_APPL_DETAIL_TB where DBID='"
                + DBID + "'  order by LAST_UPD_TS desc) WHERE ROWNUM = 1 ";

        String appli_id = null;
        String appli_status = null;
        String custType = null;

        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appli_id = resultSet.getString("appl_id");

        }

        String sql1 = "select APPL_ID, APPL_STATUS, CUST_TYPE_IND, CALL_BACK_FLAG,PREFERRED_CONTACT_NO,CALL_BACK_REASON from LND_APP_OWNER.LND_Application_TB where APPL_ID = '"
                + appli_id + "'";
        ResultSet resultSet1 = getStatement(connection, sql1);
        while (resultSet1.next()) {
            appli_id = resultSet1.getString("APPL_ID");
            appli_status = resultSet1.getString("APPL_STATUS");
            custType = resultSet1.getString("CUST_TYPE_IND");
            // String CBFlag=resultSet1.getString("CALL_BACK_FLAG");
            // String CBPrefContno=resultSet1.getString("PREFERRED_CONTACT_NO");
            // String CBReason=resultSet1.getString("CALL_BACK_REASON");

        }

        testContext.scenarioContext.setContext(TestData.ApplicationID, appli_id);
        testContext.scenarioContext.setContext(TestData.ApplicationStatus, appli_status);
        testContext.scenarioContext.setContext(TestData.CustTypeFromDB, custType);

        String bin = (String) testContext.scenarioContext.getContext(TestData.BIN);
		
        
        // capture entity type
        String sql2 = "SELECT ENTITY_TYP FROM LND_APP_OWNER.LND_BIN_ACCOUNT_DTLS_TB WHERE BIN = '" + bin + "'";
        
        String entityType = "";
        ResultSet resultSet2 = getStatement(connection, sql2);
        while (resultSet2.next()) {

            entityType = resultSet2.getString("ENTITY_TYP");

        }

        testContext.scenarioContext.setContext(TestData.EnityType, entityType);
        
        
        //Return SIC CODE
        String SICCodeQuery =  "SELECT  a.RMP_SIC_CODE FROM LND_APP_OWNER.LND_BDT_NON_PERS_CUST_DET_TB a Where a.BDT_NON_PERS_UUID IN (SELECT BDT_NON_PERS_UUID from LND_APP_OWNER.LND_BDT_NON_PERS_TB WHERE APPL_ID = '"+appli_id+"')";
        String SICCode="";
        ResultSet resultSet3 = getStatement(connection, SICCodeQuery);
        while (resultSet3.next()) {

        	SICCode = resultSet3.getString("RMP_SIC_CODE");

        }
        
        testContext.scenarioContext.setContext(TestData.SICCode, SICCode);

    }

    public void returnApplicationState(String appID, String brand) throws Exception {

        String sql = "select APPL_STATE from LND_APP_OWNER.LND_APP_STATE_TB where APPL_ID = '" + appID + "'";

        String appState = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appState += resultSet.getString("APPL_STATE") + " || ";
        }

        System.out.println("APP STATE Before: " + appState);
        testContext.scenarioContext.setContext(TestData.ApplicationStatus, appState);
        System.out.println("APP STATE After: " + testContext.scenarioContext.getContext(TestData.ApplicationStatus));
    }
    
    public void returnPrevApplicationState(String appID, String brand) throws Exception {

        String sql = "select APPL_PREV_STATE from LND_APP_OWNER.LND_APP_STATE_TB where APPL_ID = '" + appID + "' and ACTIVE_FLAG='Y'";

        String appState = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appState += resultSet.getString("APPL_PREV_STATE");
        }
        testContext.scenarioContext.setContext(TestData.ApplicationPrevStatus, appState);
        System.out.println("APP STATE After: " + testContext.scenarioContext.getContext(TestData.ApplicationPrevStatus));
    }

    public void returnApplicationSubStatus(String appID, String brand) throws Exception {

        String sql = "select APPL_SUB_STATUS from LND_APP_OWNER.LND_APP_STATE_TB where APPL_ID = '" + appID + "'";

        String appSubStatus = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appSubStatus += resultSet.getString("APPL_SUB_STATUS") + " || ";
        }
        testContext.scenarioContext.setContext(TestData.ApplicationSubStatus, appSubStatus);
    }


    public void fetchReasonTestForApplication(String appID, String brand) throws Exception {

        String sql = "SELECT * FROM LND_APP_OWNER.LND_APP_REASON_TB WHERE APPL_ID = '" + appID + "'";

        String reason = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            reason += resultSet.getString("REASON_TEXT") + " || ";
        }

        testContext.scenarioContext.setContext(TestData.ReasonText, reason);

    }

    public void fetchTurnoverAmountForApplication(String brand) throws Exception {

        String appId = String.valueOf(TestData.ApplicationID);

        String sql = "SELECT * FROM LND_APP_OWNER.LND_BDT_CUST_FI_TB WHERE APPL_ID = '" + appId + "'";

        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            resultSet.getString("TURNOVER_AMT");
            resultSet.getString("FIN_ACC_SUB_TYPE");
        }

    }


    public void returnBIN(String DBID, String brand, WebDriver driver) throws Exception {

        DBID = DBID.trim();
        String sql = "SELECT BIN FROM LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB WHERE DBID ='" + DBID + "'";

        String bin = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            bin = resultSet.getString("BIN");
            break;
        }

        testContext.scenarioContext.setContext(TestData.BIN, bin);

    }

    public void removeApplicationTraceForBIN(String BIN, String brand) throws Exception {

        String sql = "DECLARE  V_DBID LND_APP_OWNER.IN_INPUT_VAL; BEGIN  V_DBID := LND_APP_OWNER.IN_INPUT_VAL('" + BIN
                + "'); LND_APP_OWNER.LND_DB_CLEARDOWN_BIN_NEW ( V_DBID ); COMMIT; END;";

        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        if (resultSet != null) {
            System.out.println("BINS cleared successfully");
        }

    }

    public void appIdUpdate(String ApplicationID, String sTestName, int rowcount) throws Exception {
        // System.out.println("Application id:" + ApplicationID);
        ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails", sTestName, rowcount, 0);
        ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails", ApplicationID, rowcount, 1);

    }

    public void appIdUpdateDJ1(String ApplicationID, String sTestName, String brand, WebDriver driver,
                               TestContext context) throws Exception {

        try {

            ExcelUtils.WriteApplicationIDToDataSheet("Done", sTestName, ApplicationID, brand);

        } catch (Exception e) {
            helper.failTest("Done Page - Error writing Application ID", "Error writing Application ID", "", driver,
                    context);
        }

    }

    public String returnConsentFlag(String appID, String brand) throws Exception {
        String sql = "select SOFT_SEARCH_CONSENT_FLAG from LND_APP_OWNER.LND_APP_APPL_DETAIL_TB where APPL_ID = '" + appID + "'";
        String consentFlag = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            consentFlag = resultSet.getString("SOFT_SEARCH_CONSENT_FLAG");
        }
        return consentFlag;
    }

    
    public void returnApplicationExpiryDate(String appID, String brand) throws Exception {

    	String sql = "select APP_EXPIRY_DATE_TS from LND_APP_OWNER.LND_APP_APPL_DETAIL_TB where APPL_ID = '" + appID + "'";

        Date appExpiryDate = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            appExpiryDate = resultSet.getDate("APP_EXPIRY_DATE_TS");
        }
        testContext.scenarioContext.setContext(TestData.ApplicationExpDate, appExpiryDate);
    }

	public String statusOfKP(String ApplicationID, String brand) throws Exception {
		String regBrand=(String) testContext.scenarioContext.getContext(TestData.Brand);
        brand = regBrand.substring(0,regBrand.lastIndexOf("_"));
        
		String sql = "Select KP_CONFIRMED_FLAG from lnd_app_owner.LND_BDT_PERS_TB where APPL_ID='"+ApplicationID+"'";
			
		String KPStatus = null;
		Connection connection = getConnection(brand);
		ResultSet resultSet = getStatement(connection, sql);
		while (resultSet.next()) {
			KPStatus = resultSet.getString("KP_CONFIRMED_FLAG");
		}

		testContext.scenarioContext.setContext(TestData.KPStatus, KPStatus);
		return KPStatus;

	}
	
	public String KPDetailsFromDB(String ApplicationID, String brand, String details) throws Exception {
		String regBrand=(String) testContext.scenarioContext.getContext(TestData.Brand);
        brand = regBrand.substring(0,regBrand.lastIndexOf("_"));
        
		String sql = "Select * from lnd_app_owner.LND_BDT_PERS_CUST_DET_TB where int_pers_cust_uuid in (Select INT_PERS_CUST_UUID from LND_APP_OWNER.LND_BDT_PERS_TB where APPL_ID='"+ApplicationID+"') and ACTIVE_FLAG = 'Y' order by LAST_UPD_TS ASC";
		String addressSQL ="Select * from lnd_app_owner.LND_BDT_PERS_CUST_ADDR_TB where int_pers_cust_uuid in (Select INT_PERS_CUST_UUID from LND_APP_OWNER.LND_BDT_PERS_TB where APPL_ID='"+ApplicationID+"') and ACTIVE_FLAG = 'Y' order by LAST_UPD_TS ASC";
		//Select * from lnd_app_owner.LND_BDT_PERS_CUST_DET_TB where int_pers_cust_uuid in (Select INT_PERS_CUST_UUID from LND_APP_OWNER.LND_BDT_PERS_TB where APPL_ID='"+ApplicationID+"')";
		String fieldValueInDB=null;	
		String indivFullName = null;
		String birthDate = null;
		String emailAddress = null;
		//String postcodeInd = null;
		/*String birthDate = null;
		String birthDate = null;
		String birthDate = null;
		String birthDate = null;
		String birthDate = null;*/
		 
		Connection connection = getConnection(brand);
		if(details.contains("Address"))
		{
			ResultSet resultSetAddressFields = getStatement(connection, addressSQL);
			while(resultSetAddressFields.next()) {
				if(details.contains("Addresspostcode")) {
					fieldValueInDB = resultSetAddressFields.getString("ADDR_POSTCODE");	
			}
				if(details.contains("AddressLine1")) {
					fieldValueInDB = resultSetAddressFields.getString("ADDR_LINE_1_TXT");	
			}
				if(details.contains("AddressLine2")) {
					fieldValueInDB = resultSetAddressFields.getString("ADDR_LINE_2_TXT");	
			}
				
		}
		}
		else
		{
			ResultSet resultSet = getStatement(connection, sql);
			while(resultSet.next()) {
				if(details.contains("Email")) {
					fieldValueInDB = resultSet.getString("EMAIL_ADDRESS");	
			}
				else if(details.contains("DOB"))
				{
					fieldValueInDB = resultSet.getString("BIRTH_DATE");
					System.out.println("BirthDate"+fieldValueInDB);
				}
				else if(details.contains("surname"))
				{
					fieldValueInDB = resultSet.getString("SURNAME");
					
				}
				else if(details.contains("MobilePhoneNumber"))
				{
					fieldValueInDB = resultSet.getString("TEL_NO");
					//check if int code should also be validated
				}
				else if(details.contains("FirstName"))
				{
					fieldValueInDB = resultSet.getString("FIRST_NAME");
					//check if int code should also be validated
				}
				
			}
		}
		

		return fieldValueInDB;

	}
	

    public String KPindustryExp(String ApplID, String brand) throws Exception {

        String sql = "Select PORTFOLIO_CODE from lnd_app_owner.LND_BDT_NON_PERS_TB where NON_PERS_CUST_ID in (Select NON_PERS_CUST_ID from LND_APP_owner.LND_APP_APPL_DETAIL_TB where APPL_ID = '"+ApplID+"')";
        String PortfolioCode = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            PortfolioCode = resultSet.getString("PORTFOLIO_CODE");
        }
         sql = "Select INDUSTRY_EXP_FLAG from lnd_app_owner.LND_BDT_NON_PERS_CUST_DET_TB where PORTFOLIO_CODE = '"+PortfolioCode+"'";
        resultSet = getStatement(connection, sql);
        String industryExperienceFlag = null;
        while (resultSet.next()) {
            industryExperienceFlag = resultSet.getString("INDUSTRY_EXP_FLAG");
        }
        return industryExperienceFlag;
    }
    
    public String returnValifFIFlag(String appID, String brand) throws Exception {
        String sql = "select VALID_FI_IND from LND_APP_OWNER.LND_BDT_CUST_FI_TB where APPL_ID = '" + appID + "'";
        System.out.println("-------"+sql);
        String fiFlag = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
            fiFlag= resultSet.getString("VALID_FI_IND");
        }
        return fiFlag;
    }
    
    public void returnApplicationStartDate(String appID, String brand) throws Exception {

        String sql = "select APPL_INIT_DATE_TS from LND_APP_OWNER.LND_APP_APPL_TB where APPL_ID = '" + appID + "'";

        Date appStartDate = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
        	appStartDate = resultSet.getDate("APPL_INIT_DATE_TS");
        }
        testContext.scenarioContext.setContext(TestData.ApplicationStartDate, appStartDate);
    }
    
    public String returnFinUpdEmailAddr(String appID, String brand) throws Exception {
        String sql = "select EMAIL_ADDRESS from LND_APP_OWNER.LND_APP_FIN_UPD_TB where appl_id='"+appID+"'" ;
        String emailAddr = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
        	emailAddr= resultSet.getString("EMAIL_ADDRES");
        }
        return emailAddr;
    }
    
    public void returnApplicationUpdateDate(String appID, String brand) throws Exception {

        String sql = "select LAST_UPD_TS from LND_APP_OWNER.LND_APP_STATE_TB where APPL_ID = '" + appID + "'";

        Date appUpdatedDate = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
        	appUpdatedDate = resultSet.getDate("LAST_UPD_TS");
        }
        testContext.scenarioContext.setContext(TestData.ApplicationUpdatedDate, appUpdatedDate);
    }

    public void returnReportingDate(String appID, String brand) throws Exception {

        String sql = "select FIN_ACC_REP_DATE from LND_APP_OWNER.LND_BDT_CUST_FI_TB where APPL_ID = '" + appID + "'";

        Date reportingDate = null;
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
        	reportingDate = resultSet.getDate("FIN_ACC_REP_DATE");
        }
        testContext.scenarioContext.setContext(TestData.ReportingDate, reportingDate);
    }
    
	/*
	 * public void returnAppStartDateInFI(String appID, String brand) throws
	 * Exception {
	 * 
	 * String sql =
	 * "select START_DATE from LND_APP_OWNER.LND_BDT_CUST_FI_TB where APPL_ID = '" +
	 * appID + "'";
	 * 
	 * Date appStartDate = null; Connection connection = getConnection(brand);
	 * ResultSet resultSet = getStatement(connection, sql); while (resultSet.next())
	 * { appStartDate = resultSet.getDate("START_DATE"); }
	 * testContext.scenarioContext.setContext(TestData.ApplicationStartDate,
	 * appStartDate); }
	 */
    
    public Map<String,Double> returnFIFields(String appID, String brand) throws Exception {
        String sql = "select TURNOVER_AMT,NET_ASSET_AMT,COST_OF_SALES_AMT,OVERHEADS_AMT from LND_APP_OWNER.LND_BDT_CUST_FI_TB where APPL_ID = '" + appID + "'";
        Map<String,Double> fiFields=new HashMap<String, Double>();
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        
        while (resultSet.next()) {
        	for(int i=1;i<=4;i++) {
        		fiFields.put(resultSet.getMetaData().getColumnName(i),resultSet.getDouble(i));
        	}
        }
        return fiFields;
    }
    
    public void returnKPSTATEIND(String appID, String brand) throws Exception {

        String sql = "select KP_STATE_IND from lnd_app_owner.LND_BDT_PERS_CUST_DET_TB where INT_PERS_CUST_UUID in (Select INT_PERS_CUST_UUID from lnd_app_owner.LND_BDT_PERS_TB where appl_id='"+appID+"' and DETAIL_SOURCE_IND='C'and ROWNUM <=1)";
        System.out.println("SQL query is "+sql);
        String kp_state_ind = "";
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        while (resultSet.next()) {
        	kp_state_ind= resultSet.getString("KP_STATE_IND");
        	System.out.println(kp_state_ind);
        }
        testContext.scenarioContext.setContext(TestData.KPStatus, kp_state_ind);
        
    }
    
    public void removeKPSTATEIND(String appID, String brand) throws Exception {

        String sql = "select KP_STATE_IND from lnd_app_owner.LND_BDT_PERS_CUST_DET_TB where INT_PERS_CUST_UUID in (Select INT_PERS_CUST_UUID from lnd_app_owner.LND_BDT_PERS_TB where appl_id='"+appID+"') and KP_STATE_IND in ('D','A')";
        System.out.println("SQL query is "+sql);
        Connection connection = getConnection(brand);
        ResultSet resultSet = getStatement(connection, sql);
        int i = 0;
        while (resultSet.next()) {
        	 i++;
        }
        
        System.out.println("Removed KP count is "+i);
        
        testContext.scenarioContext.setContext(TestData.KPStatus, Integer.toString(i));
        
        
    }
    
    

}
