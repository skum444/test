package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class requestCallBackPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public requestCallBackPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
		testContext.scenarioContext.setContext(TestData.PageName, "CallBackRequest");
	}

	@FindBy(how = How.ID, using = "mobileNumber")
	public WebElement inputMobileNumber;

	@FindBy(how = How.ID, using = "email")
	public WebElement inputEmail;

	@FindBy(how = How.XPATH, using = "//label[contains(.,'Int. code')]/following::input[1]")
	public WebElement ddIntCode;

	@FindBy(how = How.XPATH, using = "//span[@class='zb-card-header-title']")
	public WebElement txtHeader;

	@FindBy(how = How.XPATH, using = "//a[text()='Help & support']")
	public WebElement linkHelpSupport;

	
	
	public void completeRequestCallBackForm(String email, String phone) throws Exception {
		try {

			// Enter phone
			helper.enterValue(inputMobileNumber, phone);

			// Enter email
			helper.enterValue(inputEmail, email);

			// Click continue on Submit Request
			helper.clickAnyButtonInDigitalJourney("Request callback", driver, testContext);

		} catch (Exception e) {

			helper.failTest("Request a callback", "Request a callback problem completeing form", e.getMessage(), driver,
					testContext);
		}

	}

	public void verifyRequestCallBackFormIsDisplayed() throws Exception {

		helper.initialisePage(driver, testContext, "CallbackRequest");

		try {
			String text = txtHeader.getText();

			if (!(text.contains("Request a callback")))
				helper.failTest("Request a callback", "Request a callback page not displayed", "", driver, testContext);

		} catch (Exception e) {

			helper.failTest("Request a callback not displayed", "Request a callback not displayed", e.getMessage(),
					driver, testContext);
		}
	}

}
