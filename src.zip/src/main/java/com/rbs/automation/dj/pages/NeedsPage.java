package com.rbs.automation.dj.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.ExcelUtils;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class NeedsPage {

    private WebDriver driver;
    private String sTestDataSheetName = "Needs";
    private HelperFunctions helper = new HelperFunctions();
    private GenericUtils genricUtils = new GenericUtils();
    private ExcelUtils excelUtils = new ExcelUtils();
    private WaitUtils waitUtils;
    public String Refamount;
    public String Term_year; 
    public String subpurpose;
    public String Term_month ;
    private int ddIndexYear = 2;
    private int ddIndeMonth = 3;
    boolean subPurposeDisplayed = true;

    TestContext testContext;
    private String NeedsInfo = "";

    // initialise the page elements when the class is instantiated
    public NeedsPage(WebDriver driver, TestContext context) {

        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;

    }



    //@FindBy(how = How.XPATH, using = "//input[@value='Select sub-purpose']")
    
    @FindBy(how = How.XPATH, using = "//input[@value='Select sub-purpose']")
    public WebElement ddSubPurpose;


    //@FindBy(how = How.XPATH,using = "//input[@value='core-select-collapsed']")
   // public WebElement ddTenure;


    @FindBy(how = How.NAME, using = "additionalAmount")
    public WebElement txtTransactionAmt;

    @FindBy(how = How.NAME, using = "amountValue")
    public WebElement txtAmountRequired;


  //  @FindBy(how = How.NAME, using = "Lease term (years)")
   // public WebElement txtLeaseTerm;



    @FindBy(how = How.XPATH, using = "(//span[@role='radio'])[1]")
    public WebElement rdBtnTertiaryQuestionYes;

    @FindBy(how = How.XPATH, using = "(//span[@role='radio'])[2]")
    public WebElement rdBtnTertiaryQuestionNo;
    
    @FindBy(how = How.XPATH, using = "//*[contains(text(), 'Will you be borrowing the remaining amount')]/following::span[@class='zb-radio-button'][1]")
    public WebElement rdBtnContributionSourceYes;

    @FindBy(how = How.XPATH, using = "//*[contains(text(), 'Will you be borrowing the remaining amount')]/following::span[@class='zb-radio-button'][2]")
    public WebElement rdBtnContributionSourceNo;
    
    
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Will you be borrowing the remaining amount')]/following::span[@class='zb-radio-button'][1]")
    public WebElement rdBtnBorrowRemainingAmountYes;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Will you be borrowing the remaining amount')]/following::span[@class='zb-radio-button'][2]")
    public WebElement rdBtnBorrowRemainingAmountNo;

    
    @FindBy(how = How.XPATH, using = "//input[@value='Select year']")
    public WebElement ddYear;

    @FindBy(how = How.XPATH, using = "//input[@value='Select month']")
    public WebElement ddMonth;
    
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'What products would you like to repay')]/following::input[1]")
    public WebElement ddWhatProductWouldYouRepay; 
    
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'What is the tenure of the property you are purchasing')]/following::input[1]")
    public WebElement ddTenure; 
   
    
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Lease term (years)')]/following::input[1]")
    public WebElement txtLeaseTerm; 
    
  
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Who is the majority of the debt currently with')]/following::input[1]")
    public WebElement ddWhoAreYouRefinancingDebtWith; 
    
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Do you sell your goods or services mainly')]/following::input[1]/..")
    public WebElement rdBtnDoYouSellYourGoodsAndServices; 
    
    
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Cash release')]")
    public WebElement cashRelease;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Vehicle purchase')]")
    public WebElement vehiclePurchase;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Asset purchase')]")
    public WebElement assetPurchase;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Cashflow')]")
    public WebElement cashflow;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Investment')]")
    public WebElement investment;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Property')]")
    public WebElement property;

    @FindBy(how = How.XPATH, using = "//input[@value='Select an answer']")
    public WebElement contributionSourceValue;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Please provide contribution source')]")
    public WebElement textContributionSource;

    @FindBy(how = How.XPATH,using = "//label[contains(text(),'Please provide contribution source')]")
    public WebElement textErrorConstributionSource;






    //@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Property')]")
    //public WebElement headerForPurpose;


    public void completeNeedsPageByExcel() throws Exception {

        try {

            String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
            String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);

            // Load data from Data-sheet for the given test into MAP
            Map<String, String> tdRow = ExcelUtils.getTestDataRow_DJ1(sTestDataSheetName, testName, brand);

            // Get info
            String purpose = tdRow.get("Purpose");
            String subPurpose = tdRow.get("SubPurpose");
            String transactionAamount = tdRow.get("TransactionAmount");
            String amount = tdRow.get("Amount");
            String tertiaryQs = tdRow.get("TertiaryQ1");
            String contributionQs =tdRow.get("ContributionQ1");


            // Store Needs info into store Context
            storeNeedsInfoIntoTestContext(tdRow);

            // Select Purpose
            driver.findElement(By.xpath("//div[@title='" + purpose + "']")).click();
            
     
            // Select Purpose
            ddSubPurpose.click();
            driver.findElement(By.xpath("//div[contains(text(),'" + subPurpose + "')]")).click();

            if (tertiaryQs.equalsIgnoreCase("yes"))
                rdBtnTertiaryQuestionYes.click();
            else
                rdBtnTertiaryQuestionNo.click();

            if(!transactionAamount.equalsIgnoreCase("na"))
            	txtTransactionAmt.sendKeys(transactionAamount);
            
            txtAmountRequired.sendKeys(amount);

            //Select Contribution radio button

             if (contributionQs.equalsIgnoreCase("yes"))
                 rdBtnContributionSourceYes.click();
             else
                 rdBtnContributionSourceNo.click();

            
             if(helper.isElementPresent(By.xpath("//label[contains(text(),'Will you be borrowing the remaining amount')]"), driver))
            	 rdBtnBorrowRemainingAmountYes.click();
             
             
            // Set borrowing term
            setBorrowingTerm(tdRow.get("Years"), tdRow.get("Months"));


        } catch (Exception e) {
            e.printStackTrace();

            helper.failTest("Needs Page", "Landing Page", e.getMessage(), driver, testContext);

        }

    }

   
    
    
    public void completeAdditionalPropertyQuestions(String tenure, String leaseTerm)
    {
       
    	
    		ddTenure.click();
    		driver.findElement(By.xpath("//div[contains(text(),'" + tenure + "')]")).click();
    	
    	
    	if(!tenure.equalsIgnoreCase("freehold"))
    	{
    		txtLeaseTerm.sendKeys(leaseTerm);
    		
    	}
        
        //rdBtnDoYouSellYourGoodsAndServices.click();
    }
    
    
    public void completeCashflowAdditionalQuestions(String whatProductRepay, String financingDebtWith, String sellGoodsAndServices)
    {
       
    	if(!whatProductRepay.equalsIgnoreCase("na"))
    	{
    		ddWhatProductWouldYouRepay.click();
    		driver.findElement(By.xpath("//div[contains(text(),'" + whatProductRepay + "')]")).click();
    	}
    	
    	if(!financingDebtWith.equalsIgnoreCase("na"))
    	{
    		ddWhoAreYouRefinancingDebtWith.click();
    		driver.findElement(By.xpath("//div[contains(text(),'" + financingDebtWith + "')]")).click();
    	}
    	
    	rdBtnDoYouSellYourGoodsAndServices.click();
        
    	if(subpurpose.equalsIgnoreCase("Debt consolidation"))
    			{
    	 if(!Refamount.equalsIgnoreCase("na"))
             txtAmountRequired.sendKeys(Refamount);
    	 
    	    setBorrowingTerm(Term_year, Term_month);
    			}
        //rdBtnDoYouSellYourGoodsAndServices.click();
    }
  

    //without contributionSource
    public void completeNeedsPage(String purpose, String subPurpose, String tertiaryQ1, String transactionAmount, String amount, String years, String months, String product, String contributionSource) throws Exception {

        try {

            String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
            String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);


            // for reporting log the needs info into test context

            if (purpose != "null" && purpose != "")
                NeedsInfo += " #Purpose: " + purpose;

            if (subPurpose != "null" && subPurpose != "")
            {
                NeedsInfo += " #Sub-Purpose: " + subPurpose;
                subpurpose = subPurpose ; 
            }

            if (tertiaryQ1 != null && tertiaryQ1 != "")
                NeedsInfo += " #TertiaryQ1: " + tertiaryQ1;

            if (transactionAmount != "null" && transactionAmount != "") {
                String amt = transactionAmount;
                NeedsInfo += " #TransactionAmount: " + amt;

                if (amount != "null" && amount != "")
                    NeedsInfo += " #Amount: " + amount;
                Refamount = amount;
            }
            
            Term_year= years;
            Term_month= months;
            NeedsInfo += " #No. Years: " + years;
            NeedsInfo += " #No. Months: " + months;
            NeedsInfo += " #No. ContributionSource: " + contributionSource;


            testContext.scenarioContext.setContext(TestData.NeedsInfo, NeedsInfo);

            // =============


            // Select Purpose
            driver.findElement(By.xpath("//div[text()='" + purpose + "']")).click();
            //driver.findElement(By.xpath("//div[contains(text(),'" + purpose + "')]")).click();

            // Select Purpose
            if(!subPurpose.equalsIgnoreCase("na")) {
            	Thread.sleep(1000);
                ddSubPurpose.click();
                driver.findElement(By.xpath("//div[contains(text(),'" + subPurpose + "')]")).click();
            }


            if(!tertiaryQ1.equalsIgnoreCase("na")) {
            	
            	if (tertiaryQ1.equalsIgnoreCase("yes"))
            		rdBtnTertiaryQuestionYes.click();
            	else
            		rdBtnTertiaryQuestionNo.click();
            }
            
            if(!transactionAmount.equalsIgnoreCase("na"))
                txtTransactionAmt.sendKeys(transactionAmount);

            if(!(subPurpose.equalsIgnoreCase("Debt consolidation"))) {
            	  if(!amount.equalsIgnoreCase("na"))
                      txtAmountRequired.sendKeys(amount);

            }
          

            if(!contributionSource .equalsIgnoreCase("na")) {
                if (contributionSource.equalsIgnoreCase("yes"))
                    rdBtnContributionSourceYes.click();
                else
                    rdBtnContributionSourceNo.click();
            }
            
            if(helper.isElementPresent(By.xpath("//label[contains(text(),'Will you be borrowing the remaining amount')]"), driver))
           	 rdBtnBorrowRemainingAmountYes.click();
           

            // Set borrowing term
            if(!(subPurpose.equalsIgnoreCase("Debt consolidation"))) {
            setBorrowingTerm(years, months);
            }


        } catch (Exception e) {
          

            helper.failTest("Needs Page", "Landing Page", e.getMessage(), driver, testContext);

        }

    }


    public void completePropertyNeedsPage(String purpose, String subPurpose, String tenure, String leaseTerm, String transactionAmount, String amount, String years, String months, String product, String contributionSource) throws Exception {

        try {

            String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
            String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);


            // for reporting log the needs info into test context

            if (purpose != "null" && purpose != "")
                NeedsInfo += " #Purpose: " + purpose;

            if (subPurpose != "null" && subPurpose != "")
                NeedsInfo += " #Sub-Purpose: " + subPurpose;

            if (tenure != null && tenure != "")
                NeedsInfo += " #Tenure: " + tenure;

            if (transactionAmount != "null" && transactionAmount != "") {
                String amt = transactionAmount;
                NeedsInfo += " #TransactionAmount: " + amt;

            if (amount != "null" && amount != "")
                NeedsInfo += " #Amount: " + amount;

            if (leaseTerm !="null" && leaseTerm!="" )
                NeedsInfo += "#LeaseTerm: " + leaseTerm;
            }

            NeedsInfo += " #No. Years: " + years;
            NeedsInfo += " #No. Months: " + months;
            NeedsInfo += " #No. ContributionSource: " + contributionSource;


            testContext.scenarioContext.setContext(TestData.NeedsInfo, NeedsInfo);

            // =============


            // Select Purpose
            driver.findElement(By.xpath("//div[text()='" + purpose + "']")).click();
            //driver.findElement(By.xpath("//div[contains(text(),'" + purpose + "')]")).click();

            // Select Purpose
            if(!subPurpose.equalsIgnoreCase("na")) {
                ddSubPurpose.click();
                driver.findElement(By.xpath("//div[contains(text(),'" + subPurpose + "')]")).click();
            }

            //select Tenure
            if(!tenure.equalsIgnoreCase("na")) {
                ddTenure.click();
                driver.findElement(By.xpath("//div[contains(text(),'" + tenure + "')]")).click();
            }


           /* if (tertiaryQ1.equalsIgnoreCase("yes"))
                rdBtnTertiaryQuestionYes.click();
            else
                rdBtnTertiaryQuestionNo.click();*/


            if(!transactionAmount.equalsIgnoreCase("na"))
                txtTransactionAmt.sendKeys(transactionAmount);

            if(!amount.equalsIgnoreCase("na"))
                txtAmountRequired.sendKeys(amount);

            if(!leaseTerm.equalsIgnoreCase("na"))
                txtLeaseTerm.sendKeys(leaseTerm);



            if(!contributionSource .equalsIgnoreCase("na")) {
                if (contributionSource.equalsIgnoreCase("yes"))
                    rdBtnContributionSourceYes.click();
                else
                    rdBtnContributionSourceNo.click();
            }
            
            
            if(helper.isElementPresent(By.xpath("//label[starts-with(text(),'The purchase price is more than the amount you want to borrow.')]"), driver))
           	 rdBtnBorrowRemainingAmountYes.click();
           
            
            
            // Set borrowing term
            setBorrowingTerm(years, months);


        } catch (Exception e) {
            e.printStackTrace();

            helper.failTest("Needs Page", "Landing Page", e.getMessage(), driver, testContext);

        }

    }




    public void verifyNeedsPageError( String errorMessage)throws Exception {


        driver.findElement(By.xpath("//*[contains(text(),'"+ errorMessage +"')]")).isDisplayed();


    }




    public void clickContinueOnNeedsPage() throws Exception {
        helper.clickAnyButtonInDigitalJourney("Continue", driver, testContext);
    }


    public void selectPurpose(String purpose) throws Exception {
        //driver.findElement(By.xpath("//div[text()='"+purpose+"']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'" + purpose + "')]")).click();


    }

    public void verifyHeaderForPurpose(String titleText) throws Exception {
        driver.findElement(By.cssSelector("#zb-lending-card h2")).getText().equals(titleText);
    }


    // Set the term
    private void setBorrowingTerm(String termYears, String termMonths) {

        // setup value to be selected for term i.e year & Month
        String months = "";
        String years = "";

        if (Integer.parseInt(termYears) > 1) {
            years = termYears + " years";
        } else {
            years = termYears + " year";
        }

        if (Integer.parseInt(termMonths) <= 1) {
            months = termMonths + " month";
        } else {
            months = termMonths + " months";
        }

        // select year
        ddYear.click();
        driver.findElement(By.xpath("//div[contains(text(), '" + years + "')]")).click();

        // select Months
        ddMonth.click();
        driver.findElement(By.xpath("//div[contains(text(), '" + months + "')]")).click();


    }

   /* public void setContributionSource(String contributionSource) {

        // select contribution source option
        contributionSourceValue.click();
        driver.findElement(By.xpath("//div[contains(text(), '" + contributionSource + "')]")).click();


    }*/


    public void verifyNeedsPageIsDisplayed() throws Exception {

        helper.initialisePage(driver, testContext, "Needs");

        // Read Application ID and write to excel
       // helper.captureApplicationID(testContext, driver);


        try {
           
        	//String text = driver.findElement(By.xpath("//span[@class ='zb-card-header-title titleStyle']")).getText();

        	String text = driver.findElement(By.xpath("(//h2)[2]")).getText();

        	
            if (!(text.contains("What do you need the money for?"))) {
                helper.failTest("Needs page is not displayed", "Needs page is not displayed", "", driver, testContext);


            }
        } catch (Exception e) {

            helper.failTest("Needs page is not displayed", "Needs page is not displayed", e.getMessage(), driver, testContext);

        }
    }

    public void verifyNeedsInfoList(List<Map<String, String>> needsInfoList) throws Exception {

        String purpose = needsInfoList.get(0).get("Purpose");
        String subPurpose = needsInfoList.get(0).get("SubPurpose");
        String tertiaryQ1 = needsInfoList.get(0).get("TertiaryQ1");
        String transactionAmount = needsInfoList.get(0).get("TransactionAmount");
        String amount = needsInfoList.get(0).get("Amount");
        String years = needsInfoList.get(0).get("Years");
        String months = needsInfoList.get(0).get("Months");
        String product = needsInfoList.get(0).get("Product");
        String contributionSource = needsInfoList.get(0).get("ContributionSource");

        completeNeedsPage(purpose, subPurpose, tertiaryQ1, transactionAmount, amount, years, months, product, contributionSource);


    }

    public void verifyContributionSourceIsDisplayed()throws Exception {
        try{
            helper.initialisePage(driver,testContext,"Please provide contribution source");

            if (!textContributionSource.getText().contains("Please provide contribution source")){
                helper.failTest("APlease provide contribution source","Please provide contribution source","",driver,testContext);
            }
        }catch (Exception e){
            helper.failTest("Please provide contribution source","Please provide contribution source",e.getMessage(),driver,testContext);
        }
    }

    public void verifyErrorContributionSource()throws Exception {
        try{
            helper.initialisePage(driver,testContext,"Please provide contribution source");

            if (!textErrorConstributionSource.getText().contains("Please provide contribution source")){
                helper.failTest("Please provide contribution source","Please provide contribution source","",driver,testContext);
            }
        }catch (Exception e){
            helper.failTest("Please provide contribution source","Please provide contribution source",e.getMessage(),driver,testContext);
        }
    }

    public void verifyContributionSourceNotdisplayed() throws Exception {

        helper.setImplicitTimeout(driver, 1);
        if(driver.findElements(By.xpath("//label[contains(.,'Please provide contribution source')]/following::input")).size()>0)
            helper.failTest("Please provide contribution source dropdown should not be displayed", "Please provide contribution source dropdown should not be displayed", "Please provide contribution source dropdown is displayed", driver, testContext);


        helper.resetImplicitTimeoutToDefault(driver);
    }



    private void storeNeedsInfoIntoTestContext(Map<String, String> dataRow) {

        if (dataRow.get("Purpose") != "null" && dataRow.get("Purpose") != "")
            NeedsInfo += " #Purpose: " + dataRow.get("Purpose");

        if (dataRow.get("SubPurpose") != "null" && dataRow.get("SubPurpose") != "")
            NeedsInfo += " #Sub-Purpose: " + dataRow.get("SubPurpose");


        if (dataRow.get("TertiaryQ1") != null && dataRow.get("TertiaryQ1") != "null" && dataRow.get("TertiaryQ1") != "")
            NeedsInfo += " #TertiaryQ1: " + dataRow.get("TertiaryQ1");

        if (dataRow.get("TransactionAmount") != "null" && dataRow.get("TransactionAmount") != "") {
            String amt = dataRow.get("TransactionAmount");
            NeedsInfo += " #TransactionAmount: " + amt;
        }


        NeedsInfo += " #Amount: " + dataRow.get("Amount");
        NeedsInfo += " #No. Years: " + dataRow.get("Years");
        NeedsInfo += " #No. Months: " + dataRow.get("Months");

        testContext.scenarioContext.setContext(TestData.NeedsInfo, NeedsInfo);
    }

}
