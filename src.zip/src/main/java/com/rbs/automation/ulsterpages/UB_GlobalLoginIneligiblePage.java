package com.rbs.automation.ulsterpages;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UB_GlobalLoginIneligiblePage {
    private WebDriver driver;
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    public UB_GlobalLoginIneligiblePage(WebDriver driver, TestContext context) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;

    }

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Sorry - we need more information')]")
    public WebElement txtHeaderHSPersonalAccount;

    @FindBy(how = How.XPATH, using = "//div[contains(text() ,'Sorry - for business account holders only')]")
    public WebElement txtHeaderHPBusinessAccount;

    @FindBy(how = How.XPATH, using = "//div[contains(@class,'zb-heading1 appendix-header hard-stop-header')]")
    public WebElement HardStopPageHeaderTitle;

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'zb-heading3 existing-application-call')]")
    public WebElement callUsOntxt;

    @FindBy(how = How.XPATH, using = "(//div[contains(@class, 'zb-heading2')]) [2]")
    public WebElement callUsOnContactNumber;

    @FindBy(how = How.LINK_TEXT, using = "Help & Support")
    public WebElement helpAndSupportext;

    @FindBy(how = How.XPATH, using = "//span[contains(text(), 'Exit')]")
    public WebElement exitText;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Help & Support')]")
    public WebElement PageHeader;

    /*public void verifyHardStopPersonalAccountPageIsDisplayed() throws Exception {

        //helper.initialisePage(driver, testContext, "HardStopLandingPage");

        //capture BIN
        //helper.captureBIN(testContext, driver);

        // Read Application ID and write to excel
        Thread.sleep(1000);
        //helper.captureApplicationID(testContext, driver);

        try {
            String text = HardStopPageHeaderTitle.getText();

            if (!(text.contains("Sorry - we need more information")))
                helper.failTest("HardStop Landing Page not displayed", "Hard Stop Landing Page not displayed", "", driver, testContext);

        } catch (Exception e) {

            helper.failTest("Hard Stop Landing Page not displayed", "Hard Stop Landing Page not displayed", e.getMessage(), driver, testContext);
        }
    }
              helper.failTest("Hard Stop Landing Page not displayed", "Hard Stop Landing Page not displayed", e.getMessage(), driver, testContext);
        }
    } */

    public void verifyHardStopPageDisplayElements() throws Exception {

        boolean elementDisplayError = false;
        String ErrorString = "";

        try {
            if(!txtHeaderHPBusinessAccount.getText().equalsIgnoreCase("Sorry - for business account holders only"))
            {
                elementDisplayError = true;
                ErrorString += " Hard stop page missing header text";
            }
            //header text based on dev mock build -08082019
            if (!helpAndSupportext.getText().contains("Help & Support")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing help&support text";
           }
           if (!exitText.getText().contains("Exit")) {
              elementDisplayError = true;
               ErrorString += "HardStop page missing exit text";            }
            if (!callUsOntxt.getText().contains("Call us on:")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing call us on text";
            }
            if (!callUsOnContactNumber.getText().contains("1850 211 690")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing call us on contact number";
            }
            if (elementDisplayError == true)
                helper.failTest("HardStop Page", "InEligible HardStop Page elements or text not present", ErrorString, driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Page", "InEligible HardStop Page page displayed", e.getMessage(), driver, testContext);
        }
    }

    public void verifyHardStopPersonalAccountPageDisplayElements() throws Exception {
        //verifyHardStopPersonalAccountPageIsDisplayed();
        helper.waitForLoading(driver);
        boolean elementDisplayError = false;
        String ErrorString = "";

        try {
            if(!txtHeaderHSPersonalAccount.getText().equalsIgnoreCase("Sorry - we need more informationy"))
            {
                elementDisplayError = true;
                ErrorString += " Hard stop page missing header text";
            }
            //header text based on dev mock build -08082019
            if (!helpAndSupportext.getText().equalsIgnoreCase("Help & Support")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing help&support text";
            }
            if (!exitText.getText().equalsIgnoreCase("Exit")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing exit text";
            }
            if (!callUsOntxt.getText().equalsIgnoreCase("Call us on:")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing call us on text";
            }
            if (!callUsOnContactNumber.getText().equalsIgnoreCase("+1850 211 690")) {
                elementDisplayError = true;
                ErrorString += "HardStop page missing call us on contact number";
            }
            if (elementDisplayError == true)
                helper.failTest("HardStop Page", "HardStop Page elements or text not present", ErrorString, driver, testContext);

        } catch (Exception e) {

            helper.failTest("HardStop Page", "HardStop Page", e.getMessage(), driver, testContext);
        }
    }
        public void clickOnHelpandSupport()throws Exception {

            try {
                helper.waitForLoadingElementInvisibility(driver);
                Thread.sleep(2000);
                helpAndSupportext.click();
                helper.getLatestWindowFocused(driver);
                //helper.getURLLink();
                driver.switchTo().activeElement();
                Thread.sleep(1000);

            } catch (Exception e) {
                helper.failTest("Help and Support link click failed ", "Help and Support link click failed ", e.getMessage(), driver, testContext);
            }
        }

        public void clickOnExit() throws Exception {
            try {
                helper.waitForLoadingElementInvisibility(driver);
                Thread.sleep(2000);
                exitText.click();
                Thread.sleep(1000);
            } catch (Exception e) {
                helper.failTest("Exit link click failed", "Exit link click failed", e.getMessage(), driver, testContext);
            }
        }

            public void verifyPageHeader()throws Exception {
                {
                    //String url = helper.getURLLink((String) testContext.scenarioContext.getContext(TestData.Brand));
                   // driver.get(url);
                    Thread.sleep(1000);
                    if (!PageHeader.getText().equalsIgnoreCase("Help & Support"))
                        helper.failTest("Help&Support page", "Help&Support page header displayed", "Help&Support page header doesnot displayed", driver, testContext);
                }
            }


    }
