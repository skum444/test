package com.rbs.automation.ulsterpages;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class InProgessApplicationPage {
    private WebDriver driver;
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    // initialise the page elements when the class is instantiated
    public InProgessApplicationPage(WebDriver driver, TestContext context)
    {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
    }

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Your Application is in progress')]")
    public WebElement HeaderText;

    public boolean CheckPageHeaderT(String PageHeader)
    {
        boolean textExists = false;
        if(HeaderText.getText().equalsIgnoreCase(PageHeader))
        {
            textExists = true;
        }

        return textExists;
    }

}
