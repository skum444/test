package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.ConfirmationPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConfirmationPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	ConfirmationPage confirmationPage;
	private HelperFunctions helper = new HelperFunctions();

	public ConfirmationPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		confirmationPage = testContext.getPageObjectManager().getConfirmationPage(context);

	}

	@Then("^the Confirmation page is displayed$")
	public void the_Confirmation_page_is_displayed() throws Throwable {

		confirmationPage.verifyLendingConfirmationPage();
	}

	@When("^user clicks the confirm and submit button on the confirmation page$")
	public void user_clicks_the_continue_button_on_the_confirmation_page() throws Throwable {

		confirmationPage.Confirmation_ClickContinue();
	}

}