package com.rbs.automation.dj.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.rbs.automation.dj.pages.LoginPage;
import com.rbs.automation.dj.pages.LoginPage2;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;


import com.rbs.automation.dj.testcontext.TestContext;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	LoginPage loginPage;
	LoginPage2 loginPage2;

	private HelperFunctions helper = new HelperFunctions();

	public LoginPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		loginPage = testContext.getPageObjectManager().getLoginPage(context);
		loginPage2 = testContext.getPageObjectManager().getLoginPage2(context);

	}

	@When("^\"([^\"]*)\" is entered in Business Banking Login page and user clicks the continue button$")
	public void is_entered_in_Business_Banking_Login_page_and_user_clicks_the_continue_button(String DBID)
			throws Throwable {

		testContext.scenarioContext.setContext(TestData.DBID, DBID);
		testContext.scenarioContext.setContext(TestData.PageName, "LoginPage");
		loginPage.inputCustomerID(DBID);
	}

	// Login Page 2

	@Then("^the Business Banking Login page two is displayed$")
	public void the_Business_Banking_Login_page_two_is_displayed() throws Throwable {

		loginPage2.verifyLoginPage2IsDisplayed();
	}

	@When("^user inputs the security code and password and clicks on login button$")
	public void user_inputs_the_security_code_and_password_and_clicks_on_login_button() throws Throwable {

		loginPage2.inputValuesInBBlogin2Page();

	}
}