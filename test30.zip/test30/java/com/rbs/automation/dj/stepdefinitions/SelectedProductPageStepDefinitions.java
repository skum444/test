package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.SelectedProductPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SelectedProductPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	SelectedProductPage selectedProductPage;
	private HelperFunctions helper = new HelperFunctions();

	public SelectedProductPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		selectedProductPage = testContext.getPageObjectManager().getSelectedProductPage(context);

	}

	@When("^the selected product page is displayed$")
	public void the_selected_product_page_is_displayed() throws Throwable {

		selectedProductPage.verifySelectedProductPageIsDisplayed();
	}

	@When("^user clicks selected product continue button$")
	public void user_clicks_selected_product_continue_button() throws Throwable {

		selectedProductPage.SelectProduct_ClickContinue();
	}

	@Then("^the lombard redirect popup is displayed and user clicks continue$")
	public void the_lombard_redirect_popup_is_displayed_and_user_clicks_continue() throws Throwable {

		selectedProductPage.ContinueToLombard_ClickContinue();
	}
}
