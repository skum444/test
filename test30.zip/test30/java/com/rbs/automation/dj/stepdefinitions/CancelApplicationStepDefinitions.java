package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.CancelApplicationPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class CancelApplicationStepDefinitions{
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    CancelApplicationPage cancelApplicationPage;
    private HelperFunctions helper = new HelperFunctions();

    public CancelApplicationStepDefinitions(TestContext context) {
        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        cancelApplicationPage = testContext.getPageObjectManager().getCancelApplicationPage(context);
    }

    @Then("^the Cancel application is displayed$")
    public void the_Cancel_application_is_displayed() throws Throwable {
        cancelApplicationPage.verifyCancelApplicationIsDisplayed();
    }

    @Then("^I select The conditions required for borrowing do not match my expectations$")
    public void i_select_The_conditions_required_for_borrowing_do_not_match_my_expectations() throws Throwable {
        cancelApplicationPage.borrowingConditions();
    }

    @Then("^I select The cost of borrowing does not my expectations$")
    public void i_select_The_cost_of_borrowing_does_not_my_expectations() throws Throwable {
        cancelApplicationPage.costOfBorrowing();

    }

    @Then("^I enter the reason for Other$")
    public void i_enter_the_reason_for_Other() throws Throwable {
       // driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        cancelApplicationPage.otherReason();

    }

    @Then("^I click the Confirm Cancellation button$")
    public void i_click_the_Confirm_Cancellation_button() throws Throwable {
        cancelApplicationPage.confirmCancellation();

    }

}
