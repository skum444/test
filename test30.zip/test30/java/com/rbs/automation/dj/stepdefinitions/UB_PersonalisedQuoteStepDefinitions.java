package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import com.rbs.automation.dj.helpers.HelperFunctions;
	import com.rbs.automation.dj.managers.WebDriverManager;
	import com.rbs.automation.dj.pages.UB_PersonalisedQuotePage;
	import com.rbs.automation.dj.testcontext.TestContext;
	import cucumber.api.java.en.Then;
	import cucumber.api.java.en.When;

	public class UB_PersonalisedQuoteStepDefinitions {
		WebDriver driver;
		WebDriverManager webDriverManager;
		TestContext testContext;
		UB_PersonalisedQuotePage personalisedQuotesPage;
		private HelperFunctions helper = new HelperFunctions();

		public UB_PersonalisedQuoteStepDefinitions(TestContext context) {

			testContext = context;
			driver = testContext.getWebDriverManager().getDriver();
			personalisedQuotesPage = testContext.getPageObjectManager().getUBPersonalisedQuotePage(context);

		}
	
	
	@Then("^the personalised quote page should be displayed\\.$")
	public void the_personalised_quote_page_should_be_displayed() throws Throwable {
		personalisedQuotesPage.verifyPersonalisedQuotePageIsDisplayed();
	}


	
	@When("^user selects the following \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_the_following_and_and_and(String purpose, String amount, String termYears, String termMonths) throws Throwable {
	    
		personalisedQuotesPage.setQuoteParameters(purpose,amount,termYears, termMonths);
	}
	

	
	
	
	@When("^user clicks the product \"([^\"]*)\"$")
	public void user_clicks_the_product(String product) throws Throwable {
	    
		personalisedQuotesPage.selectProduct(product);
	}
	
	
	@When("^user selects the following \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_the_following_and_and(String purpose, String amount, String termInMonths) throws Throwable {
	  
		personalisedQuotesPage.setQuoteParamsTermInMonths(purpose, amount, termInMonths);
		
	}

	@Then("^Verify correct Year to Month Conversion \"([^\"]*)\"$")
	public void verify_correct_Year_to_Month_Conversion(String expectedTermInMonthsandYears) throws Throwable {
	   
		personalisedQuotesPage.VerifyCorrectMonthsToYearMonthconversion(expectedTermInMonthsandYears);
	}
	
	
	@Then("^all standard borrowing purposes are displayed$")
	public void all_standard_borrowing_purposes_are_displayed() throws Throwable {
	   
		personalisedQuotesPage.VerifyAllStandardPurposeAreDisplayed();
	}

	@Then("^verify that the \"([^\"]*)\" purpose is displayed$")
	public void verify_that_the_purpose_is_displayed(String purpose) throws Throwable {
	   
		personalisedQuotesPage.VerifyThatPurposeisDisplayed(purpose);
	}
	
	
	

	
	

	@When("^user clicks the Get Quote button$")
	public void user_clicks_the_Get_Quote_button() throws Throwable {
		personalisedQuotesPage.clickGetQuote();
	}

	@Then("^verify the allowed range error message is displayed\\.$")
	public void verify_the_allowed_range_error_message_is_displayed() throws Throwable {
	   
		
		
	}
	
	@Then("^verify the allowed range error message \"([^\"]*)\" is displayed\\.$")
	public void verify_the_allowed_range_error_message_is_displayed(String errorMsg) throws Throwable {
	  
		personalisedQuotesPage.validateErrorMessageIsDisplayed(errorMsg);
	}
	
	
	@Then("^verify that the \"([^\"]*)\" purpose is not displayed$")
	public void verify_that_the_purpose_is_not_displayed(String purpose) throws Throwable {
	    
		personalisedQuotesPage.verifyAgriculturalStockingIsNotDisplayed(purpose);
	}


	@Then("^the Get Quote button is disabled$")
	public void the_Get_Quote_button_is_disabled() throws Throwable {
		personalisedQuotesPage.verifyGetQuoteButtonIsDisabled();
	}


}
