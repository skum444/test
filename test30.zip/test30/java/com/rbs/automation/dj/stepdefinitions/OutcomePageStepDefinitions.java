package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.OutcomePage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OutcomePageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	OutcomePage outcomePage;
	private HelperFunctions helper = new HelperFunctions();

	public OutcomePageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		outcomePage = testContext.getPageObjectManager().getOutcomePage(context);

	}

	@Then("^the Outcome page is displayed$")
	public void the_Outcome_page_is_displayed() throws Throwable {

		outcomePage.verifyOutcomePageIsDisplayed();
	}

	@When("^user clicks Close this page button$")
	public void user_clicks_Close_the_page() throws Throwable {
		outcomePage.Outcome_ClosePage();
	}
	
	@Then("^Verify all elements are present on the Outcome page$")
	public void verify_all_elements_are_present_on_the_Personalised_Quote_page() throws Throwable {
	    
		outcomePage.verifyOutcomePageElements();
	}
	
	

/*	@Then("^verify FI required page is displayed$")
	public void verify_FI_required_page_is_displayed() throws Throwable {
		outcomePage.verifyFIRequiredMessageDisplayed();
	}*/

	@Then("^user is redirected to the homepage$")
	public void user_is_redirected_to_the_homepage() throws Throwable {

		String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
		
		helper.addfullScreenCaptureToExtentReport(driver, testContext);

		try {

			if (brand.toLowerCase().contains("RBS") && !driver.getCurrentUrl().contains("rbs"))
				helper.failTest("Expecting RBS homepage", "Expecting RBS homepage to be displayed", "", driver,testContext);

			if (brand.toLowerCase().contains("NWB") && !driver.getCurrentUrl().contains("natwest"))
				helper.failTest("Expecting Natwest homepage", "Expecting Natwest homepage to be displayed", "", driver,testContext);

		} catch (Exception e) {
			testContext.scenarioContext.setContext(TestData.Status, "Fail");
			helper.failTest("Expecting Natwest homepage ", "Expecting Natwest homepage ", e.getMessage(), driver,testContext);
		}

	}
}
