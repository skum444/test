package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.OneConnectJourneyPages;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;

public class OneConnectJourneyPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	OneConnectJourneyPages oneConnectJourneyPages;
	private HelperFunctions helper = new HelperFunctions();

	public OneConnectJourneyPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		oneConnectJourneyPages = testContext.getPageObjectManager().getOneConnectJourneyPages(context);

	}

	@Then("^complete OneConnect journey \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void complete_OneConnect_journey_and_and_and(String email, String mobileNumber, String amount, String term,
			String loanType) throws Exception {

		oneConnectJourneyPages.CompletOneConnectJourney(email, mobileNumber, amount, term, loanType);
	}
}
