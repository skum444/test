package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.ApplicationCancelledPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import org.openqa.selenium.WebDriver;

public class ApplicationCancelledStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    ApplicationCancelledPage applicationCancelledPage;
    private HelperFunctions helper = new HelperFunctions();

    public ApplicationCancelledStepDefinitions(TestContext context) {
        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        applicationCancelledPage = testContext.getPageObjectManager().getApplicationCancelledPage(context);
    }

    @Then("^the Application cancelled is displayed$")
    public void the_Application_cancelled_is_displayed() throws Throwable {
       applicationCancelledPage.verifyApplicationCancelledIsDisplayed();
    }


    @Then("^I click Start new application button$")
    public void i_click_Start_new_application_button() throws Throwable {
        applicationCancelledPage.startNewApplication();
    }

}