package com.rbs.automation.dj.stepdefinitions;

import java.util.Properties;

import com.rbs.automation.dj.pages.LoginPage;
import com.rbs.automation.ulsterpages.UB_GlobalLoginIneligiblePage;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.pages.UB_LandingPage;
import com.rbs.automation.dj.pages.IneligibleLandingPage;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.FileReaderManager;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UB_LandingStepDefinitions {
    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    UB_LandingPage uB_landingPage;
    LoginPage loginPage;
    IneligibleLandingPage ineligibleLandingPage;
    UB_GlobalLoginIneligiblePage uB_globalLoginIneligibleLandingPage;
    private HelperFunctions helper = new HelperFunctions();


    public UB_LandingStepDefinitions(TestContext context) {

        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        uB_landingPage = testContext.getPageObjectManager().getuB_LandingPage(context);
        ineligibleLandingPage = testContext.getPageObjectManager().getIneligibleLandingPage(context);
        uB_globalLoginIneligibleLandingPage = testContext.getPageObjectManager().getuB_GlobalLoginInEligibleLandingPage(context);
    }

    @Then("^verify landing screen is displayed with the correct message containing the text \"([^\"]*)\"$")
    public void verify_landing_screen_is_displayed_with_the_correct_message_containing_the_text(String messageToVerify)
            throws Throwable {

        uB_landingPage.verifyMessageOnLandingPage(messageToVerify);
    }


    @Then("^verify landing screen is displayed with pal message and amount$")
    public void verify_landing_screen_is_displayed_with_pal_message_and_amount() throws Throwable {

        uB_landingPage.verifyPalMessageOnLandingPage();
    }

    @Then("^verify landing screen is displayed without pal message$")
    public void verify_landing_screen_is_displayed_without_pal_message() throws Throwable {

        uB_landingPage.verifyNonPalMessageOnLandingPage();
    }


    @When("^user enters values in \"([^\"]*)\" and \"([^\"]*)\" field and clicks on Get Started button\\.$")
    public void user_enters_values_in_and_field_and_clicks_on_Get_Started_button(String email, String mobileNumber)
            throws Throwable {

        uB_landingPage.updateDetailsOnLandingPage(email, mobileNumber);

    }

    @When("^user enters email and mobile number and clicks on Get Started button\\.$")
    public void user_enters_email_and_mobile_number_and_clicks_on_Get_Started_button() throws Throwable {

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();

        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        uB_landingPage.updateDetailsOnLandingPage(email, mobileNumber);

    }

    @Then("^user is displayed the continue application page and clicks cancel$")
    public void user_is_displayed_the_continue_application_page_and_clicks_cancel() throws Throwable {

        uB_landingPage.continueApplicationScreenDisplayedAndClickCancel();
    }

    @Then("^user is displayed the continue application page and clicks continue$")
    public void user_is_displayed_the_continue_application_page_and_clicks_continue() throws Throwable {
       // uB_landingPage.continueApplicationScreenDisplayedAndClickContinue();
    }

    @Then("^verify the \"([^\"]*)\" page is displayed$")
    public void verify_the_page_is_displayed(String expectedPage) throws Throwable {
        uB_landingPage.verifyDisplayedPage(expectedPage);
    }

    @Then("^verify all landing page elements are present$")
    public void verify_all_landing_page_elements_are_present() throws Throwable {
        uB_landingPage.VerifyWelcomePageDisplayElements();
    }


    //========================================
    // Ineligible
    //========================================

    @Then("^verify that the inelligble landing page is displayed$")
    public void verify_that_the_inelligble_landing_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyIneligibleLandingPageIsDisplayed();

    }

    @When("^user completes the callback request form \"([^\"]*)\" and \"([^\"]*)\"  and confirms$")
    public void user_completes_the_callback_request_form_and_and_confirms(String email, String phone) throws Throwable {

        ineligibleLandingPage.completeIneligibleForm(email, phone);
    }


    @When("^user completes the callback request form and continues$")
    public void user_completes_the_callback_request_form_and_continues() throws Throwable {

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();

        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeIneligibleForm(email, mobileNumber);


    }

    @When("^user completes the AJ specific callback request form and continues$")
    public void user_completes_the_aj_specific_callback_request_and_continues() throws Throwable {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeAJSpecificCallBackForm(email, mobileNumber);
    }

    @When("^user completes the HS callback request form and continues$")
    public void user_completes_the_hs_callback_request_and_continues() throws Throwable {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String email = prop.getProperty("EmailAddress");
        String mobileNumber = prop.getProperty("MobileNumber");
        ineligibleLandingPage.completeHardStopCallBackForm(email, mobileNumber);
    }

    @Then("^verify that the hardstop landing page is displayed$")
    public void verify_that_the_hardstop_landing_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyHardStopPageIsDisplayed();
    }

    @Then("^verify that the hardstop personal account page is displayed$")
    public void verify_that_the_hardstop_personal_account_page_is_displayed() throws Throwable {

        ineligibleLandingPage.verifyHardStopPersonalAccountPageIsDisplayed();
    }

    @Then("^verify hardstop landing page all elements are present$")
    public void verifyHardstopLandingPageAllElementsArePresent() throws Throwable {
        uB_globalLoginIneligibleLandingPage.verifyHardStopPageDisplayElements();
    }

    @When("^hs landing page is displayed and user completes the hs specific callback request form \"([^\"]*)\" and \"([^\"]*)\" and continues$")
    public void hs_landing_page_is_displayed_and_user_completes_the_hs_specific_callback_request_form_and_continues(String email, String phone) throws Throwable {
        ineligibleLandingPage.verifyHardStopPageIsDisplayed();
        ineligibleLandingPage.completeHardStopCallBackForm(email, phone);
    }

    @Then("^verify the \"([^\"]*)\" is displayed on HS generic page$")
    public void verify_the_in_hs_generic_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSGenericInformationTextIsDisplayed(message);

    }

    @Then("^verify the \"([^\"]*)\" is displayed on HS specific page$")
    public void verify_the_in_hs_specific_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSSpecificInformationTextIsDisplayed(message);

    }


    @Then("^verify if welcome page is displayed$")
    public void verify_if_landing_page_is_displayed() throws Throwable {
        uB_landingPage.verifyLandingPage();
    }

    @And("^verify the \"([^\"]*)\" is displayed on HS personal account page$")
    public void verify_text_is_displayed_on_hs_personal_account_page(String message) throws Throwable {
        ineligibleLandingPage.verifyHSPersonalAccountInformationTextIsDisplayed(message);
    }

    @And("^verify the \"([^\"]*)\" is displayed on AJ specific page$")
    public void verify_text_is_displayed_on_aj_specific_page(String message) throws Throwable {
        ineligibleLandingPage.verifyAJSpecificInformationTextIsDisplayed(message);
    }

    @And("^verify the \"([^\"]*)\" is displayed on AJ generic page$")
    public void verify_text_is_displayed_on_aj_generic_page(String message) throws Throwable {
        ineligibleLandingPage.verifyAJGenericInformationTextIsDisplayed(message);
    }

    @When("^I click edit details$")
    public void iClickEditDetails() {

    }

    @And("^download and verify all guide documents are downloaded successfully$")
    public void iDownloadAndVerifyAllGuideDocumentsAreDownloadedSuccessfully() throws Exception {
        uB_landingPage.verifydownloadedguideDocuments();
    }

    @And("^verify the check box on landing page$")
    public void verifyTheCheckBoxOnLandingPage() throws Exception {
        uB_landingPage.verifyLandingPageCheckbox();
    }

    @And("^verify displayed validation message for uncheck check box on landing page$")
    public void verifyDisplayedValidationMessageForUncheckCheckBoxOnLandingPage() throws Exception {
        uB_landingPage.verifyUncheckCheckboxValidationMsg();

    }

    @And("^confirm to contiue$")
    public void confirmToContiue() throws Exception {
        uB_landingPage.selectConfirmCheckBox();
    }


    @Then("^Personalise your Quote screen is displayed$")
    public void personaliseYourQuoteScreenIsDisplayed() throws Exception {
        uB_landingPage.verifyDisplayedQuotePage();
    }

    @And("^click Edit Details$")
    public void clickEditDetails() throws Exception {
        uB_landingPage.clickEditDetails();

    }

    @When("^edit the email address with invalidEmail \"([^\"]*)\"$")
    public void editTheEmailAddressWithInvalidEmail(String InValidEmailID) throws Throwable {

        uB_landingPage.enterInValidEmail(InValidEmailID);
    }

    @Then("^verify displayed validation message on phone field \"([^\"]*)\"$")
    public void verifyDisplayedValidationMessageOnPhoneField(String PhoneFieldValMsg) throws Throwable {
        uB_landingPage.verifyPhoneFieldValidationMsg(PhoneFieldValMsg);

    }

    @Then("^verify displayed validation message on email field \"([^\"]*)\"$")
    public void verifyDisplayedValidationMessageOnEmailField(String EmailFieldValMsg) throws Throwable {
        uB_landingPage.verifyEmailFiledValidationMsg(EmailFieldValMsg);
    }

    @Then("^verify displayed dialog modal$")
    public void verifyDisplayedDialogModal() throws Exception {
        uB_landingPage.verifyUpdateDetailsDialogDisplayed();
    }

    @When("^edit the mobile number field with invalid number \"([^\"]*)\" and populated default Int code$")
    public void editTheMobileNumberFieldWithInvalidNumberAndPopulatedDefaultIntCode(String PhoneNumber) throws Throwable {
        uB_landingPage.enterPhoneNumber(PhoneNumber);
    }

    @When("^edit the mobile number field  with valid number \"([^\"]*)\" using international dialling code \"([^\"]*)\" and update$")
    public void editTheMobileNumberFieldWithValidNumberUsingInternationalDiallingCodeAndUpdate(String IntCode, String ValidPhoneNumber) throws Throwable {
        uB_landingPage.editIntCodeAndEnterValidNumber(IntCode, ValidPhoneNumber);
    }

    @Then("^verify hardstop personal account landing page all elements are displayed$")
    public void verifyHarstopPersonalAccountLandingPageAllElementsAreDisplayed() throws Exception {
        uB_globalLoginIneligibleLandingPage.verifyHardStopPersonalAccountPageDisplayElements();

    }

    @When("^edit email address with validEmail \"([^\"]*)\"$")
    public void editEmailAddressWithValidEmail(String ValidEmail) throws Throwable {
        uB_landingPage.enterValidEmail(ValidEmail);
    }

    @When("^edit the mobile number field  with valid number \"([^\"]*)\" and default populated dialling code and update$")
    public void editTheMobileNumberFieldWithValidNumberAndDefaultPopulatedDiallingCodeAndUpdate(String ValidPhoneNumber) throws Throwable {
        uB_landingPage.editIntCodeAndEnterValidNumber(ValidPhoneNumber);
    }

    @Then("^verify displayed elements in contact details form$")
    public void verifyDisplayedElementsInContactDetailsForm() throws Exception {
        uB_landingPage.verifyDisplayedUpdateDetailsDialogElements();
    }

    @Then("^verify updated contact details on landing page$")
    public void verifyUpdatedContactDetailsOnLandingPage() throws Exception {
        uB_landingPage.verifyUpdateddetails();
    }

    @When("^customer clicks on the Exit button$")
    public void customerClicksOnTheExitButton() throws Exception {

        uB_globalLoginIneligibleLandingPage.clickOnExit();

    }

    @Then("^the customer is returned to their online banking facility home page$")
    public void theCustomerIsReturnedToTheirOnlineBankingFacilityHomePage() {

    }

    @When("^customer clicks on the HelpAndSupport link$")
    public void customerClicksOnTheHelpAndSupportlink() throws Exception {

        uB_globalLoginIneligibleLandingPage.clickOnHelpandSupport();
    }

    @Then("^click on enabled get started button$")
    public void clickOnEnabledGetStartedButton() throws Exception {
        uB_landingPage.clickonGetStartedBtn();
    }

    @And("^confirm to continue$")
    public void confirmToContinue() throws Exception {
        uB_landingPage.selectConfirmCheckBox();
    }

    @And("^I fill in data to continue$")
    public void iFillInDataToContinue() {
    loginPage.enterAllDataToContinue();

    }

    @Then("^verify page header$")
    public void verifyPageHeader() throws Exception {
        uB_globalLoginIneligibleLandingPage.verifyPageHeader();
    }

    @And("^verify displayed application number$")
    public void verifyDisplayedApplicationNumber() throws Exception {
        uB_landingPage.verifyApplicationNumber();
    }

    @Then("^verify page header text$")
    public void verifyPageHeaderText() throws Exception {
        uB_landingPage.VerifyInprogressPageHeaderDisplayed();
    }
}



