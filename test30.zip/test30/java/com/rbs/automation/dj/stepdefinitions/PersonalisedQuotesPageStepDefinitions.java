package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.PersonalisedQuotePage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalisedQuotesPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	PersonalisedQuotePage personalisedQuotesPage;
	private HelperFunctions helper = new HelperFunctions();

	public PersonalisedQuotesPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		personalisedQuotesPage = testContext.getPageObjectManager().getPersonalisedQuotePage(context);

	}
	
	
	
	@Then("^verify the Personalised Quote page is displayed$")
	public void verify_the_Personalised_Quote_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personalisedQuotesPage.VerifyQuotePageIsDisplayed();
	}

	@Then("^Verify all elements are present on the Personalised Quote page$")
	public void verify_all_elements_are_present_on_the_Personalised_Quote_page() throws Throwable {
	    
		personalisedQuotesPage.verifyPersonalisedQuotePageElements();
	}

	
	@Then("^the correct products and pricing should be displayed on the Personalised Quote page$")
	public void the_correct_products_and_pricing_should_be_displayed_on_the_Personalised_Quote_page() throws Throwable {
	   
		personalisedQuotesPage.VerifyAllProductsAndPricingIsDisplayed();
	}

	

@Then("^verify that the Confirm and Submit modal is displayed$")
public void verify_that_the_Confirm_and_Submit_modal_is_displayed() throws Throwable {
    
	personalisedQuotesPage.verifyConfirmSubmitModalIsDisplayed();
}

@Then("^verify that Credit Scoring Guide link is displayed$")
public void verify_that_Credit_Scoring_Guide_link_is_displayed() throws Throwable {
	personalisedQuotesPage.verifyCreditScoringLinkIsDisplayed();
}

@When("^we close the Confirm and Submit modal$")
public void we_close_the_Confirm_and_Submit_modal() throws Throwable {
   
	personalisedQuotesPage.closeConfirmSubmitModal();
}

@When("^we confirm and submit application$")
public void we_confirm_and_submit_application() throws Throwable {
   
	helper.clickAnyButtonInDigitalJourney("Confirm and submit","4", driver, testContext);
}


/*
@Then("^Account screen is displayed\\.$")
public void account_screen_is_displayed() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

	
	


	
	
	@Then("^the correct products and pricing should be displayed$")
	public void the_correct_products_and_pricing_should_be_displayed() throws Throwable {

		personalisedQuotesPage.VerifyAllProductsAndPricingIsDisplayed();
	}
	

	@Then("^verify cashflow\\+ product is not displayed$")
	public void verify_cashflow_product_is_not_displayed() throws Throwable {
	   
		personalisedQuotesPage.verifyCashFlowProductsNotDisplayed();
	}
	
	

	@When("^user clicks the save and exit link$")
	public void user_clicks_save_and_exit_link() throws Throwable {

		personalisedQuotesPage.clickSaveAndExitLink();
	}
	
	
	@Then("^the user continues with the appliction$")
	public void the_user_continues_with_the_appliction() throws Throwable {
	 
		personalisedQuotesPage.ContinueApplication();
	}
	
	@Then("^Verify all elements are present on the QQ page$")
	public void verify_all_elements_are_present_on_the_QQ_page() throws Throwable {
	    
		personalisedQuotesPage.verifyQQPageElements();
	}
	
	
	

@Then("^verify \"([^\"]*)\" not visible in products table$")
public void verify_not_visible_in_products_table(String heading) throws Throwable {
   
	personalisedQuotesPage.verifyProductTypeHeaderNotDisplayed(heading);
}
	
	//Needs page 
	@Then("^Verify that the no products match needs message displayed\\.$")
	public void verify_that_the_no_products_match_needs_message_displayed() throws Throwable {
	  
		personalisedQuotesPage.verifyNoProductsMessageDisplayed();
	}
	
	
	

	@Then("^the needs page is pre-populated with previously selected values$")
	public void the_needs_page_is_pre_populated_with_previously_selected_values() throws Throwable {
	   
		System.out.println("#######To do this setp########");
		System.out.println("the_needs_page_is_pre_populated_with_previously_selected_values");
	}
	
	
	
	*/

	
}

