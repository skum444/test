package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.BPMApplicationSummaryPage;
import com.rbs.automation.dj.pages.BPMLoginPage;
import com.rbs.automation.dj.pages.BPMMyWorksPage;
import com.rbs.automation.dj.pages.HomePage;
import com.rbs.automation.dj.testcontext.TestContext;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BPMApplicationSummaryStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	BPMApplicationSummaryPage bpmApplicationSummaryPage;
	HomePage homePage;
	public String dealTeamID = null;
	
	private HelperFunctions helper = new HelperFunctions();

	public BPMApplicationSummaryStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		bpmApplicationSummaryPage = testContext.getPageObjectManager().BPMApplicationSummaryPage(context);		
		
	}
	
	@When("^user selects the \"([^\"]*)\" and selects the Application Decision as \"([^\"]*)\"$")
	public void user_selects_the_and_selects_the_Application_Decision_as_for_the(String dealteam, String applicationDecision) throws Throwable {
		dealTeamID = dealteam;
		if(!((dealTeamID.contains("REF"))||(dealTeamID.contains("DIR"))))
		{
		bpmApplicationSummaryPage.selectBBRMTeam(dealteam);
		}
		bpmApplicationSummaryPage.selectApplicationDecision(applicationDecision);
	}

	@Then("^user should navigate to Application Summary Page corresponding to the above reference number$")
	public void user_should_navigate_to_Application_Summary_Page_corresponding_to_the_above_reference_number() throws Throwable {
		bpmApplicationSummaryPage.verifyBPMApplicationSummaryPageIsDisplayed();
	   
	}

	@When("^user selects the Application Decision as \"([^\"]*)\"$")
	public void user_selects_the_Application_Decision_as_(String applicationDecision) throws Throwable {
		bpmApplicationSummaryPage.selectApplicationDecision(applicationDecision);
	}
	
	@When("^submits the application$")
	public void submits_the_application() throws Throwable {
		bpmApplicationSummaryPage.submitApplication(dealTeamID);
	}
	
}