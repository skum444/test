package com.rbs.automation.dj.stepdefinitions;

import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.FinancialsPage;
import com.rbs.automation.dj.pages.IneligibleLandingPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class FinancialsPageStepDefinitions {

    WebDriver driver;
    WebDriverManager webDriverManager;
    TestContext testContext;
    FinancialsPage financialsPage;
    IneligibleLandingPage ineligibleLandingPage;
    

    public FinancialsPageStepDefinitions(TestContext context) {

        testContext = context;
        driver = testContext.getWebDriverManager().getDriver();
        financialsPage = testContext.getPageObjectManager().getFinancialsPage(context);
    }

    @Then("^the financials page is displayed$")
    public void the_financials_page_is_displayed() throws Throwable {
        financialsPage.verifyFinancialsPageIsDiplayedPage();
    }

    @When("^clicking on the question mark icon next to the fields$")
    public void click_question_mark_icon_next_to_field(DataTable fields) throws Exception {
       List<String> fieldsList = fields.asList(String.class);
        financialsPage.clickIcon(fieldsList);
    }

    @Then("^description for fields are validated$")
    public void description_for_each_field_is_displayed() throws Exception {
        financialsPage.validateFieldDescription();
    }

    @And("^the latest historical values are displayed$")
    public void latest_financials_is_displayed() throws Exception {
        financialsPage.validateLatestFinancialsIsDisplayed();
    }
    @Then("^validate projected financial reporting period$")
    public void validate_financial_reporting_period() throws Exception {
        financialsPage.reportingPeriodIsDisplayed();
    }

    @And("^I confirm projected financials$")
    public void confirm_projected_financials() throws Exception {
        financialsPage.clickConfirmAndContinue();
    }

    @When("^I click 'Confirm and continue'$")
    public void click_confirm_and_continue() throws Exception {
        financialsPage.clickConfirmAndContinue();
    }

    @Then ("^screen to enter projected turnover is displayed$")
    public void screen_eo_enter_projected_turnover_is_displayed() throws Exception{
        financialsPage.isTurnoverDisplayed();
    }

    @When("^I enter \"([^\"]*)\" and click 'Calculate projected financials' button$")
    public void screen_to_enter_projected_financials_is_displayed(String turnover) throws Exception {
        financialsPage.inputProjectedFinancials(turnover);
    }

    @Then("^validate projected financial data based on \"([^\"]*)\"$")
    public void on_entering_turnover_validate_projected_financial_data(String turnover)throws Exception {
            financialsPage.validateProjectedFinancials(turnover);
    }

    @Then ("^values of Turnover,Overheads and Cost of Sales are editable$")
    public void I_can_edit_values() throws Exception {
        financialsPage.checkEditableFields();
    }

    @When("^I successfully edit turnover with \"([^\"]*)\"$")
    public void i_edit_turnover(String turnover) throws Exception {
        financialsPage.editProjectedTurnover(turnover);
    }

    @When("^I successfully edit saleCost with \"([^\"]*)\"$")
    public void i_edit_saleCost(String turnover) throws Exception {
        financialsPage.editProjectedCOS(turnover);
    }

    @When("^I successfully edit overheads with \"([^\"]*)\"$")
    public void i_edit_overhead(String turnover) throws Exception {
        financialsPage.editProjectedOverheads(turnover);
    }

    @When ("^I enter the \"([^\"]*)\"$")
    public void enter_renumeration(String remuneration) throws Exception {
        financialsPage.confirmProjectedFinancials(remuneration);
    }

    @Then ("^I am on Financials Consent screen with Confirmation text$")
    public void i__am_on_financials_consent_screen() throws Exception {
        financialsPage.financialConsentIsDisplayed();
    }


    @When ("^I click Check eligibility button$")
    public void customer_clicks_check_eligiblity() throws Exception {
        financialsPage.clickCheckEligibility();
    }

    @When("^I select to update financials$")
    public void select_update_financials() throws Exception {
        financialsPage.selectUpdateFinancials();
    }
    @Then("^update FI screen is displayed$")
    public void update_fi_screen_is_displayed() throws Exception {
        financialsPage.verifyUpdateFIScreenIsDisplayed();
    }

    @When("^I click 'What you ll need to supply'$")
    public void customer_click_what_you_need_to_supply() throws Exception {
        financialsPage.clickForInfoNeeded();
    }

    @Then("^the system will display modal$")
    public void system_will_dislay_modal() throws Exception {
        financialsPage.verifyModalIsDisplayed();
    }

    @And("^the modal will mention the need to supply details for \"([^\"]*)\"$")
    public void modal_will_mention_need_to_supply_details(String entity) throws Exception {
        financialsPage.validateModalText(entity);
    }

    @When("^I click X, this will close the modal$")
    public void user_clicks_close_modal() throws Exception {
        financialsPage.closeModal();
    }

    @Then("^four reasons are presented for updating Financials$")
    public void four_reasons_are_presented_for_updating_Financials(DataTable reasons) throws Exception {
    	 List<String> finUpdateReasons = reasons.asList(String.class);
         financialsPage.validateFinUpdateReasons(finUpdateReasons);
    }


    @And("^the freetext box is available up to 255 characters for providing additional details$")
    public void freetext_box_provide_additional_details()throws Exception{
        financialsPage.isProvideAdditionalDetailsDisplayed();
    }

    @And("^I click 'Request email' button$")
    public void clickk_request_email_button() throws  Exception{
        financialsPage.clickRequestEmail();
    }

    @When("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_enter_reason_and_additional_details(String reason, String details) throws  Exception{
        financialsPage.enterReasonAndDetails(reason,details);
    }

    @Then("^I am on email sent screen$")
    public void i_am_on_email_sent_screen() throws  Exception{
        financialsPage.isEmailSentScreenDisplayed();
    }

    @When("^I select Cancel button$")
    public void i_select_cancel_button() throws Exception{
        financialsPage.clickCancelButton();
    }

    @Then("^system re-runs the calculations but any user edited/ entered values are not overriden by the calculation$")
    public void system_reruns_calculations() throws  Exception{
        financialsPage.rerunProjFinCalc();
    }

    @Then("^the email address and phone number field is displayed with default value as in Login page$")
    public void the_email_address_and_phone_number_field_is_displayed_with_default_value_as_in_Login_page() throws Exception {
    	financialsPage.verifyEmailPhoneField();
    }

    @And("^the modal will display a link to Glossary of terms$")
    public void modal_will_display_link_to_glossary_of_terms() throws Exception{
        financialsPage.clickGlossaryOfTermsLink();
    }

    @And ("^validate text displayed on the email sent screen$")
    public void validate_text_on_email_sent_screen() throws Exception{
        financialsPage.validateEmailSentText();
    }

    @And("^no FI header is displayed and the screen tells the user what the next steps are$")
    public void no_financials_page_is_displayed() throws Exception{
        financialsPage.verifyNoFIHeaderIsDisplayed();
    }
    
    @Then("^the system displays block customer screen with appropriate message$")
    public void system_displays_customer_blocked_screen() throws Exception{
        financialsPage.verifyCustBlockedIsDisplayed();
    }
    
    @And ("^validate returned user message is displayed$")
    public void validate_returned_user_message() throws Exception{
      //  financialsPage.verifyCustReturendIsDisplayed();
    }
   
    @And ("^expiry Date of the application is mentioned$")
    public void expiry_date_of_application_is_mentioned() throws Exception{
        financialsPage.verifyappExpiryDate();
     }
    
    @And("^email confirmed on the Landing page is mentioned to which the email has been sent to$")
    public void email_confirmed_on_landing_page() throws Exception{
        financialsPage.verifyEmailOnBlockedScreen();
     }
    
    @And("^date when customer requested an email for FI update is displayed$")
    public void date_when_customer_requested_email() throws Exception{
        financialsPage.verifyDateOFEmailOnBlockedScreen();
     }
    
    @And("^criteria A & B are evaluated with \"([^\\\"]*)\"$")
    public void criteriaA_criteriaB_are_evaluated(String liabilities) throws Exception{
        financialsPage.validateCriteria(liabilities);
     }
    
    @Then("^validate valid FI flag$")
    public void validate_FI_Flag() throws Exception{
        financialsPage.validateFIFlagWithCriteria();
     }
    
    @And("^finaicial fields are fetched \"([^\\\\\\\"]*)\"$")
    public void financial_fields_are_fetched(String liabilities) throws Exception{
        financialsPage.computeCriteriaB(liabilities);
     }   
    
    @And("stale FI header is displayed and the screen tells the user what the next steps are$")
    public void staleo_financials_page_is_displayed() throws Exception{
        financialsPage.verifyStaleoFIHeaderIsDisplayed();
    }
    
   
}
