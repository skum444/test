package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.QuotesPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class QuotePageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	QuotesPage quotesPage;
	private HelperFunctions helper = new HelperFunctions();

	public QuotePageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		quotesPage = testContext.getPageObjectManager().getQuotesPage(context);

	}

	@Then("^the quotes page should be displayed$")
	public void the_quotes_page_should_be_displayed() throws Throwable {

		quotesPage.VerifyQuotePageIsDisplayed();
	}

	@Then("^the correct products and pricing should be displayed$")
	public void the_correct_products_and_pricing_should_be_displayed() throws Throwable {

		quotesPage.VerifyAllProductsAndPricingIsDisplayed();
	}
	
	@Then("^verify cashflow\\+ product is not displayed$")
	public void verify_cashflow_product_is_not_displayed() throws Throwable {
	   
		quotesPage.verifyCashFlowProductsNotDisplayed();
	}
	
	

	@When("^user clicks the save and exit link$")
	public void user_clicks_save_and_exit_link() throws Throwable {

		quotesPage.clickSaveAndExitLink();
	}
	
	
	@Then("^the user continues with the appliction$")
	public void the_user_continues_with_the_appliction() throws Throwable {
	 
		quotesPage.ContinueApplication();
	}
	
	@Then("^Verify all elements are present on the QQ page$")
	public void verify_all_elements_are_present_on_the_QQ_page() throws Throwable {
	    
		quotesPage.verifyQQPageElements();
	}
	
	
	

@Then("^verify \"([^\"]*)\" not visible in products table$")
public void verify_not_visible_in_products_table(String heading) throws Throwable {
   
	quotesPage.verifyProductTypeHeaderNotDisplayed(heading);
}
	
	//Needs page 
	@Then("^Verify that the no products match needs message displayed\\.$")
	public void verify_that_the_no_products_match_needs_message_displayed() throws Throwable {
	  
		quotesPage.verifyNoProductsMessageDisplayed();
	}
	
	
	

	@Then("^the needs page is pre-populated with previously selected values$")
	public void the_needs_page_is_pre_populated_with_previously_selected_values() throws Throwable {
	   
		System.out.println("#######To do this setp########");
		System.out.println("the_needs_page_is_pre_populated_with_previously_selected_values");
	}
	
	
	
	// Needs page stuff ends

	
}
