package com.rbs.automation.dj.stepdefinitions;

import cucumber.api.PendingException;
import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.AccountDetailsPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccountDetailsPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	AccountDetailsPage accountDetailsPage;
	private HelperFunctions helper = new HelperFunctions();

	public AccountDetailsPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		accountDetailsPage = testContext.getPageObjectManager().getAccountDetailsPage(context);

	}

	@Then("^the account details page is displayed$")
	public void the_account_details_page_is_displayed() throws Throwable {

		accountDetailsPage.verifyAccountDetailsPageIsDisplayed();
	}
	
	@When("^user selects a bank account \"([^\"]*)\"$")
	public void user_selects_a_bank_account(String acountName) throws Throwable {
	  
		accountDetailsPage.selectBankAccount(acountName);
	}

	@When("^clicks Continue Application button on Account details page$")
	public void clicks_Continue_Application_button_on_Account_details_page() throws Throwable {
	   
		accountDetailsPage.AccountDetails_ClickContinue();
	}

	@When("^user clicks the Continue button on the account details page$")
	public void user_clicks_the_Continue_button_on_the_account_details_page() throws Throwable {

		accountDetailsPage.AccountDetails_ClickContinue();

	}

}
