package com.rbs.automation.dj.stepdefinitions;

import org.openqa.selenium.WebDriver;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.managers.WebDriverManager;
import com.rbs.automation.dj.pages.CreditCheckPage;
import com.rbs.automation.dj.testcontext.TestContext;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditCheckPageStepDefinitions {
	WebDriver driver;
	WebDriverManager webDriverManager;
	TestContext testContext;
	CreditCheckPage creditCheckPage;
	private HelperFunctions helper = new HelperFunctions();

	public CreditCheckPageStepDefinitions(TestContext context) {

		testContext = context;
		driver = testContext.getWebDriverManager().getDriver();
		creditCheckPage = testContext.getPageObjectManager().getCreditCheckPage(context);

	}

	@Then("^user enters details for credit check \"([^\"]*)\" and \"([^\"]*)\" and continues$")
	public void user_enters_details_for_credit_check_and_and_continues(String email, String mobileNumber)
			throws Throwable {

		creditCheckPage.CreditCheck_AddDetails_ClickContinue(email, mobileNumber);
	}

	@When("^verify that the application in progress is displayed and click exit$")
	public void verify_that_the_application_in_progress_is_displayed_and_click_exit() throws Throwable {

		creditCheckPage.ApplicationInProgress_Click_Exit();
	}

	@Then("^complete legal X steps$")
	public void complete_legal_X_steps() throws Throwable {

		creditCheckPage.LegalXCheck();
	}
}
