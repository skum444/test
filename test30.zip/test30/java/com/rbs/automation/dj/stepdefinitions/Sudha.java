package com.rbs.automation.dj.stepdefinitions;

import java.sql.*;

public class Sudha {
    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@vstuogb01d.server.rbsgrp.mde:1535:UOGBLN1",
                    "LND_APP_USER_RO", "L3nd09z3rR0#1881");
            Statement stmt = connection.createStatement();
            ResultSet resultSet=null;
            //stmt = connection.createStatement();
            resultSet = stmt.executeQuery("select SOFT_SEARCH_CONSENT_FLAG from LND_APP_OWNER.LND_APP_APPL_DETAIL_TB where APPL_ID = 'DJ000487330'");
            if (resultSet.next()) {
                //System.out.println((resultSet.getString(14)));
                System.out.println((resultSet.getString("SOFT_SEARCH_CONSENT_FLAG")));
            }
        } catch (ClassNotFoundException e) {

        } catch (Exception e) {

        }

    }
}
