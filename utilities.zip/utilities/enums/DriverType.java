package com.rbs.automation.dj.enums;

public enum DriverType {

	FIREFOX,
	CHROME,
	INTERNETEXPLORER,
	
}
