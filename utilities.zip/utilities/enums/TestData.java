package com.rbs.automation.dj.enums;

public enum TestData {

    TestName,
    Segment,
    DBID,
    ApplicationID,
    PortfolioCode,
    ApplicationStatus,
    ApplicationSubStatus,
    ApplicationExpDate,
    ApplicationStartDate,
    ApplicationUpdatedDate,
    PageName,
    Status,
    Brand,
    NeedsInfo,
    EnityType,
    TestDescription,
    StartTime,
    EndTime,
    Browser,
    TestSnapShotDir,
    NetworkErrors,
    ReasonText,
    BIN,
    CustTypeFromDB,
    TestResultsDir,
    DataComparision,
    ScenarioName,
    TestRunName,
    JIRA,
    KPStatus,
    Email,
    Phone,
    ReportingDate,
    ApplicationPrevStatus,
    SICCode


}
