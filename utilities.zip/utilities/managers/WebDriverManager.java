
package com.rbs.automation.dj.managers;

import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.net.Urls;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.rbs.automation.dj.enums.DriverType;
import com.rbs.automation.dj.enums.EnvironmentType;

public class WebDriverManager {

	private WebDriver driver;
	private static DriverType driverType;
	private static EnvironmentType environmentType;
	private static String deviceName;
	private static String deviceOrientation;
	private static String browserName;
	private static String platformVersion;
	private static String platformName;
	private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
	
	public static final String USERNAME = System.getenv("SAUCE_USER");
	public static final String ACCESS_KEY = System.getenv("SAUCE_PASS");
	public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";
	
	DesiredCapabilities caps;	
 
	public WebDriverManager() {
		driverType = FileReaderManager.getInstance().getConfigReader().getBrowser();
		environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();		
		deviceName=FileReaderManager.getInstance().getConfigReader().getDeviceName();
		deviceOrientation=FileReaderManager.getInstance().getConfigReader().getDeviceOrientation();
		browserName=FileReaderManager.getInstance().getConfigReader().getBrowserName();
		platformVersion=FileReaderManager.getInstance().getConfigReader().getPlatformVersion();
		platformName=FileReaderManager.getInstance().getConfigReader().getPlatformName();
	}
	//fileImagePath
	
 
	public WebDriver getDriver() {
		if(driver == null) driver = createDriver();
		return driver;
	}
	
	

 
	private WebDriver createDriver() {
		switch (environmentType) {	    
        case LOCAL : driver = createLocalDriver();
        	break;
        case REMOTE : driver = createRemoteDriver();
        	break;
        case MOBILE : driver = createMobileRemoteDriver();
	   }
	   return driver;
	}
 
	private WebDriver createRemoteDriver() {
		throw new RuntimeException("RemoteWebDriver is not yet implemented");
	}
 
	private WebDriver createMobileRemoteDriver() {		
		caps = DesiredCapabilities.chrome();
		/*caps.setCapability("platform", "Windows 10");
		caps.setCapability("version", "66.0");*/
		caps.setCapability("appiumVersion", "1.9.1");
		caps.setCapability("deviceName",deviceName);
		caps.setCapability("deviceOrientation", deviceOrientation);
		caps.setCapability("platformVersion",platformVersion);
		caps.setCapability("platformName", platformName);
		caps.setCapability("browserName", browserName);
		caps.setCapability("idle-timeout","180");
		//Set the tunnel 
		caps.setCapability("tunnel-identifier", "DIGITALSTUDIOSECURE");
		caps.setCapability("parentTunnel","RBS_Admin");
		driver = new ProxyEnabledRemoteWebDriver().get(caps, URL);
		return driver;		
	}
	
	private WebDriver createLocalDriver() {
        switch (driverType) {	    
        case FIREFOX : driver = new FirefoxDriver();
	    	break;
        case CHROME : 
        	System.setProperty(CHROME_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getDriverPath());
        	ChromeOptions options = new ChromeOptions();

        	options.addArguments("test-type");
        	options.addArguments("start-maximized");
        	options.addArguments("--js-flags=--expose-gc");
        	options.addArguments("--enable-precise-memory-info");
        	options.addArguments("--disable-popup-blocking");
        	options.addArguments("--disable-default-apps");
        	options.addArguments("--disable-notifications");     	
        	options.addArguments("test-type=browser");    
        	options.addArguments("disable-infobars");
        	
        	options.setExperimentalOption("useAutomationExtension", false);
            
        	// Network logging performance
        	LoggingPreferences logPrefs = new LoggingPreferences();
        	logPrefs.enable(LogType.PERFORMANCE, Level.INFO);
        	options.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
        	DesiredCapabilities dc = DesiredCapabilities.chrome();
        	dc.setCapability(ChromeOptions.CAPABILITY, options);
        	driver = new ChromeDriver(options);
        
    		break;
        case INTERNETEXPLORER : driver = new InternetExplorerDriver();
    		break;
        }
 
        if(FileReaderManager.getInstance().getConfigReader().getBrowserWindowSize()) driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
		
        return driver;
	}	
 
	public void closeDriver() {
		driver.close();
		driver.quit();
	}
 
}
