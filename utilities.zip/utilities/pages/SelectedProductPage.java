package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class SelectedProductPage {

	private WebDriver driver;
	private String sTestDataSheetName = "SelectedProduct";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public SelectedProductPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	
	public void SelectProduct_ClickContinue() throws Exception {
		try {

			Thread.sleep(2000);
			// Click continue on Selected Product Page
			helper.clickAnyButtonInDigitalJourney("Continue",driver,testContext);

			

		} catch (Exception e) {

			helper.failTest("Selected product page", "Selected product page is not displayed", e.getMessage(), driver,testContext);
		}

	}

	public void ContinueToLombard_ClickContinue() throws Exception {
		try {

			
			Thread.sleep(2000);
			
			testContext.scenarioContext.setContext(TestData.PageName, "Lombard-Redirect");
			helper.clickAnyButtonInDigitalJourney("Continue to lombard.co.uk",driver,testContext);
			
		} catch (Exception e) {

			helper.failTest("Lombard Redirect page", "Lombard Redirect page is not displayed", e.getMessage(), driver,testContext);
		}

	}

	public void verifySelectedProductPageIsDisplayed() throws Exception {
		
		helper.initialisePage(driver, testContext, "SelectedProduct");
		
		try {
			String text = driver.findElement(By.xpath("//h2[text() = 'Selected product']")).getText();
			
			if (!(text.equals("Selected product"))) {
				helper.failTest("Selected product page", "Selected product page is not displayed","", driver,testContext);
			}
		} catch (Exception e) {
			
			helper.failTest("Selected product page", "Selected product page is not displayed", e.getMessage(), driver,testContext);
		}
	}

	

}
