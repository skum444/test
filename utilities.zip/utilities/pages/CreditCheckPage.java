package com.rbs.automation.dj.pages;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class CreditCheckPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	public CreditCheckPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}
	
	@FindBy(how = How.XPATH, using = "//div[@class='AgreementPage_container_UrMa']/button")
	public WebElement btnExit;

	
	
	public void ApplicationInProgress_Click_Exit() throws Exception {
		try {
			
			
			verifyAIPPageIsDisplayed();
		
			helper.clickAnyButtonInDigitalJourney("Exit", "2",driver,testContext);


		} catch (Exception e) {
		
			helper.failTest("Application Inprogress ", "Application Inprogress", e.getMessage(), driver,testContext);
			
		}

	}

	private void verifyAIPPageIsDisplayed() throws Exception {

		helper.initialisePage(driver, testContext, "ApplicationInProgress");

		helper.setImplicitTimeout(driver, 0);

		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//h1[contains(text(), 'Your application is in progress')]")));

			String text = driver.findElement(By.xpath("//h1[contains(text(), 'Your application is in progress')]"))
					.getText();
			
		
			if (!(text.contains("Your application is in progress")))
				helper.failTest("Application In progress ", "Application Inprogress page is not displayed", "",
						driver,testContext);

			helper.resetImplicitTimeoutToDefault(driver);
			
			
			
		} catch (Exception e) {
			helper.resetImplicitTimeoutToDefault(driver);
			helper.failTest("Application Inprogress ", "Application Inprogress", e.getMessage(), driver,testContext);
		
		
		}

	}
	
	
	
	
	public void CreditCheck_AddDetails_ClickContinue(String email, String mobileNumber) throws Exception {

		

		try {

			Thread.sleep(2000);

			//Set Month
			DJ1_setDateMovedIn("mainMt", "March");
			
			Thread.sleep(3000);
			//Set YEar
			DJ1_setDateMovedIn("mainYr", "2009");
			
			
			if (WaitUtils.isElementPresentWithoutImplicitWait(driver, By.id("secondaryMt"))) {

			
			//Set Month
			DJ1_setDateMovedIn("secondaryMt", "March");
			
			Thread.sleep(2000);
			//Set YEar
			DJ1_setDateMovedIn("secondaryYr", "2009");
			

			Thread.sleep(2000);
			
			
			// Add details mobile number and email
			email = helper.randomAlphaNumeric(4) + email;
			
			driver.findElements(By.xpath("//a[@id='manualAddress']")).get(1).click();
			
			// Add email
			driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(email);
				
			// Add mobile phone
			driver.findElement(By.xpath("//input[@id='mobileNumber']")).sendKeys(mobileNumber);
						
			// Add mobile phone
			driver.findElement(By.xpath("//button[contains(text(), 'Save changes')]")).click();
			
			}
					
			helper.clickAnyButtonInDigitalJourney("Confirm & run a credit check",driver,testContext);
			
			
			


		} catch (Exception e) {

			helper.failTest("Credit Check page ", "Credit Check page is not displayed", e.getMessage(), driver,testContext);
		}

	}

	
	// Set Date Moved in 
	private void DJ1_setDateMovedIn(String id, String textToSelect) {

		// Select the drop down
		WebElement ddElement = driver.findElement(By.xpath("//*[@id='"+id+"']"));
		ddElement.click();
		
		try {
			// Select option
			WebElement option = driver.findElement(By.xpath("//div[contains(text(),'"+textToSelect+"')]"));
			option.click();
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			// Select option
						WebElement option = driver.findElement(By.xpath("//div[contains(text(),'"+textToSelect+"')]"));
						option.click();
		}

	}

	
	public void LegalXCheck() throws Exception
	{
		
		boolean foundLandingPage = false;
		
		helper.setImplicitTimeout(driver, 5);


		WebDriverWait wait = new WebDriverWait(driver, 80);

		if (wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'approved your')]")))
				.isDisplayed())
			foundLandingPage = true;

		
		// Confirm & run credit check
		if (!foundLandingPage)
			helper.failTest("One Connect JourneyFlow", "Credit Check failed", "", driver,testContext);

		
		Thread.sleep(10000);

		//================================
		
		if (helper.isElementPresent(By.xpath("//button[text()='View documents']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("View documents",driver,testContext);
		
		
		 
		if (helper.isElementPresent(By.xpath("//button[text()='Confirm']"),driver)) 
		    helper.clickAnyButtonInDigitalJourney("Confirm",driver,testContext);
		
		
		if (helper.isElementPresent(By.xpath("//button[text()='Confirm']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("Confirm",driver,testContext);

		
		if (helper.isElementPresent(By.xpath("//button[text()='Read & sign your agreement']"),driver))  
			helper.clickAnyButtonInDigitalJourney("Read & sign your agreement",driver,testContext);

		
		
		if (helper.isElementPresent(By.xpath("//button[text()='Read & sign your documents']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("Read & sign your documents",driver,testContext);
		
		Thread.sleep(4000);
		
		helper.getLatestWindowFocused(driver);
		
		System.out.println(driver.getTitle());
		if( driver.getTitle() == "Untitled")
			Assert.fail("POP UP NOT DISPLAYED");

		
		if (helper.isElementPresent(By.xpath("//div[contains(text(),'Cookies')]"),driver)) 
			driver.findElement(By.id("_evidon-accept-button")).click();
	
		
		if (helper.isElementPresent(By.xpath("//span[@class='checkbox-image']"),driver)) 
		    driver.findElement(By.xpath("//span[@class='checkbox-image']")).click();

	
		if (helper.isElementPresent(By.id("_evidon-accept-button"),driver)) 
		    driver.findElement(By.id("_evidon-accept-button")).click();
		
		if (helper.isElementPresent(By.xpath("//button[contains(@class, 'btn btn-primary agree-to-terms')]"),driver)) 
		       driver.findElement(By.xpath("//button[contains(@class, 'btn btn-primary agree-to-terms')]")).click();
		
		
		
		if (helper.isElementPresent(By.xpath("//button[contains(@class, 'coachmark')]"),driver)) 
		driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
		
		
		Thread.sleep(3000);
		if (helper.isElementPresent(By.xpath("//button[@class='btn btn-primary click-to-esign ']"),driver)) 
		   driver.findElement(By.xpath("//button[@class='btn btn-primary click-to-esign ']")).click();
		
		if (helper.isElementPresent(By.xpath("//div[@class='faux_field']"),driver)) 
			driver.findElement(By.xpath("//div[@class='faux_field']")).click();
		
		if (helper.isElementPresent(By.xpath("//input[@value='test']"),driver)) 
			driver.findElement(By.xpath("//input[@value='test']")).sendKeys("test");

			

		if (helper.isElementPresent(By.xpath("//button[text()='Apply']"),driver)) 
			driver.findElement(By.xpath("//button[text()='Apply']")).click();
		
		
		Thread.sleep(3000);
		
		if (helper.isElementPresent(By.id("form-control-signerName"),driver))   {
			driver.findElement(By.id("form-control-signerName")).sendKeys("test");
			driver.findElement(By.id("form-control-signerName")).sendKeys(Keys.ENTER);
		}
		
		
		Thread.sleep(3000);
		
		if (helper.isElementPresent(By.xpath("//button[text()='Accept']"),driver))
		driver.findElement(By.xpath("//button[text()='Accept']")).click();
		

		if (helper.isElementPresent(By.id("download-signed-pdf"),driver))
			driver.findElement(By.id("download-signed-pdf")).click();  
		
		Thread.sleep(2000);
		driver.close();
		Thread.sleep(2000);
		helper.getLatestWindowFocused(driver);
		
		
		helper.waitForLoading(driver);
		helper.clickAnyButtonInDigitalJourney("Close this page",driver,testContext);
		
		helper.resetImplicitTimeoutToDefault(driver);

	}




	public void verifyCreditCheckPageIsDisplayed() throws Exception {
		
		helper.initialisePage(driver, testContext, "CreditCheck");
		
		try {
			
			String text = driver.findElement(By.xpath("//h1[contains(text(), 'Confirm details and run a credit check')]")).getText();
			
			
			if (!(text.contains("Confirm details and run a credit check"))) {
				helper.failTest("Credit Check page ", "Credit Check page is not displayed", "", driver,testContext);
			}
		} catch (Exception e) {
			
			helper.failTest("Credit Check page ", "Credit Check page is not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	
	}
