package com.rbs.automation.dj.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.ExcelUtils;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class UB_PersonalisedQuotePage {

    private WebDriver driver;
    private HelperFunctions helper = new HelperFunctions();
    public String Term_month ;
    TestContext testContext;
    private String NeedsInfo = "";

    // initialise the page elements when the class is instantiated
    public UB_PersonalisedQuotePage(WebDriver driver, TestContext context) {

        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;

    }

    @FindBy(how = How.XPATH, using = "//*[@class='zb-heading1 personalise-your-quote']")
    public WebElement header;

    @FindBy(how = How.XPATH, using = "//input[@class='quote-form-money']")
    public WebElement txtAmountRequired;
    
   // @FindBy(how = How.XPATH, using = "//div[@class=' css-1hwfws3']")
   // public WebElement ddMonth;
    
    @FindBy(how = How.XPATH, using = "(//input)[2]")
    public WebElement ddMonth;
    
    @FindBy(how = How.XPATH, using = "//input[@value='Select month']")
    public WebElement ddTermMonths;
     
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Grow your business')]")
    public WebElement purposeGrowYourBusiness;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'For assets')]")
    public WebElement purposeForAssets;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'For daily cash flow')]")
    public WebElement purposeForDailyCashFlow;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'For a vehicle')]")
    public WebElement purposeForAVehicle;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'To consolidate debt')]")
    public WebElement purposeToConsolidateDebt;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Help with your tax')]")
    public WebElement purposeToHelpWithYourTax;

    @FindBy(how = How.XPATH, using = "//input[@value='Agricultural stocking facility']")
    public WebElement purposeAgriculturalStockingFacility;
    
    @FindBy(how = How.XPATH, using = "(//div[@class='validation-message'])[1]")
    public WebElement txtValidationErrorMsg;
    

    
    public void VerifyAllStandardPurposeAreDisplayed() throws Exception
    {
    	try {
    	purposeGrowYourBusiness.isDisplayed();
    	purposeForAssets.isDisplayed();
    	purposeForAVehicle.isDisplayed();
    	purposeToConsolidateDebt.isDisplayed();
    	purposeToHelpWithYourTax.isDisplayed();
    	}
    	catch(Exception e)
    	{
    		helper.failTest("Verify Purposes", "All Pruposes displayed", e.getMessage(), driver, testContext);
    	}
  
    }
    
    // Verify Agricultural stocking facility option is displayed
    public void VerifyThatPurposeisDisplayed(String purpose) throws Exception {
    	
    	
    	if(!helper.isElementPresent(By.xpath("//div[contains(text(),'"+ purpose +"')]"), driver))
    		
    	{
    		helper.failTest("Personalised Quote Page", purpose + "  should be displayed", purpose + "  IS NOT displayed", driver, testContext);
    	}
    }
    

    
    public void setQuoteParameters(String purpose, String amount, String termYears, String termMonths) throws Exception {
    	
    	selectPurpose(purpose);
    	setBorrowingAmount(amount);
    	setBorrowingTerm(termYears, termMonths);
    	
    }

    // Select Purpose
    public void selectPurpose(String purpose) throws Exception {

    
    	
        driver.findElement(By.xpath("//div[contains(text(),'" + purpose + "')]")).click();

    }
    
    // Set amount to borrow
    public void setBorrowingAmount(String amount) throws Exception {
    	
    	helper.enterValue(txtAmountRequired, amount);
    	
    }
    
    
    private void setBorrowingTerm(String termYears, String termMonths) {

        // setup value to be selected for term i.e year & Month
        String months = "";
        String years = "";
        
        if (Integer.parseInt(termMonths) <= 1) {
            months = termMonths + " month";
            
            if(Integer.parseInt(termMonths) == 0)
            	months = "";
            	
        } else {
            months = termMonths + " months";
        }
        
        if (Integer.parseInt(termYears) <= 1) {
        	years = termYears + " year";
        } else {
        	years = termYears + " years";
        }
        
       
        
        String termString = years + ", " + months;
        
       
        
        // select Months
        ddMonth.click();
        System.out.println("termString : " + termString);
        driver.findElement(By.xpath("//div[contains(text(), '" + termString + "')]")).click();


    }
    
    public void setQuoteParamsTermInMonths(String purpose, String amount, String termInMonths) throws Exception {

    	
    	selectPurpose(purpose);
    	setBorrowingAmount(amount);
    
    	// select Months
        ddMonth.sendKeys(termInMonths);
        
    }
    
    
    
    
    public void VerifyCorrectMonthsToYearMonthconversion(String expectedTermInMonthsandYears)
    {
    	
    	driver.findElement(By.xpath("//div[contains(text(), '" + expectedTermInMonthsandYears + "')]")).isDisplayed();
    }
    
    
    
    
    
  public void clickGetQuote() throws Exception {

        helper.clickAnyButtonInDigitalJourney("Get quote", driver, testContext);
    }
    
    

  
    // Verify get quote button is disabled
    public void verifyGetQuoteButtonIsDisabled() throws Exception {
    	
    	if(driver.findElement(By.xpath("//button[text()='Get quote']")).isEnabled())
    	{
    		helper.failTest("Personalised Quote Page", "When an error occurs, the Get quote button should be disabled", "the Get quote button is enabled", driver, testContext);
    	}
    }
    
    // Verify Agricultural stocking facility option is displayed
    public void verifyAgriculturalStockingIsNotDisplayed(String purpose) throws Exception {
    	
    	
    	if(helper.isElementPresent(By.xpath("//div[contains(text(),'"+ purpose +"')]"), driver))
    		
    	{
    		helper.failTest("Personalised Quote Page", purpose + "  should NOT be displayed", purpose + "  IS displayed", driver, testContext);
    	}
    }
    
    
    
    
    
    
    
    // verify error message is displayed
    public void validateErrorMessageIsDisplayed(String errorMsg) throws Exception {
    	txtValidationErrorMsg.getText().contains(errorMsg);
    }
    
  
    
    //Verify Quotes page is displayed
    public void verifyPersonalisedQuotePageIsDisplayed() throws Exception {

    	driver.findElement(By.xpath("//input[@class='confirm-to-continue-checkbox form-check-input']")).click();
    	
    	helper.clickAnyButtonInDigitalJourney("Get Started", driver, testContext);
    	
    	helper.waitForLoading(driver);
    	
        helper.initialisePage(driver, testContext, "Quote");

        try {
           
        		

        	
            if (!(header.getText().contains("Personalise your quote"))) {
                helper.failTest("Personalised quote page is not displayed", "Personalised quote page is displayed", "Personalised quote page is not displayed", driver, testContext);


            }
        } catch (Exception e) {

            helper.failTest("Personalised quote page is not displayed", "Personalised quote page is displayed", e.getMessage(), driver, testContext);

        }
    }

   



   

}

