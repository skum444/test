package com.rbs.automation.dj.pages;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class BPMMyWorksPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();	
	private WaitUtils waitUtils;
	public static String user = null;

	// initialise the page elements when the class is instantiated
	public BPMMyWorksPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
		testContext.scenarioContext.setContext(TestData.PageName, "BPMWorksTabPage");
	}
	
	@FindBy(how = How.XPATH, using = "//h2")
	public WebElement txtH2Header;

	@FindBy(how = How.XPATH, using = "//div[(contains(@class,'form-group has-feedback empty'))]//input[(contains(@class,'form-control ng-pristine'))]")
	public WebElement txtSearchBar;
	
	//@FindBy(how = How.XPATH, using = "//div[@class='bpm-social-magnify']")
	//@FindBy(how = How.ID, using = "update-filter")
	@FindBy(how = How.XPATH, using = "//button[@title='Search']")
	public WebElement btnSearchButton;
	
	@FindBy(how = How.XPATH, using = "//button[text() ='Claim Task']")
	public WebElement btnClaimTask;
	
	
	@FindBy(how = How.XPATH, using = "//a[@title='Click to work on the task']")
	public WebElement lnkClaimTask;
	
	@FindBy(how = How.XPATH, using = "//a[@title='Lending Digital Search Screen']")
	public WebElement lnkLendingDigitalSearch;

	@FindBy(how = How.XPATH,using = "//a[contains(text(),'Show')][1]")
	public WebElement showMoreConnect;

	@FindBy(how= How.XPATH,using = "//a[contains(text(),'BBConnect New Applications')]")
	public WebElement bbcConnectNew;
	
	@FindBy(how= How.XPATH,using = "//a[contains(text(),'Digital Journey Applications')]")
	public WebElement digitalApplications;
	
	//Works tab
	@FindBy(how= How.XPATH,using = "//a[contains(text(),'‪Work‬')]")
	public WebElement worksTab;
	
	@FindBy(how= How.XPATH,using = "//a[contains(text(),'‪Digital Pending Applications‬')]")
	public WebElement pendingApplicationsTab;
	
	@FindBy(how= How.XPATH,using = "//input[@placeholder='Enter search text...']")
	public WebElement pendingTabTextBox;
	
	
	//@FindBy(how = How.XPATH,using = "//div[(contains(@class,'form-group has-feedback empty'))]//input[(contains(@class,'form-control ng-pristine'))]")
   // public WebElement inputTextInSrchBox;


	public void verifyBPMWorksTabPageIsDisplayed() throws Exception {

		helper.initialisePage(driver, testContext, "BBConnect New");

		try {
			Thread.sleep(4000);
			showMoreConnect.click();
			Thread.sleep(4000);
			worksTab.click();
		}catch (Exception e) {
			e.printStackTrace();
		}

		try {
			Thread.sleep(5000);
			//digitalApplications.click();
			
			if((showMoreConnect.getText()).contains("Show less..."))
			{
				showMoreConnect.click();
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}

		/*try {

			waitUtils.waitForLoading(driver);
 			String h2Header = txtH2Header.getText();			
			boolean headerNotFound=false;			
			if(h2Header.contains("My Work"))
				headerNotFound = true;				
			if(headerNotFound == false)
				helper.failTest("BPM - My Works page", "BPM Works page is not displayed", "", driver,testContext);
		} catch (Exception e) {
			helper.failTest("BPM - My Works page", "BPM Works page is not displayed", e.getMessage(), driver,testContext);
		}*/
	}
	
	public void claimTaskForApplicationID(String userID) throws Exception {		
		try {
			//String applicationID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
			//For scripting purpose
			String applicationID = "DJ000549022";
			txtSearchBar.sendKeys(applicationID);	
			btnSearchButton.click();
			Thread.sleep(2000);
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
			
			toClaimSpecificApplication(userID);
			//lnkClaimTask.click();
			if(driver.findElements(By.xpath("//button[text() ='Claim Task']")).size()>0)
				btnClaimTask.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickLendingDigitalSearchLink() throws Exception{
		try {
			lnkLendingDigitalSearch.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void toClaimSpecificApplication(String userID) throws Exception {
		try {
		//String applicationID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
		//For scripting purpose
		String applicationID = "DJ000549022";
		WebElement claim;
		user = userID;
		List<WebElement> titleForApp = driver.findElements(By.xpath("//a[contains(text(),'for')]"));
		claim = titleForApp.get(2);	
		/*if((userID.contains("REF"))||(userID.contains("CBDIR"))||(userID.contains("CBFI")))
		{
			List<WebElement> titleForApp = driver.findElements(By.xpath("//a[contains(text(),'for')]"));
			claim = titleForApp.get(2);	
		    //claim =driver.findElement(By.xpath("//a[contains(text(),'Process application for')]"));
		}
		else
		{
		 //claim =driver.findElement(By.xpath("//span[@title='"+applicationID+"']"));
			claim =driver.findElement(By.xpath("//span[contains(@title,'"+applicationID+"')]"));
		}*/
		
		claim.click();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			helper.failTest("To claim BPM task", "BPM task should be claimed successfully", "BPM task is not claimed successfully", driver, testContext);
		}
		
	}
	public void pendingTabValidation() throws Exception{
		try {
			showMoreConnect.click();
			Thread.sleep(2000);
			pendingApplicationsTab.click();
			//String applicationID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
			//For scripting purpose
			Thread.sleep(2000);
			String applicationID = "DJ000549022";
			pendingTabTextBox.sendKeys(applicationID);
			btnSearchButton.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void appValidationInPendingTab() throws Exception {
		try {	
			//String applicationID = (String)testContext.scenarioContext.getContext(TestData.ApplicationID);
			//For scripting purpose
		String applicationID = "DJ000549022";
		WebElement appIDRow = driver.findElement(By.xpath("//div[@class='ui-grid-cell-contents ng-scope']//span[contains(@title,'DJ0')]"));
		String appIDtext = appIDRow.getText();
		if (appIDtext.equalsIgnoreCase(applicationID))
		{
			System.out.println("Application is displayed in pending applications tab");
		}
		else
		{
			helper.failTest("Pending tab validation", "Application should be displayed in pending tab", "Application is not displayed in pending tab", driver, testContext);
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			helper.failTest("Pending tab validation", "There should not be any issues in pending tab", "Thereis an issue with pending tab", driver, testContext);
		}
		
	}
}

