package com.rbs.automation.dj.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class LoginPage {

	private WebDriver driver;
	private String sTestDataSheetName = "LoginPage";
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private WaitUtils waitUtils;

	// initialise the page elements when the class is instantiated
	// initialise the page elements when the class is instantiated
	public LoginPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;

	}

	@FindBy(how = How.ID, using = "customerNumberProxy")
	public WebElement inputDBID;

	@FindBy(how = How.XPATH, using = "//button[text()='Try again']")
	public WebElement btnRetry;

	@FindBy(how = How.XPATH, using = "//button[text()='Continue']")
	public WebElement btnLogin;

	@FindBy(how = How.ID, using = "cin")
	public WebElement CIN;

	@FindBy(how = How.ID, using = "bin")
	public WebElement BIN;

	@FindBy(how = How.ID, using = "dbin")
	public WebElement DBIN;

	@FindBy(how = How.ID, using = "blcin")
	public WebElement BLCIN;

	@FindBy(how = How.XPATH, using = "//button[contains(text(),' Sign in')]")
	public WebElement SignIn;

	public void inputCustomerID(String DBID) throws Exception {

		try {

			helper.initialisePage(driver, testContext, "Login");

			// Enter values
			inputDBID.sendKeys(DBID);

			// click to continue
			helper.clickAnyButtonInDigitalJourney("Continue", driver, testContext);

			if (WaitUtils.isElementPresentWithoutImplicitWait(driver,
					By.xpath("//span[@class= 'pageError-message']"))) {

				helper.failTest("Login page not displayed", "Login page not displayed", "", driver, testContext);
			}

		} catch (Exception e) {

			helper.failTest("Login page not displayed", "Login page not displayed", "", driver, testContext);
		}

	}
		 public void enterAllDataToContinue()
		{
			helper.waitForWebElementToBeVisible(driver,SignIn);
			//driver.getWindowHandles();
			//driver.switchTo().activeElement();
			driver.switchTo().defaultContent();
			driver.findElement(By.id("cin")).sendKeys("123456");
			//CIN.sendKeys("123456");
			BIN.sendKeys("123456");
			DBIN.sendKeys("123456");
			BLCIN.sendKeys("123456");
			SignIn.click();

		}
	}

