package com.rbs.automation.dj.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.helpers.ExcelUtils;

public class BPMApplicationSummaryPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;
	private String sTestDataSheetName = "BPM";
	public static String frameText = null;

	// initialise the page elements when the class is instantiated
	public BPMApplicationSummaryPage(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
		testContext.scenarioContext.setContext(TestData.PageName, "BPMApplicationSummaryPage");
	}
	
	@FindBy(how = How.XPATH, using = "(//h2)[2]")
	public WebElement txtH2Header;

	@FindBy(how = How.XPATH, using = "//input[@id='com_ibm_bpm_social_widgets_task_list_SearchBar_0_input']")
	public WebElement txtSearchBar;
	
	@FindBy(how = How.XPATH, using = "//div[@class='bpm-social-magnify']")
	public WebElement btnSearchButton;
	
	@FindBy(how = How.XPATH, using = "//button[text() ='Claim Task']")
	public WebElement btnClaimTask;
	
	@FindBy(how = How.XPATH, using = "//input[@id='dijit_form_FilteringSelect_1']")
	public WebElement txtApplicationDecision;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement btnSubmit;
	
	@FindBy(how = How.XPATH, using = "(//button[contains(text(),'Submit')])[2]")
	public WebElement btnCBSubmit;
			
	@FindBy(how = How.XPATH, using = "//textarea[@id='dijit_form_Textarea_0']")
	public WebElement txtReferralDetails;
	
	@FindBy(how = How.XPATH, using = "//input[@id='dijit_form_FilteringSelect_0']")
	public WebElement txtbbrmTeam;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Print')][1]")
	public WebElement btnPrint;
	
	@FindBy(how = How.XPATH, using = "(//button[contains(text(),'Submit')]")
	public WebElement btnCBPrint;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Referral reason')]/parent::div/parent::div/following-sibling::div//span")
	public WebElement txtRefReason;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Download report')][1]")
	public WebElement lnkDownloadReport;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(text(),'Download report')])[2]")
	public WebElement lnkCBDownloadReport;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Call back complete')]")
	public WebElement btnCBComplete;
	

	public void verifyBPMApplicationSummaryPageIsDisplayed() throws Exception {		
		helper.initialisePage(driver, testContext, "ApplicationSummaryPage");		
		try {		
		/*	String user = BPMMyWorksPage.user;
			if(user.contains("REF"))
			{
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'Process application for')]")));
			}
			else
				{
				
				List<WebElement> frameList = driver.findElements(By.xpath("//iframe"));
				String frameText = frameList.get(2).getAttribute("title");
	            
				driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'"+frameText+"')]")));
				
				}*/
			List<WebElement> frameList = driver.findElements(By.xpath("//iframe"));
			 frameText = frameList.get(2).getAttribute("title");
            
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'"+frameText+"')]")));
			
			
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'App Summary')]")));
			String h2Header = driver.findElement(By.xpath("//span[@class='panel-title'][1]")).getText();			
			
			boolean headerNotFound=false;			
			if(h2Header.contains("Tier3 Digital Application Summary"))
				headerNotFound = true;				
			if(headerNotFound == false)
				helper.failTest("BPM - Digital Application Summary page", "BPM Digital Application Summary page is not displayed", "", driver,testContext);				
		} catch (Exception e) {
			e.printStackTrace();
			helper.failTest("BPM - Digital Application Summary page", "BPM Digital Application Summary page is not displayed", e.getMessage(), driver,testContext);
		}
	}
	
	/*public void selectDealTeam1() throws Exception {		
		try {
			// Load data from Data-sheet for the given test into MAP
			String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
			String segment = (String) testContext.scenarioContext.getContext(TestData.Segment);
			String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_DJ1(sTestDataSheetName, testName, brand);
			String applicationID =tdRow.get("ApplicationID");						
			txtSearchBar.sendKeys(applicationID);	
			btnSearchButton.click();
			driver.findElement(By.xpath("//a[contains(text(),'"+applicationID+"')]")).click();

			if(driver.findElements(By.xpath("//button[text() ='Claim Task']")).size()>0)
				btnClaimTask.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/

	public void selectApplicationDecision(String applicationDecision) throws Exception {
		try {			
			
			WebElement dropDownValue = driver.findElement(By.xpath("//select[@id='singleselect-Single_Select2']"));
			Select selectElement = new Select(dropDownValue);
			selectElement.selectByVisibleText(applicationDecision);
			/*txtApplicationDecision.clear();
			Thread.sleep(1000);
			txtApplicationDecision.sendKeys(applicationDecision);			
			txtApplicationDecision.sendKeys(Keys.TAB);*/
			if(applicationDecision.contains("Pending")) {
				dropDownValue = driver.findElement(By.xpath("//select[@id='singleselect-Single_Select3']"));
				 selectElement = new Select(dropDownValue);
				selectElement.selectByVisibleText("10");
				Thread.sleep(2000);
				helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
				List<WebElement> saveExitButton = driver.findElements(By.xpath("//button[contains(text(),'Save & exit')]"));
				if(saveExitButton.size()>0)
				{
					saveExitButton.get(0).click();
				}
				else
				{
					saveExitButton.get(1).click();
				}
			}
			String segment = (String) testContext.scenarioContext.getContext(TestData.Segment);
			String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
			/*Thread.sleep(1000);
			if((segment.equalsIgnoreCase("CB"))&&(applicationDecision.contains("Referred")))
				inputReferralDetails();*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void inputReferralDetails() throws Exception {
		try {
			String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);	
			String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_DJ1(sTestDataSheetName, testName, brand);
			txtReferralDetails.clear();
			Thread.sleep(1000);
			txtReferralDetails.sendKeys(tdRow.get("Referral Details"));			
			txtApplicationDecision.sendKeys(Keys.TAB);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void submitApplication(String dealTeam) throws Exception {
		try {
			
			/*if(txtRefReason.getText().contains("Call Back")){
				btnCBPrint.click();	
				Thread.sleep(5000);
				lnkCBDownloadReport.click();
				Thread.sleep(1000);
				helper.addfullScreenCaptureToExtentReport(driver, testContext);
				List<WebElement> reason = driver.findElements(By.xpath("//label[contains(text(),'Referral reason')]/parent::div/parent::div/following-sibling::div//span"));
				boolean reasonText = false;
				OuterLoop: // label
				for (int j = 1; j <= reason.size(); j++) {					
					if ((reason.get(j-1).getText().contains("Route to RM"))) {						
						reasonText = true;
						break OuterLoop;
					}
				}				
				if(reasonText==false){
					btnCBSubmit.click();
				}
				else{
					btnCBComplete.click();
				}
			}else{
				btnPrint.click();
				Thread.sleep(3000);
				lnkDownloadReport.click();
				Thread.sleep(1000);
				helper.addfullScreenCaptureToExtentReport(driver, testContext);
				btnSubmit.click();
			}*/
			WebElement submit = null;
			WebElement print;
			WebElement report;
			//Uncomment after print issue fix
			
			/*List<WebElement> buttonPrint = driver.findElements(By.xpath("//button[text()='Print']"));
			
			if((frameText.contains("Process application"))||(frameText.contains("Key in FI"))) {
				print = buttonPrint.get(0);
			}
			else {
			print = buttonPrint.get(1);
			}
			print.click();
			Thread.sleep(3000);
			List<WebElement> reportDownload = driver.findElements(By.xpath("//a[contains(text(),'Download report')]"));
			if((frameText.contains("Process application"))||(frameText.contains("Key in FI"))) {
				report = reportDownload.get(0);
			}
			else {
				report = reportDownload.get(1);
			}
			report.click();*/
			//-----------------------------
			/*//a[contains(text(),'Download report')]
			//btnPrint.click();
			//List<WebElement> reportDownload = driver.findElements(By.xpath("//a[contains(text(),'Download report')]"));
			//a[contains(text(),'Download report')]
			//lnkDownloadReport.click();*/
			
			
			
			Thread.sleep(1000);
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
			//if(((dealTeam.contains("CBDI"))||((frameText.contains("call back for"))&&(dealTeam.contains("REF")))))
			//if(((frameText.contains("call back for"))&&(dealTeam.contains("CBDI")))||((frameText.contains("call back for"))&&(dealTeam.contains("REF"))))	
			//if((frameText.contains("call back for"))&&((dealTeam.contains("CBDI"))||(dealTeam.contains("REF"))))
			if((frameText.contains("call back for"))&&((dealTeam.contains("CBDI"))))
			{
				submit = driver.findElement(By.xpath("//button[contains(text(),'Call back complete')]"));
			}
			
			else {
			List<WebElement> submitList = driver.findElements(By.xpath("//button[contains(text(),'Submit')]"));
			if(submitList.size()>1)
			{
			submit = submitList.get(1);
			//submit.click();
			}
			else {
				submit = submitList.get(0);
				//submit.click();
			}
			
			}
			submit.click();
			//btnSubmit.click();
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}

	public void selectBBRMTeam(String bbrmTeam) {
		try {
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
			 String[] labelList={"Princi","Products","Financials","App"};
		        for(int i=0;i<labelList.length;i++ ){
		        	String toCheck = labelList[i];
		        	System.out.println("!!!!!!!!!!!!!"+toCheck);
		        	driver.findElement(By.xpath("//span[contains(text(),'"+toCheck+"')]")).click();
		        	
		        	List<WebElement> frameList = driver.findElements(By.xpath("//iframe"));
					 frameText = frameList.get(2).getAttribute("title");
		           driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'"+frameText+"')]")));
					driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@title,'"+toCheck+"')]")));
					helper.addfullScreenCaptureToExtentReport(driver, testContext);
		        }
		
			WebElement dropDownValue = driver.findElement(By.xpath("//select[@id='singleselect-Single_Select1']"));
			Select selectElement = new Select(dropDownValue);
			selectElement.selectByVisibleText(bbrmTeam);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}

