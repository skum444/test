package com.rbs.automation.dj.pages;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.GenericUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.helpers.ExcelUtils;

public class OneConnectJourneyPages {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private GenericUtils genricUtils = new GenericUtils();
	private WaitUtils waitUtils;
	private String sTestDataSheetName = "Done";

	// initialise the page elements when the class is instantiated
	public OneConnectJourneyPages(WebDriver driver, TestContext context) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	
	}

	/*TO DO
	 * 
	 * @FindBy(how = How.XPATH, using = "//button[text()='Login']")
	public WebElement btnLogin;

	@FindBy(how = How.XPATH, using = "//h4")
	public WebElement txtH4Header;

	@FindBy(how = How.XPATH, using = "//h2")
	public WebElement txtH2Header;

	@FindBy(how = How.XPATH, using = "//span[@class='pageError-message']")
	public WebElement txtPageErrorMsg;

*/
	
	public void CompletOneConnectJourney(String email, String mobileNumber, String amount, String term,
			String loanType) throws Exception {
		try {

			
			
		
			
			
			// turn implicit wait to 2
			helper.setImplicitTimeout(driver, 10);

			// Landing Page
			/*try {

				// if Edit Button is displayed don't update details
				if (WaitUtils.isElementPresentWithoutImplicitWait(driver,
						By.xpath("//button[text()='Edit details']"))) {
					helper.clickAnyButtonInDigitalJourney("Get started",driver);

				} else {

					driver.findElement(By.id("email")).clear();
					driver.findElement(By.id("email")).sendKeys(email);
					
					driver.findElement(By.id("mobileNumber")).clear();
					driver.findElement(By.id("mobileNumber")).sendKeys(mobileNumber);
			
					// helper.clickAnybuttonInZambesi("Update");
					helper.clickAnyButtonInDigitalJourney("Get started",driver);
				}

			} catch (Exception e) {
				helper.failTest("Landing Page", "Landing Page", e.getMessage(), driver);
			}*/

			helper.initialisePage(driver, testContext, "OneConnectJourney");

			// Select purpose - for assets
			driver.findElement(By.xpath("//div[@title ='For assets']")).click();
			helper.clickAnyButtonInDigitalJourney("Continue",driver,testContext);

			helper.waitForLoading(driver);


			// Enter Amount & term
			driver.findElement(By.id("AmountSlider")).clear();
			driver.findElement(By.id("AmountSlider")).sendKeys(amount);
			
			driver.findElement(By.id("TermSlider")).clear();
			driver.findElement(By.id("TermSlider")).sendKeys(term);

			helper.clickAnyButtonInDigitalJourney("Get quote",driver,testContext);

			helper.waitForLoading(driver);

			// Choose a type of product loan or overdraft
			if (loanType.equalsIgnoreCase("loan")) {

				helper.clickAnyButtonInDigitalJourney("Choose a loan",driver,testContext);

			} else {

				helper.setImplicitTimeout(driver, 2);

				if (helper.isElementPresent(By.xpath("//button[contains(text(), 'Choose an overdraft')]"),driver))
						helper.clickAnyButtonInDigitalJourney("Choose an overdraft",driver,testContext);

				else
						helper.clickAnyButtonInDigitalJourney("Choose a loan",driver,testContext);
				
			}

			// 
			helper.initialisePage(driver, testContext, "OneConnectJourney");
			
			// Check credit page

			// Set Month
			DJ1_setDateMovedIn("mainMt", "March");

			// Set YEar
			DJ1_setDateMovedIn("mainYr", "2012");

			if (helper.isElementPresent(By.id("secondaryMt"),driver)) {

				// helper.sleepTime(2);

				// Add details mobile number and email
				email = "Jagatpreet.Gill@rbs.co.uk";
				driver.findElements(By.xpath("//a[@id='manualAddress']")).get(1).click();

				// Add email
				driver.findElement(By.xpath("//input[@id='emailAddress']")).clear();
				driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(email);

				// Add mobile phone
				driver.findElement(By.xpath("//input[@id='mobileNumber']")).clear();
				driver.findElement(By.xpath("//input[@id='mobileNumber']")).sendKeys(mobileNumber);

				// Add mobile phone
				driver.findElement(By.xpath("//button[contains(text(), 'Save changes')]")).click();

				// Set Month
				DJ1_setDateMovedIn("secondaryMt", "March");

				// helper.sleepTime(3);
				// Set YEar
				DJ1_setDateMovedIn("secondaryYr", "2009");

			}

			// Confirm & run credit check
			helper.clickAnyButtonInDigitalJourney("Confirm & run a credit check",driver,testContext);
			helper.setImplicitTimeout(driver, 0);
			helper.waitForLoading(driver);

			

			boolean foundLandingPage = false;

			WebDriverWait wait = new WebDriverWait(driver, 60);

			if (wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'approved your')]")))
					.isDisplayed())
				foundLandingPage = true;

			helper.setImplicitTimeout(driver, 2);

			// Confirm & run credit check
			if (!foundLandingPage)
				helper.failTest("One Connect JourneyFlow", "Credit Check failed", "", driver,testContext);

			
			 LegalXCheck();
			 
			 
			
			/*else
				Reporter.reportPassWithSnapshot("validate credit check has passed ", "Application should be displayed",
						"Application should be displayed", driver);

			*/
			
			 /*
			//================================
			helper.waitForLoading(driver);
			helper.clickAnyButtonInDigitalJourney("View documents",driver);
			
			
			helper.waitForLoading(driver);
			helper.clickAnyButtonInDigitalJourney("Confirm",driver);
			
			
			Thread.sleep(3000);
						
			if (WaitUtils.isElementPresentWithoutImplicitWait(driver, By.xpath("//button[text() = 'Confirm']"))) 
				helper.clickAnyButtonInDigitalJourney("Confirm",driver);

			
			Thread.sleep(3000);

			helper.clickAnyButtonInDigitalJourney("Read & sign your documents",driver);
			
			// This will return the number of windows opened by Webdriver and will return Set of St//rings
		    //Set<String>s1=driver.getWindowHandles();
		    // Now we will iterate using Iterator
		    Set<String> windowIterator = driver.getWindowHandles();
		    String parentWindow = driver.getWindowHandle();
		    String childWindow = "";
		      
		    for (String s : windowIterator) 
		      {	         
		          if( s != parentWindow)
		        	  childWindow = s;
		      }

			System.out.println("parent window: "+ parentWindow);
			System.out.println("child window: "+ childWindow);
			
			
			helper.waitForLoading(driver);
			Thread.sleep(5000);
			
			System.out.println(driver.getTitle());
			if( driver.getTitle() == "Untitled")
				Assert.fail("POP UP NOT DISPLAYED");
			
			driver.findElement(By.xpath("//span[@class='checkbox-image']")).click();

		
			driver.findElement(By.id("_evidon-accept-button")).click();
			
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[contains(@class, 'btn btn-primary agree-to-terms')]")).click();
			
			
			
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
			
			Thread.sleep(3000);
			//driver.findElement(By.xpath("//button[contains(@class, 'btn btn-primary click-to-esign')]")).click();
			
			
			driver.findElement(By.xpath("//div[@class='faux_field']")).click();
			
			
			driver.findElement(By.xpath("//input[@value='test']")).sendKeys("test");

			driver.findElement(By.xpath("//button[text()='Apply']")).click();


			driver.findElement(By.xpath("//button[text()='Accept']")).click();


			driver.findElement(By.xpath("//a[@id='download-signed-pdf']")).click();

			
			driver.switchTo().window(parentWindow);

			helper.waitForLoading(driver);
			helper.clickAnyButtonInDigitalJourney("Close this page",driver);
			//driver.findElement(By.xpath("//button[text()='Close this page']")).click();

			
			
			
			
			//================================
			
			
			
			driver.close();
			driver.quit();
			
			*/
			testContext.scenarioContext.setContext(TestData.Status, "Pass");

		} catch (Exception e) {
			testContext.scenarioContext.setContext(TestData.Status, "Fail");
			helper.failTest("OneConnectJourneyFlow ", "OneConnectJourneyFlow", e.getMessage(), driver,testContext);
			driver.close();
			driver.quit();
		}

	}

	public void CaptureApplicationID(String sTestName) throws Exception {
		helper.waitForLoading(driver);
		helper.waitForLoadingElementInvisibility(driver);

		//s1.setupTestName(sTestDataSheetName + "_" + sTestName, "chrome", sTestDataSheetName + "_" + sTestName);

		try {
			// helper.waitForPageHeaderToAppear("Done");
			WebElement appIdLabel = driver.findElement(By.xpath("//span[@class='ApplicationSubmittedDJ_appID_1xbg']"));
			String appID = appIdLabel.getText();
			System.out.println("App Id: " + appID);
			String brand = "RBS";
			ExcelUtils.WriteApplicationIDToDataSheet(sTestDataSheetName, sTestName, brand, appID);
		} catch (Exception e) {
			helper.failTest("Done Page - Error writing Application ID", "Error writing Application ID", "",
					driver,testContext);
		}

	}

	// Set Date Moved in
	private void DJ1_setDateMovedIn(String id, String textToSelect) {

		// Select the drop down
		WebElement ddElement = driver.findElement(By.xpath("//*[@id='" + id + "']"));
		ddElement.click();

		try {
			// Select option
			WebElement option = driver.findElement(By.xpath("//div[contains(text(),'" + textToSelect + "')]"));
			option.click();
		} catch (org.openqa.selenium.StaleElementReferenceException ex) {
			// Select option
			WebElement option = driver.findElement(By.xpath("//div[contains(text(),'" + textToSelect + "')]"));
			option.click();
		}

	}
	
	
	
	
	private void LegalXCheck() throws Exception
	{
		
		boolean foundLandingPage = false;
		
		helper.setImplicitTimeout(driver, 5);


		WebDriverWait wait = new WebDriverWait(driver, 80);

		if (wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'approved your')]")))
				.isDisplayed())
			foundLandingPage = true;
		
		
		// Confirm & run credit check
		if (!foundLandingPage)
			helper.failTest("One Connect JourneyFlow", "Credit Check failed", "", driver,testContext);

		else
			//Reporter.reportPassWithSnapshot("validate credit check has passed ", "Application should be displayed",
					//"Application should be displayed", driver);
			testContext.scenarioContext.setContext(TestData.Status, "Pass");
		
		Thread.sleep(10000);

		//================================
		
		if (helper.isElementPresent(By.xpath("//button[text()='View documents']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("View documents",driver,testContext);
		
		
		 
		if (helper.isElementPresent(By.xpath("//button[text()='Confirm']"),driver)) 
		    helper.clickAnyButtonInDigitalJourney("Confirm",driver,testContext);
		
		
		if (helper.isElementPresent(By.xpath("//button[text()='Confirm']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("Confirm",driver,testContext);

		
		if (helper.isElementPresent(By.xpath("//button[text()='Read & sign your agreement']"),driver))  
			helper.clickAnyButtonInDigitalJourney("Read & sign your agreement",driver,testContext);

		
		
		if (helper.isElementPresent(By.xpath("//button[text()='Read & sign your documents']"),driver)) 
			helper.clickAnyButtonInDigitalJourney("Read & sign your documents",driver,testContext);
		
		Thread.sleep(2000);
		
		helper.getLatestWindowFocused(driver);
		
		System.out.println(driver.getTitle());
		if( driver.getTitle() == "Untitled")
			Assert.fail("POP UP NOT DISPLAYED");

		
		if (helper.isElementPresent(By.xpath("//div[contains(text(),'Cookies')]"),driver)) 
			driver.findElement(By.id("_evidon-accept-button")).click();
	
		
		if (helper.isElementPresent(By.xpath("//span[@class='checkbox-image']"),driver)) 
		    driver.findElement(By.xpath("//span[@class='checkbox-image']")).click();

	
		if (helper.isElementPresent(By.id("_evidon-accept-button"),driver)) 
		    driver.findElement(By.id("_evidon-accept-button")).click();
		
		if (helper.isElementPresent(By.xpath("//button[contains(@class, 'btn btn-primary agree-to-terms')]"),driver)) 
		       driver.findElement(By.xpath("//button[contains(@class, 'btn btn-primary agree-to-terms')]")).click();
		
		
		
		if (helper.isElementPresent(By.xpath("//button[contains(@class, 'coachmark')]"),driver)) 
		driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
		
		
		if (helper.isElementPresent(By.xpath("//button[text()='Accept']"),driver))
			driver.findElement(By.xpath("//button[text()='Accept']")).click();
		
		
		if (helper.isElementPresent(By.xpath("//input[@name='ilaChoice' and @value='Taken']"),driver)) {
			
			driver.findElement(By.xpath("//input[@name='ilaChoice' and @value='Taken']")).click();
			
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[contains(@class, 'coachmark')]")).click();
			
			
		}
		
		Thread.sleep(3000);
		if (helper.isElementPresent(By.xpath("//div[@class='faux_field']"),driver)) 
			   driver.findElement(By.xpath("//div[@class='faux_field']")).click();
		
		helper.getLatestWindowFocused(driver);
		
		
		if (helper.isElementPresent(By.xpath("//button[@class='btn btn-primary click-to-esign ']"),driver) && driver.findElement(By.xpath("//button[@class='btn btn-primary click-to-esign ']")).isDisplayed() ) 
			   driver.findElement(By.xpath("//button[@class='btn btn-primary click-to-esign ']")).click();
			
	
		
		
		if (helper.isElementPresent(By.xpath("//input[@value='test']"),driver)) 
			driver.findElement(By.xpath("//input[@value='test']")).sendKeys("test");

			

		if (helper.isElementPresent(By.xpath("//button[text()='Apply']"),driver)) 
			driver.findElement(By.xpath("//button[text()='Apply']")).click();
		
		
		Thread.sleep(3000);
		
		if (helper.isElementPresent(By.id("form-control-signerName"),driver))   {
			driver.findElement(By.id("form-control-signerName")).sendKeys("test");
			driver.findElement(By.id("form-control-signerName")).sendKeys(Keys.ENTER);
		}
		
		
		Thread.sleep(3000);
		
		if (helper.isElementPresent(By.xpath("//button[text()='Accept']"),driver))
		driver.findElement(By.xpath("//button[text()='Accept']")).click();
		

		if (helper.isElementPresent(By.id("download-signed-pdf"),driver))
			driver.findElement(By.id("download-signed-pdf")).click();  
		
		Thread.sleep(2000);
		driver.close();
		Thread.sleep(2000);
		helper.getLatestWindowFocused(driver);
		
		
		helper.waitForLoading(driver);
		helper.clickAnyButtonInDigitalJourney("Close this page",driver,testContext);
		
		helper.resetImplicitTimeoutToDefault(driver);

	}
	
	
}


