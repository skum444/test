package com.rbs.automation.dj.pages;

import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ThankYouPage {

    private WebDriver driver;
    private String sDataSheetName = "ThankYou";
    TestContext testContext;
    private HelperFunctions helper = new HelperFunctions();
    private WaitUtils waitUtils;

    public ThankYouPage(WebDriver driver, TestContext context) {

        PageFactory.initElements(driver, this);
        this.driver = driver;
        testContext = context;
    }

    @FindBy(how = How.XPATH, using = "//span[@class='zb-card-header-title']")
    public WebElement textThankYou;

    public void verifyThankYouPageIsDisplayed() throws Exception {
       // helper.initialisePage(driver,testContext, "ThankYou");

        try {
            if (!textThankYou.getText().contains("We've received your callback request")){
                helper.failTest("Thank you Page", "We've received your callback request" ,"" ,driver,testContext);

            }
        }catch (Exception e) {
            helper.failTest("Thank you Page","We've received your callback request",e.getMessage(),driver,testContext);
        }
        System.out.println("");
    }

    public void saveAndExit() throws Exception {

        helper.clickAnyButtonInDigitalJourney("Save & exit",driver,testContext);

    }
}

