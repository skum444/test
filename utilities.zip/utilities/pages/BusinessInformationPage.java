package com.rbs.automation.dj.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.helpers.ExcelUtils;
import com.rbs.automation.dj.helpers.HelperFunctions;
import com.rbs.automation.dj.helpers.WaitUtils;
import com.rbs.automation.dj.testcontext.TestContext;

public class BusinessInformationPage {

	private WebDriver driver;
	TestContext testContext;
	private HelperFunctions helper = new HelperFunctions();
	private WaitUtils waitUtils;
	private String sTestDataSheetName = "BusinessInformation";
	private String savedBusinessInformation = "";

	// initialise the page elements when the class is instantiated
	public BusinessInformationPage(WebDriver driver, TestContext context) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		testContext = context;
	}

	// Key Principles page Header
	@FindBy(how = How.XPATH, using = "//h1")
	public WebElement txtHeader;
	
	@FindBy(how = How.XPATH, using = "//li[@role='option']/div")
	public List<WebElement> listoption;
	

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Edit details')]")
	public WebElement linkEditBusinessInfo;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'BusinessInformationPage_infoText')]")
	public WebElement txtStaticMessage;
	
	//@FindBy(how = How.XPATH, using = "//*[@id=\"zb-radio-group-field-115\"]/span/a")
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'How do you')]/a")
	
	public WebElement linkmanageRisks;
	
	//@FindBy(how = How.XPATH, using = "//*[@id=\"zb-modal-body-5\"]/h2")
	@FindBy(how = How.XPATH, using = "//div[@class='zb-modal-card']//h2")
	public List<WebElement> txtManageRisksHeader;
	
	@FindBy(how = How.XPATH, using = "(//*[@class='zb-icon-core-modal-close zb-icon'])[2]")
	public WebElement buttonCloseManageRisksWindow;
	
	
	
	
	@FindBy(how = How.XPATH, using = "//a[text()='How we use your information']")
	public WebElement linkHowWeUseYourInfo;
	
	
	

	// Business Info

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Company name')]//following-sibling::div[1]")
	public WebElement txtCompanyName;
	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Registered company number')]//following-sibling::div[1]")
	public WebElement txtRegisteredNumber;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Company sector')]//following-sibling::div[1]")
	public WebElement txtCompanySector;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Sub-sector')]//following-sibling::div[1]")
	public WebElement txtCompanySubSector;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Trading start date')]//following-sibling::div[1]")
	public WebElement txtTradingStartDate;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Company address')]//following-sibling::div[1]")
	public WebElement txtCompanyAddress;
	

	// Edit business info

	@FindBy(how = How.NAME, using = "name")
	public WebElement inputCompanyName;

	@FindBy(how = How.NAME, using = "registeredNo")
	public WebElement inputRegistereNo;

	@FindBy(how = How.XPATH, using = "//label[contains(.,'Company sector')]/following::input")
	public WebElement selectDDCompanySector;

	@FindBy(how = How.XPATH, using = "//label[contains(.,'Sub-sector')]/following::input")
	public WebElement selectDDCompanySubSector;

	@FindBy(how = How.XPATH, using = "//label[contains(.,'Trading start')]/following::input[1]")
	public WebElement selectDDTradingStartMonth;

	@FindBy(how = How.XPATH, using = "//label[contains(.,'Trading start')]/following::input[2]")
	public WebElement selectDDTradingStartYear;

	// Address fields

	// These have been taken out
	@FindBy(how = How.XPATH, using = "//a[text()='Company address look up']")
	public WebElement linkPostCodeLookUp;

	@FindBy(how = How.NAME, using = "houseNumber")
	public WebElement inputHouseNumber;
	
	@FindBy(how = How.XPATH, using = "//label[contains(.,'Country')]/following::input")
	public WebElement selectDDCountry;
	

	@FindBy(how = How.NAME, using = "addressLine1")
	public WebElement inputHouseFlatBuildingName;
	//===================================================
	

	@FindBy(how = How.NAME, using = "addressLine1")
	public WebElement inputAddressLine1;

	@FindBy(how = How.NAME, using = "addressLine2")
	public WebElement inputAddressLine2;

	@FindBy(how = How.NAME, using = "addressLine3")
	public WebElement inputCity;

	@FindBy(how = How.NAME, using = "postCode")
	public WebElement inputPostcode;



	@FindBy(how = How.XPATH, using = "//img[@alt='Exit']")
	public WebElement btnExit;

	// Tell us more about your business options

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'your annual business income?')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtn3LrgCust50PerYes;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'your annual business income?')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtn3LrgCust50PerNo;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'annual business purchases')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtn3LrgSupp50PerYes;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'annual business purchases')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtn3LrgSupp50PerNo;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'semi-professional cricket club or rugby club or football club')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtnCricketClubYes;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'semi-professional cricket club or rugby club or football club')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtnCricketClubNo;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'personal injury / consumer litigation sector')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtnLegalActivitiesYes;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'personal injury / consumer litigation sector')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtnLegalActivitiesNo;

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'tenure of your trading premises')]/following::input")
	public WebElement selectTenureTradingPremises;

	@FindBy(how = How.NAME, using = "leaseYear")
	public WebElement inputLeaseTerm;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'business a franchise')]/following::span[@role='radio'][1]")
	public WebElement rdBtnIsTheBusinessAFranciseYes;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'business a franchise')]/following::span[@role='radio'][2]")
	public WebElement rdBtnIsTheBusinessAFranciseNo;

	@FindBy(how = How.NAME, using = "businessName")
	public WebElement inputFranchiseName;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'overseas supply / demand')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtnIsTheBusinessOverseasDepYes;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'overseas supply / demand')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtnIsTheBusinessOverseasDepNo;

	
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'How do you')]/following::span[@class='zb-radio-button'][1]")
	public WebElement rdBtnAlwaysManageRisk;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'How do you')]/following::span[@class='zb-radio-button'][2]")
	public WebElement rdBtnSometimesManageRisk;

	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'How do you')]/following::span[@class='zb-radio-button'][3]")
	public WebElement rdBtnNotNecessaryManageRisk;

	
	
	   public void getBIZeditINfoList(List<Map<String, String>> BIZEditInfoList) throws Exception {
		   String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
		   System.out.println("Appid:"+appID);
		   
				String companyName = BIZEditInfoList.get(0).get("companyName");
				String RegiteredNumber = BIZEditInfoList.get(0).get("RegiteredNumber");
				String Sector = BIZEditInfoList.get(0).get("Sector");
				String SubSector = BIZEditInfoList.get(0).get("SubSector");
				String tradingStartDateMonth = BIZEditInfoList.get(0).get("tradingStartDateMonth");
				String TradingStartDateYr = BIZEditInfoList.get(0).get("TradingStartDateYr");
			
				editBusinessDetails(companyName,RegiteredNumber,Sector,SubSector,tradingStartDateMonth,TradingStartDateYr);
		   }
	   
	 
	public void editBusinessDetails(String companyName, String RegiteredNumber, String Sector, String SubSector, String tradingStartDateMonth, String TradingStartDateYr) throws Exception {

		String EntityType = (String) testContext.scenarioContext.getContext(TestData.EnityType);
		
		
		
		if(!(companyName.equalsIgnoreCase("NA")))
		{
		inputCompanyName.sendKeys(companyName);
		}
		
		if(EntityType!=null)
		{
			if((EntityType.equalsIgnoreCase("LLP")) || (EntityType.equalsIgnoreCase("LTD")))
			{
				if(!RegiteredNumber.equalsIgnoreCase("NA"))
				{
					inputRegistereNo.clear();
					inputRegistereNo.sendKeys(RegiteredNumber);
		//helper.enterValue(inputRegistereNo, RegiteredNumber);
				}
			}
		}
	
		helper.scrollWindow(driver,  "0", "100");
		
	//	Sector= "Leisure";
		if(!(Sector.equalsIgnoreCase("NA")))
		{
		selectDDCompanySector.click();
		driver.findElement(By.xpath("//div[contains(text(),'"+Sector+"')]")).click();
		}
		
		if(!(SubSector.equalsIgnoreCase("NA")))
		{
		if(selectDDCompanySubSector.isDisplayed())
		{
		//	SubSector= "Pubs & Bars";
			selectDDCompanySubSector.click();
			driver.findElement(By.xpath("//div[contains(text(),'"+SubSector+"')]")).click();
		}
		}
		if(!(tradingStartDateMonth.equalsIgnoreCase("NA")))
		{
		selectDDTradingStartMonth.click();
		driver.findElement(By.xpath("//div[contains(text(),'"+tradingStartDateMonth+"')]")).click();
		}
		
		if(!(TradingStartDateYr.equalsIgnoreCase("NA")))
		{
		selectDDTradingStartYear.click();
		driver.findElement(By.xpath("//div[contains(text(),'"+TradingStartDateYr+"')]")).click();
		}

	}

	public void updateAddress(List<Map<String, String>> BIZaddrdet ) throws Exception {

		String addressLine1 = BIZaddrdet.get(0).get("addressLine1");
		String addressLine2 = BIZaddrdet.get(0).get("addressLine2");
		String town = BIZaddrdet.get(0).get("town");
		
		String postCode = BIZaddrdet.get(0).get("postCode");
		
		// click the edit details link
		//linkPostCodeLookUp.click();

		//inputHouseNumber.sendKeys("");
		//inputHouseFlatBuildingName.sendKeys("");
		inputAddressLine1.clear();
		inputAddressLine1.sendKeys(addressLine1);
		inputAddressLine2.clear();
		inputAddressLine2.sendKeys(addressLine2);
		inputCity.clear();
		inputCity.sendKeys(town);
		inputPostcode.clear();
		inputPostcode.sendKeys(postCode);
		//selectDDCountry.click();
		//driver.findElement(By.xpath("//div[contains(text(),'United Kindom')]")).click();

	}
	
	
	
	public void verifyBIStaticInfo(String staticMessage) throws Exception
	{
		String staticMsg = txtStaticMessage.getText();
		helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
		
		if(!staticMsg.contains(staticMessage))
			helper.failTest("Static message not displayed on BI screen", staticMessage, staticMsg, driver, testContext);
			
	}
	
	
	public void clickTheHowWeuseUseYourInfoLink() throws Exception
	{
		
		linkHowWeUseYourInfo.click();
			
	}
	
	public void verifyTheBIInformationPageIsDisplayed() throws Exception
	{
		
		helper.setLastestWindow(driver);
		Thread.sleep(4000);
		//helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
	String url = driver.getCurrentUrl();
	
	if(!url.contains("we_use_your_information_"))
		helper.failTest("link does not open how we use your info pdf", "expecting how we use your info pdf", "How we use your info pdf not displayed", driver, testContext);
	
	driver.close();
	helper.setLastestWindow(driver);
	
	}
	
	
	
	
	

	public void saveBusinessDetails() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Save updates", driver, testContext);
	}

	public void cancelEditBusinessDetails() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Cancel", driver, testContext);
	}
	
	

	public void confirmAndContinue() throws Exception {
		helper.clickAnyButtonInDigitalJourney("Confirm and continue", driver, testContext);
	}

	public void clickEditBusinessDetailsLink() throws Exception {
	
		
		//savedBusinessInformation = this.returnCurrentBusinessInformation();
		//testContext.scenarioContext.setContext(TestData.DataComparision, savedBusinessInformation);
		
		// click the edit details link
		linkEditBusinessInfo.click();
	}
	
	
	public void selectCompanySector(String companySector)
	{
		selectDDCompanySector.click();
		driver.findElement(By.xpath("//div[contains(text(),'"+companySector+"')]")).click();
		
	}


	
	public void selectCompanySubSector(String subSector) throws Exception {
		
		helper.setImplicitTimeout(driver, 1);
		
		if(subSector.toLowerCase() == "na" && driver.findElements(By.xpath("//label[contains(.,'Sub-sector')]/following::input")).size()>0)
			helper.failTest("subsector dropdown should not be displayed", "subsector dropdown should not be displayed", "subsector dropdown is displayed", driver, testContext);
		
		if(!subSector.equalsIgnoreCase("na") )
		{
			selectDDCompanySubSector.click();
			driver.findElement(By.xpath("//div[contains(text(),'"+subSector+"')]")).click();
		}
		
	}
	
	
public void verifySubSectorNotDisplayed() throws Exception {
		
		helper.setImplicitTimeout(driver, 1);
		if(driver.findElements(By.xpath("//label[contains(.,'Sub-sector')]/following::input")).size()>0)
			helper.failTest("subsector dropdown should not be displayed", "subsector dropdown should not be displayed", "subsector dropdown is displayed", driver, testContext);
		
		
		helper.resetImplicitTimeoutToDefault(driver);
	}
	
	
	
public void verifySectorFirstOption(String firstOption) throws Exception
{
		boolean Error = false;
		
		selectDDCompanySector.click();
		
		String firstOptionValue = driver.findElement(By.id("react-autowhatever-zb-lookup-5--item-0")).getText();
	
		/*List<WebElement> sectorsFromSite = driver.findElements(By.xpath("//ul/li[@role='option']/div"));
	
		//Thread.sleep(2000);
		
		WebElement e = sectorsFromSite.get(0);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf( e)));
         
		*/
		// ensure last item in list is Other
		if(!firstOptionValue.equalsIgnoreCase(firstOption))
			helper.failTest("company sector first option", "company sector first option is  Please select", "company sector first option is not Please select", driver, testContext);
		
		
		// ensure last item in list is Other
		//if(!sectorsFromSite.get(sectorsFromSite.size()-1).getText().equalsIgnoreCase(lastOption))
			//Error = true;
}
	
	
	public void verifySubSectorFirstandLatOptions(String firstOption, String lastOption) throws Exception
	{
			boolean Error = false;
		
			List<WebElement> subSectorsFromSite = driver.findElements(By.xpath("//ul/li[@role='option']/div"));
		
			// ensure last item in list is Other
			if(!subSectorsFromSite.get(subSectorsFromSite.size()-1).getText().equalsIgnoreCase(lastOption))
			{
				Error = true;
			}
			else
			{
				System.out.println("Lastoption avaialble in the dropdown is " +lastOption);
			}
			
			// ensure last item in list is Other
			if(!subSectorsFromSite.get(0).getText().equalsIgnoreCase(firstOption))
			{
				Error = true;
			}
			else
			{
				System.out.println("firstoption avaialble in the dropdown is " +firstOption);
			}
			
			
			if(Error == true)
				helper.failTest("First and Last options not correct", "First and Last options not correct", "First and Last options not correct", driver, testContext);
	
	}
	
	public void verifySubSectorOptions(List<Map<String, String>> subSectorList) throws Exception
	{
		
		
		
		selectDDCompanySubSector.click();
		Thread.sleep(3000);
		
		
		List<WebElement> subSectorsFromSite = driver.findElements(By.xpath("//ul/li[@role='option']/div"));
		
		boolean Error = false;
		boolean mismatch = false;
		System.out.println("size of list: " +subSectorList.size() );
		

		// Frst check size mismatch
		if(subSectorsFromSite.size()!= subSectorList.size())
			Error = true;
		
		
				
		helper.setImplicitTimeout(driver, 2);
		// check all items are present in the list
		/*
		 * for (int r=0; r<subSectorList.size(); r++) { String text =
		 * subSectorList.get(r).get("SubSectorList");
		 * System.out.println("//div[contains(text(),'"+text+"')]");
		 * if(driver.findElements(By.xpath("//div[contains(text(),'"+text+"')]")).size()
		 * ==0) { Error = true; } else { System.out.println("Subsector " +
		 * subSectorList.get(r).get("SubSectorList") + " is displayed"); }
		 * 
		 * 
		 * }
		 */
		
		// check all items are present in the list
		int listsize = listoption.size();
		
		 for (int r=0; r<subSectorList.size(); r++)
		 {
			 String actoptiontext = listoption.get(r).getText();
			 String exptext = subSectorList.get(r).get("SubSectorList");
			 if(!(actoptiontext.equalsIgnoreCase(exptext)))
			 {
				 Error = true;
				 System.out.println(actoptiontext + " is not displayed in correct position");
			 }
			 else
			 {
				 System.out.println(actoptiontext + " is  displayed"); 
				 
			 }
		 }
		
		
		
		helper.resetImplicitTimeoutToDefault(driver);
	 
		if(Error == true)
			helper.failTest("list mismatch", "list mismatch", "list mismatch", driver, testContext);
		
		
	}
	
	
	public void confirmSectorIsDisplayed(String sector) throws Exception {

		if (!txtCompanySector.getText().trim().equalsIgnoreCase(sector))
			helper.failTest("Business Info", "Company Sector should be: " + sector,
					"Sector displayed is: " + txtCompanySector.getText(), driver, testContext);

	}

	public void confirmSubSectorIsDisplayed(String subSector) throws Exception {
		
		//if (subSector.equalsIgnoreCase("na") && (txtCompanySubSector!= null) && (txtCompanySubSector.isDisplayed()))
			//if (subSector.equalsIgnoreCase("na") && (txtCompanySubSector!= null))
				try
				{
				if( (subSector.equalsIgnoreCase("na")))
						{
					if(txtCompanySubSector.isDisplayed())
					{
						helper.failTest("Business Info", "Company Sub Sector should not be displayed: ",
							"Sub Sector displayed is: " /* + txtCompanySubSector.getText() */, driver, testContext);	
					}
						}
		
		
		
		

		if (!txtCompanySubSector.getText().trim().equalsIgnoreCase(subSector))
			helper.failTest("Business Info", "Company Sub Sector should be: " + subSector,
					"Sub Sector displayed is: " + txtCompanySubSector.getText(), driver, testContext);
				}
				catch (Exception e)
				{
					System.out.println(e);
					System.out.println("Sub sector field is not available");
				}

	}
	
	public void verifyErrorMessageIsDisplayed(String errorMessage) throws Exception
	{
		
		if(!errorMessage.equalsIgnoreCase("na"))
		{
		
			String errorOnScreen = driver.findElement(By.xpath("(//*[contains(text(),'"+errorMessage+"') and @role='tooltip'])")).getText();
		
			if(!errorMessage.equalsIgnoreCase(errorOnScreen))
				helper.failTest("error Message Validation error", "error Message Validation error", "error Message Validation error", driver, testContext);
		
		}
	}
	
	   public void getBIZINfoList(List<Map<String, String>> BIZInfoList) throws Exception {
		   
			String Q1 = BIZInfoList.get(0).get("Q1");
			String Q2 = BIZInfoList.get(0).get("Q2");
			String TenureType = BIZInfoList.get(0).get("TenureType");
			String leaseTerm = BIZInfoList.get(0).get("leaseTerm");
			String IsYourBusinessAFranchise = BIZInfoList.get(0).get("IsYourBusinessAFranchise");
			String franchiseName = BIZInfoList.get(0).get("franchiseName");
			String OveseasSupplyDemand = BIZInfoList.get(0).get("OveseasSupplyDemand");
			String riskManagement = BIZInfoList.get(0).get("riskManagement");
			updateMoreInfoAboutBusiness(Q1,Q2,TenureType,leaseTerm,IsYourBusinessAFranchise,franchiseName,OveseasSupplyDemand,riskManagement);
	   }

	   public void getValuesFromExcelAndupdateMoreInfoAboutBusiness () throws Exception
	   {
			String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
			String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
			// Load data from Data-sheet for the given test into MAP
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_DJ1(sTestDataSheetName, testName, brand);

			// Get info
			String Q1 = tdRow.get("Q1");
			String Q2 = tdRow.get("Q2");
			String TenureType = tdRow.get("TenureOfTradingPremises");
			String leaseTerm = tdRow.get("LeaseTerm");
			String IsYourBusinessAFranchise = tdRow.get("IsYourBusinessAFranchise");
			String franchiseName = tdRow.get("FranchiseName");
			String OveseasSupplyDemand = tdRow.get("OveseasSupplyDemand");
			String riskManagement = tdRow.get("RiskManagement");
			updateMoreInfoAboutBusiness(Q1,Q2,TenureType,leaseTerm,IsYourBusinessAFranchise,franchiseName,OveseasSupplyDemand,riskManagement);
	   }
	public void updateMoreInfoAboutBusiness(String Q1,String Q2,String TenureType,String leaseTerm, String IsYourBusinessAFranchise, String franchiseName, String OveseasSupplyDemand, String riskManagement ) throws Exception {
		
	
		String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
		String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);

	/*	// Load data from Data-sheet for the given test into MAP
		Map<String, String> tdRow = ExcelUtils.getTestDataRow_DJ1(sTestDataSheetName, testName, brand);

		// Get info
		String Q1 = tdRow.get("Q1");
		String Q2 = tdRow.get("Q2");
		String TenureType = tdRow.get("TenureOfTradingPremises");
		String leaseTerm = tdRow.get("LeaseTerm");
		String IsYourBusinessAFranchise = tdRow.get("IsYourBusinessAFranchise");
		String franchiseName = tdRow.get("FranchiseName");
		String OveseasSupplyDemand = tdRow.get("OveseasSupplyDemand");
		String riskManagement = tdRow.get("RiskManagement"); */
		
		

		helper.scrollWindow(driver, "0", "900");

		if (Q1.equalsIgnoreCase("yes"))
			rdBtn3LrgCust50PerYes.click();
		else
			rdBtn3LrgCust50PerNo.click();

		if (Q2.equalsIgnoreCase("yes"))
			rdBtn3LrgSupp50PerYes.click();
		else
			rdBtn3LrgSupp50PerNo.click();

		selectTenureTradingPremises.click();
		driver.findElement(By.xpath("//div[contains(text(), '" + TenureType + "')]")).click();

		if (!TenureType.equalsIgnoreCase("freehold"))
			helper.enterValue(inputLeaseTerm, leaseTerm);
		

	
		
		if (IsYourBusinessAFranchise.equalsIgnoreCase("yes")) {
			rdBtnIsTheBusinessAFranciseYes.click();

			inputFranchiseName.sendKeys(franchiseName);
		} else {
			rdBtnIsTheBusinessAFranciseNo.click();
		}
		
		helper.scrollWindow(driver, "0", "200");
		
		
		
		

		if (OveseasSupplyDemand.equalsIgnoreCase("yes")) {

			rdBtnIsTheBusinessOverseasDepYes.click();

			if (riskManagement.equalsIgnoreCase("always"))
				rdBtnAlwaysManageRisk.click();

			if (riskManagement.equalsIgnoreCase("sometime"))
				rdBtnSometimesManageRisk.click();

			if (riskManagement.equalsIgnoreCase("not-necessary"))
				rdBtnNotNecessaryManageRisk.click();

		} else {

			rdBtnIsTheBusinessOverseasDepNo.click();
		}

		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		
		
	}
	
	
	public void verifyTradingDate(String tradingDate) throws Exception
	{
		
		if(!txtTradingStartDate.getText().equalsIgnoreCase(tradingDate))
				helper.failTest("Trading Date Mismatch", "Trading date expected: "+tradingDate, "Actual trading date: "+txtTradingStartDate.getText() , driver, testContext);
	}
	
	
	public void isThisAProffessionalClub(String answer) throws Exception {
		
		
		if( answer.equalsIgnoreCase("yes"))
			rdBtnCricketClubYes.click();
		else
			rdBtnCricketClubNo.click();
	}
	
	
	public void isThisActiveInConsumerLitigation(String answer) throws Exception {
		
		
		if( answer.equalsIgnoreCase("yes"))
			rdBtnLegalActivitiesYes.click();
		else
			rdBtnLegalActivitiesNo.click();
	}
		
		
			
	public void verifyBusinessInformationHasBeenSaved() throws Exception {
		
		if(!hasBusinessInfoBeenSaved())
			helper.failTest("Save Business details", "business details are saved", "business detail not saved", driver, testContext);
			
		
	}
	
	
	public void enterLeaseTerm(String leaseTerm)
	{
		if(!leaseTerm.equalsIgnoreCase("na")) {
			
			helper.enterValue(inputLeaseTerm, leaseTerm);		
			inputLeaseTerm.click();	
		}
		
	}
	
	public void verifyValidationMessagesExistForMissingBusinessInformation(String validationMessage, String field) throws Exception {
		
		
		String onScreenMessage = driver.findElement(By.xpath("//div[contains(text(),'"+field+"')]//following-sibling::div[1]")).getText();
		
		if(!onScreenMessage.equalsIgnoreCase(validationMessage))
			helper.failTest("Business info validation message present", "Business info validation message NOT present", "Business info validation message present", driver, testContext);
			
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		
	}
	
	
	
	
	public void verifyTheManageRisksLink() throws Exception
	{
		linkmanageRisks.click();
		helper.addCurrentScreenCaptureWOScrolling(driver, testContext);
		
		if(!txtManageRisksHeader.get(1).getText().equalsIgnoreCase("Managing risks linked to overseas demand or supply"))
			helper.failTest("Manage Risk popup message is displayed", "Manage Risk popup message is displayed", "Manage Risk popup meesage not displayed", driver, testContext);
			
		
		buttonCloseManageRisksWindow.click();
		
	}
	
	
	public void verifyBusinessInformationHasNotBeenSaved() throws Exception {
		
		if(hasBusinessInfoBeenSaved())
			helper.failTest("Cancel Business details", "business details are not saved", "business detail are saved", driver, testContext);
			
		
	}
	
	
	private String returnCurrentBusinessInformation(){

		String dataString = "";
		helper.waitForWebElementToBeVisible(driver,txtCompanyName);
		dataString = txtCompanyName.getText()+"-"+txtRegisteredNumber.getText()+"-"+ txtCompanySector.getText()+"-"+ txtCompanySubSector.getText()+"-"+ txtTradingStartDate.getText()+"-"+ txtCompanyAddress.getText();
		
		return dataString;
		
	}
	
	private boolean hasBusinessInfoBeenSaved()
	{

		String dataBeforeEdit = (String) testContext.scenarioContext.getContext(TestData.DataComparision);
			
		String dataAfterEditorCancel = this.returnCurrentBusinessInformation(); 
		
		if(!dataBeforeEdit.equalsIgnoreCase(dataAfterEditorCancel))
			return true;
		else
			return false;
		
	}
	
	public void verifyAddressfieldsNotDisplayed() throws Exception
	{
		helper.scrollWindow(driver, "0", "500");
	
		
		if(helper.isElementPresent(selectDDCountry, driver) || helper.isElementPresent(inputHouseNumber, driver) || helper.isElementPresent(linkPostCodeLookUp, driver))
			helper.failTest("Verify certain address fields are not displayed", "Postcode look up, country and house number fields not displayed", "Postcode look up, country and house number fields are displayed", driver, testContext);
			
		helper.addfullScreenCaptureToExtentReport(driver, testContext);
		helper.resetImplicitTimeoutToDefault(driver);
	}


	public void VerifyBusinessInfoPageIsDisplayed() throws Exception {

		try {
			helper.waitForWebElementToBeVisible(driver,txtHeader);
			helper.addfullScreenCaptureToExtentReport(driver, testContext);
			if (!txtHeader.getText().contains("Your business information")) {

				helper.failTest("Your business information", "Your business information", "incorrect page header",
						driver, testContext);

			}
			
			helper.addCurrentScreenCaptureWOScrolling(driver, testContext);

		} catch (Exception e) {

			helper.failTest("Your business information", "Your business information", e.getMessage(), driver,
					testContext);
		}

	}
	
	public void editFieldName(String fieldName, String fieldValue) throws Exception {

		switch(fieldName) {
		case "CompanyName" :
		   inputCompanyName.clear();
		   inputCompanyName.sendKeys(fieldValue);
		   break;
		   
		case "BuildingName" :
	      // Need to check which field it is from Shazia
	      break;
	      
		case "AddressLine1" :
		   String str;
		   
		   if(fieldValue.contains("addcomma")) {
			   
			   str = inputAddressLine1.getText();
			   StringBuilder sb = new StringBuilder(str);
			   sb.insert(5, ',');
			   System.out.println("Address entered "+str);
			   inputAddressLine1.clear();
			   inputAddressLine1.sendKeys(sb.toString());
			   
		   }else if(fieldValue.contains("deletecomma")) {
			   
			   str = inputAddressLine1.getText();
			   str = str.replaceAll(",", "re");
			   inputAddressLine1.clear();
			   inputAddressLine1.sendKeys(str);
			   
		   }else {
			   
			   inputAddressLine1.clear();
			   inputAddressLine1.sendKeys(fieldValue);
			   
		   }
		   
		   break;
		   
		case "AddressLine2" :
			if(fieldValue.contains("delete")) {
				inputAddressLine2.clear();
			}else {
				inputAddressLine2.clear();
				inputAddressLine2.sendKeys(fieldValue);
			}
		   
		   break;
		   
		case "City" :
		   inputCity.clear();
		   inputCity.sendKeys(fieldValue);
		   break;
		   
		case "Country" :
		      // Need to check which field it is from Shazia
		      break;
		      
		case "CountryPostcode" :
			   inputPostcode.clear();
			   inputPostcode.sendKeys(fieldValue);
			   break;
			   
		case "PCCompanyAddLine2" :
			   inputAddressLine2.clear();
			   inputAddressLine2.sendKeys("Address Line 2");
			   inputPostcode.clear();
			   inputPostcode.sendKeys("Hp13 6aq");
			   inputCompanyName.clear();
			   inputCompanyName.sendKeys("%%**New Comp8any Name$");
			   break;
		      
		case "All" :
		   editBusinessDetails("PetHeaven", "74858687", "Leisure", "O&G Pipelines", "March", "2007");
		   inputAddressLine1.clear();
		   inputAddressLine1.sendKeys("Address Line 1");
		   inputAddressLine2.clear();
		   inputAddressLine2.sendKeys("Address Line 2");
		   inputCity.clear();
		   inputCity.sendKeys("High Wycombe");
		   inputPostcode.clear();
		   inputPostcode.sendKeys("Hp13 6aq");
		   break;
		   
		default :
		   System.out.println("This field was not available in BI Page");
		   helper.failTest("Field to be edited should be available in BI Page", "Field to be edited should be available in BI Page", "Field to be edited "+fieldName+" was not available in BI Page",
					driver, testContext);
		   
		}
	}

}
