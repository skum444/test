package com.rbs.automation.dj.helpers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InvalidPropertiesFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rbs.automation.dj.helpers.TestRun;
import com.rbs.automation.dj.testcontext.TestContext;
import com.rbs.automation.dj.managers.FileReaderManager;



public class GenericUtils {
	

	
	public static String captureScreen(final WebDriver driver ,String snapshotFile) {

			
			//snapshotFile = GenericUtils.getProperty("snapshotPath") + "\\" + snapshotFile;
			
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			
			//waitForPageLoaded(driver);
			
			// Now you can do whatever you need to do with it, for example copy
			// somewhere
			try {
				FileUtils.copyFile(scrFile, new File(snapshotFile));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return snapshotFile;
	}
	
	

	 public static void waitForPageLoaded(WebDriver driver) {

	     ExpectedCondition<Boolean> expectation = new
	ExpectedCondition<Boolean>() {
	        public Boolean apply(WebDriver driver) {
	          return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
	        }
	      };

	     Wait<WebDriver> wait = new WebDriverWait(driver,30);
	      try {
	              wait.until(expectation);
	      } catch(Throwable error) {
	    	  error.printStackTrace();
	              //Assert.assertFalse(true,"Timeout waiting for Page Load Request to complete.");
	      }
	 } 
	
	    
	    
	public static String getMethodName()
	{
		StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
	    StackTraceElement e = stacktrace[1];//coz 0th will be getStackTrace so 1st
	    return  e.getMethodName();
	}
	
	public static ArrayList<String> getBrowsers(){
		
		ArrayList<String> browsers = new ArrayList<String> ();
		try {

		        String filePath = "./config/Browsers.xls";
				FileInputStream file = new FileInputStream(new File(filePath ));

		        // Get the workbook instance for XLS file
		        HSSFWorkbook workbook = new HSSFWorkbook(file);

		        // Get first sheet from the workbook
		        HSSFSheet sheet = workbook.getSheetAt(0);

		        // Iterate through each rows from first sheet
		        Iterator<Row> rowIterator = sheet.iterator();
		        while (rowIterator.hasNext()) {
		            Row row = rowIterator.next();
		          
		            if (row.getCell(1).getStringCellValue().equals("YES"))
		            {
		            	browsers.add(row.getCell(0).getStringCellValue());
		            }
		           
		        }
		        file.close();
		        workbook.close();

		    } catch (FileNotFoundException e1) {
		        e1.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		 
		return browsers;
	}
	
	
	

	public  final static String getDateTime()  
	{  
	    DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh_mm_ss_S");  
	    df.setTimeZone(TimeZone.getTimeZone("IST"));  
	    return df.format(new Date());  
	}
	
	public  final static String getDate()  
	{  
	    DateFormat df = new SimpleDateFormat("dd/MM/yyyy");  
	    df.setTimeZone(TimeZone.getTimeZone("IST"));  
	    return df.format(new Date());  
	}
	
	public static String getProperty(String propertyName)
	{
		
	
		 Properties prop =  FileReaderManager.getInstance().getConfigReader().getProperties();
		 return prop.getProperty(propertyName);
		
	}
	
	
	
	public static String getlabeltext(WebDriver driver, String labelname, String classname) {

		
		String labelvalue;
		try {
			WebElement inforeqelt = driver
					.findElement(By.xpath("//label[@class='" + classname + "'][@for='" + labelname + "']"));
			labelvalue = inforeqelt.getText();
			return labelvalue;
		} catch (Exception e) {

			System.out.println(e);
			e.printStackTrace();
			return null;
		}

	}

	public void updateSecPin(WebDriver driver, String labelname, String classname, char value) {

		//waitForLoading();

		//waitForLoadingElementInvisibility(driver);
		String labelvalue;
		try {
			WebElement inforeqelt = driver
					.findElement(By.xpath("//input[@class='" + classname + "'][@id='" + labelname + "']"));
			String val = Character.toString(value);
			inforeqelt.sendKeys(val);
			
		} catch (Exception e) {

			
			System.out.println(e);
			e.printStackTrace();

		}

	}
	
	

}


