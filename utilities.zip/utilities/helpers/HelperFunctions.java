package com.rbs.automation.dj.helpers;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import com.rbs.automation.dj.pages.FinancialsPage;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.xmlbeans.XmlCursor;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.rbs.automation.dj.enums.TestData;
import com.rbs.automation.dj.managers.FileReaderManager;
import com.rbs.automation.dj.testcontext.TestContext;
import com.cucumber.listener.Reporter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;

import static com.rbs.automation.dj.helpers.TestRun.testRunName;

public class HelperFunctions {
    public static String FieldValidationResultTitle = null;
    public static String FieldValidationResultFirstName = null;
    public static String FieldValidationResultLastName = null;
    public static String FieldValidationResultDOB = null;
    public static String FieldValidationResultEmailAddress = null;
    /**
     * @param testContext
     * @param testName
     * @param regBrand
     * @param segment
     * @desc initiaise the test by setting various params including dir
     */
    public void initialiseTest(TestContext testContext, String testName, String regBrand, String segment) {
        String currentTestreportSnapshotDir = "";

        testContext.scenarioContext.setContext(TestData.TestName, testName);
        testContext.scenarioContext.setContext(TestData.Brand, regBrand);
        testContext.scenarioContext.setContext(TestData.Segment, segment);
        testContext.scenarioContext.setContext(TestData.PageName, "HomePage");
        testContext.scenarioContext.setContext(TestData.Browser, "Chrome");

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String localSnapshotDir = prop.getProperty("localTestResultsPath");
        String remoteSnapshotDir = prop.getProperty("remoteSnapshotPath");

        String testRunName = TestRun.getTestRunName();
        String testRunDir = System.getProperty("user.dir") + localSnapshotDir + "\\" + testRunName;

        currentTestreportSnapshotDir = testRunDir + "\\" + testName + "_" + GenericUtils.getDateTime();

        // set the snaphot dir
        testContext.scenarioContext.setContext(TestData.TestSnapShotDir, currentTestreportSnapshotDir);

        // set the default Test Status as PASS
        testContext.scenarioContext.setContext(TestData.Status, "PASS");

        System.out.println("==== TEST: " + testName);
        System.out.println("==== BRAND: " + regBrand);
        System.out.println("==== SEGMENT: " + segment);

    }

    public void initialiseTest(TestContext testContext, String testName, String regBrand, String segment, String portfolioCode, String entityType, String jiraRef) {
        String currentTestreportSnapshotDir = "";

        testContext.scenarioContext.setContext(TestData.TestName, testName);
        testContext.scenarioContext.setContext(TestData.Brand, regBrand);
        testContext.scenarioContext.setContext(TestData.Segment, segment);
        testContext.scenarioContext.setContext(TestData.EnityType, entityType);
        testContext.scenarioContext.setContext(TestData.JIRA, jiraRef);
        testContext.scenarioContext.setContext(TestData.PortfolioCode, portfolioCode);
        testContext.scenarioContext.setContext(TestData.PageName, "HomePage");
        testContext.scenarioContext.setContext(TestData.Browser, "Chrome");

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String localSnapshotDir = prop.getProperty("localTestResultsPath");
        String remoteSnapshotDir = prop.getProperty("remoteSnapshotPath");

        String testRunName = TestRun.getTestRunName();
        String testRunDir = System.getProperty("user.dir") + localSnapshotDir + "\\" + testRunName;

        currentTestreportSnapshotDir = testRunDir + "\\" + testName + "_" + GenericUtils.getDateTime();

        // set the snaphot dir
        testContext.scenarioContext.setContext(TestData.TestSnapShotDir, currentTestreportSnapshotDir);

        // set the default Test Status as PASS
        testContext.scenarioContext.setContext(TestData.Status, "PASS");

        System.out.println("==== TEST: " + testName);
        System.out.println("==== BRAND: " + regBrand);
        System.out.println("==== SEGMENT: " + segment);
        System.out.println("==== ENTITY TYPE: " + entityType);
        System.out.println("==== JIRA REF: " + jiraRef);

    }


    /**
     * @param web
     * @param driver
     * @param testContext
     * @param pageName
     * @return N/A
     * @desc sets values for page initialisation
     */
    public void initialisePage(WebDriver driver, TestContext testContext, String PageName) throws Exception {

        // wait for page to load
        // waitForLoading(driver);
        waitForLoadingElementInvisibility(driver);
        waitForPageLoaded(driver);

        // Set the page Name
        testContext.scenarioContext.setContext(TestData.PageName, PageName);

        // Ensure you try again in case page does not load
        clickTryAgainOnPageError(driver, testContext);

        String status = (String) testContext.scenarioContext.getContext(TestData.Status);
        String page = (String) testContext.scenarioContext.getContext(TestData.PageName);
        String appId = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);


    }

    /**
     * Wait for the page to fully load
     *
     * @param driver
     */
    public static void waitForPageLoaded(WebDriver driver) {

        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
        };

        Wait<WebDriver> wait = new WebDriverWait(driver, 30);
        try {
            wait.until(expectation);
        } catch (Throwable error) {
            error.printStackTrace();
            // Assert.assertFalse(true,"Timeout waiting for Page Load Request to
            // complete.");
        }
    }

    /**
     * @param driver
     * @throws Exception
     * @desc click the retry button when we get the 'Something went wrong' error
     * message
     */
    public void clickTryAgainOnPageError(WebDriver driver, TestContext testContext) throws Exception {

        try {
            this.waitForLoading(driver);
            int i = 1;
            boolean pageLoadedCorrectly = true;


            while (i <= 5) {
                String url = driver.getCurrentUrl();
                if (url.contains("error")) {
                    driver.findElement(By.xpath("//Button[text() = 'Try again']")).click();
                    Thread.sleep(5000);
                    this.waitForLoading(driver);
                    pageLoadedCorrectly = false;
                    i++;
                } else {
                    pageLoadedCorrectly = true;
                    break;
                }

            }

            if (pageLoadedCorrectly == false)
                failTest("Something went Wrong error", "Something went Wrong error", "", driver, testContext);

        }catch(Exception e) {

            failTest("Something went Wrong error", "Something went Wrong error", "", driver, testContext);
        }

    }

    // Set Date Moved in
    public void setDropDownValue(By by, String textToSelect, WebDriver driver) {

        // Select the drop down
        WebElement ddElement = driver.findElement(by);
        ddElement.click();

        try {
            // Select option
            WebElement option = driver.findElement(By.xpath("//div[contains(text(),'" + textToSelect + "')]"));
            option.click();
        } catch (org.openqa.selenium.StaleElementReferenceException ex) {
            // Select option
            WebElement option = driver.findElement(By.xpath("//div[contains(text(),'" + textToSelect + "')]"));
            option.click();
        }

    }

    /**
     * @param driver
     * @desc reset the implicit timeout to the value in the config
     */
    public void resetImplicitTimeoutToDefault(WebDriver driver) {
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String defaultImplicitTimeout = prop.getProperty("implicitlyWait");

        int timeInSecs = Integer.parseInt(defaultImplicitTimeout);

        // set back to default
        driver.manage().timeouts().implicitlyWait(timeInSecs, TimeUnit.SECONDS);
    }

    /**
     * @param driver
     * @param secs
     * @desc sets the focus on the last opened window
     */
    public void setImplicitTimeout(WebDriver driver, int secs) {
        // set back to default
        driver.manage().timeouts().implicitlyWait(secs, TimeUnit.SECONDS);
    }

    /**
     * @param driver
     * @desc Sets the focus on the last opened window
     */
    public void setLastestWindow(WebDriver driver) {

        Set<String> allwindow = driver.getWindowHandles();
        for (String eachwindow : allwindow) {

            driver.switchTo().window(eachwindow);

        }

    }

    /**
     * @param driver
     * @desc Get the last window opened and in focus
     */
    public static void getLatestWindowFocused(WebDriver driver) {
        String mostRecentWindowHandle = "";
        for (String winHandle : driver.getWindowHandles()) {
            mostRecentWindowHandle = winHandle;
            System.out.println("Window Id: " + winHandle);
        }

        driver.switchTo().window(mostRecentWindowHandle);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.focus();");
        js = null;
    }


    /**
     * @param element and value to populate
     * @return N/A
     * @desc Clear input box and enter value
     */

    public void enterValue(WebElement element, String value) {
        element.clear();
        int stringLength = element.getAttribute("value").length();
        if (stringLength > 0) {
            for (int i = 0; i < stringLength; i++) {
                element.sendKeys(Keys.BACK_SPACE);
            }
        }
        element.sendKeys(value);
        String insertedValue = element.getAttribute("value");
        if (!(insertedValue.equalsIgnoreCase(value))) {
            element.clear();
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
            }
        }
        element.sendKeys(Keys.TAB);
    }

    /**
     * @param filename
     * @return N/A
     * @desc allows us to upload a file when a upload file button is clicked
     */
    public void uploadFile(String fileName) throws AWTException, InterruptedException {

        String path = FileReaderManager.getInstance().getConfigReader().getImageFilePath();

        String fullPath = path + fileName;
        // System.out.println("full path1: "+ fullPath);

        StringSelection ss = new StringSelection(fullPath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

        // imitate mouse events like ENTER, CTRL+C, CTRL+V
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

        Thread.sleep(2000);

    }

    public void WriteNumericCode(String code, String fileName) {
        try {
            FileWriter writer = new FileWriter("src\\test\\resources\\NumericKey.txt", false);
            writer.write(code);
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public String ReadNumericCode(String fileName) {

        String NumericKey = "";
        try {
            BufferedReader reader = new BufferedReader(new FileReader("src\\test\\resources\\NumericKey.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                NumericKey = line;
            }
            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return NumericKey;

    }

    /**
     * @param WebDriver
     * @return N/A
     * @desc wait for load spinner to become invisible
     */
    public void waitForLoading(WebDriver driver) {

        setImplicitTimeout(driver, 0);

        try {

            new WebDriverWait(driver, 0).until(ExpectedConditions
                    .invisibilityOfElementLocated(By.xpath("//img[@alt='//img[@alt='Just a moment...']")));
            resetImplicitTimeoutToDefault(driver);

        } catch (Exception e) {
            resetImplicitTimeoutToDefault(driver);
        }

    }


    /**
     * @param WebDriver
     * @return N/A
     * @desc wait for load spinner to become invisible
     */
    public void waitForWebElementToBeVisible(WebDriver driver, WebElement element) {

        setImplicitTimeout(driver, 0);

        try {

            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .visibilityOf(element));
            resetImplicitTimeoutToDefault(driver);

        } catch (Exception e) {
            resetImplicitTimeoutToDefault(driver);
        }

    }

    /**
     * @param driver
     * @Desc wait for spinner 'please wait' to become invisible
     */
    public void waitForLoadingElementInvisibility(WebDriver driver) {

        try {
            setImplicitTimeout(driver, 0);

            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@class='zb-loader-text']")));

            resetImplicitTimeoutToDefault(driver);

        } catch (Exception e) {

            resetImplicitTimeoutToDefault(driver);
            //this.addCurrentScreenCaptureWOScrolling(driver, testContext);

        }
    }

    /**
     * @param URLtype
     * @return
     * @desc return url from config file
     */
    public String getURLLink(String URLtype) {
        String URL = "";

        if (URLtype.equalsIgnoreCase("QA_01_NWB")) {
            URL = GenericUtils.getProperty("QA_NWB_URL");
            // BPMURL=GenericUtils.getProperty("CIT_BPM");
        } else if (URLtype.equalsIgnoreCase("QA_01_RBS")) {
            URL = GenericUtils.getProperty("QA_RBS_URL");
            // BPMURL=GenericUtils.getProperty("CIT_BPM");
        } else if (URLtype.equalsIgnoreCase("QA_02_RBS")) {
            URL = GenericUtils.getProperty("QA_RBS02_URL");
            // BPMURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("QA_02_NWB")) {
            URL = GenericUtils.getProperty("QA_NWB02_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("QA_03_RBS")) {
            URL = GenericUtils.getProperty("QA_RBS03_URL");
            // BPMURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("QA_03_NWB")) {
            URL = GenericUtils.getProperty("QA_NWB03_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");
            //==
        } else if (URLtype.equalsIgnoreCase("QA_04_NWB")) {
            URL = GenericUtils.getProperty("QA_NWB04_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");

        } else if (URLtype.equalsIgnoreCase("QA_04_RBS")) {
            URL = GenericUtils.getProperty("QA_RBS04_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");


        } else if (URLtype.equalsIgnoreCase("DEV_01_NWB")) {
            URL = GenericUtils.getProperty("DEV_NWB_URL");
            // BPMURL=GenericUtils.getProperty("CIT_BPM");
        } else if (URLtype.equalsIgnoreCase("DEV_01_RBS")) {
            URL = GenericUtils.getProperty("DEV_RBS_URL");
            // BPMURL=GenericUtils.getProperty("CIT_BPM");
        } else if (URLtype.equalsIgnoreCase("DEV_02_RBS")) {
            URL = GenericUtils.getProperty("DEV_RBS02_URL");
            // BPMURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("DEV_02_NWB")) {
            URL = GenericUtils.getProperty("DEV_NWB02_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("DEV_03_RBS")) {
            URL = GenericUtils.getProperty("DEV_RBS03_URL");
            // BPMURL=GenericUtils.getProperty("UAT_BPM");
        } else if (URLtype.equalsIgnoreCase("DEV_03_NWB")) {
            URL = GenericUtils.getProperty("DEV_NWB03_URL");
            // MURL=GenericUtils.getProperty("UAT_BPM");

        } else if (URLtype.equalsIgnoreCase("PRE-NFT_NWB")) {
            URL = GenericUtils.getProperty("PRE-NFT_NWB_URL");
        } else if (URLtype.equalsIgnoreCase("PRE-NFT_RBS")) {
            URL = GenericUtils.getProperty("PRE-NFT_RBS_URL");

        } else if (URLtype.equalsIgnoreCase("NFT_NWB")) {
            URL = GenericUtils.getProperty("NFT_NWB_URL");
        } else if (URLtype.equalsIgnoreCase("NFT_RBS")) {
            URL = GenericUtils.getProperty("NFT_RBS_URL");


        } else if (URLtype.equalsIgnoreCase("PSE_NWB")) {
            URL = GenericUtils.getProperty("PSE_NWB_URL");
            // BPMURL=GenericUtils.getProperty("PSE_BPM");
        } else if (URLtype.equalsIgnoreCase("PSE_RBS")) {
            URL = GenericUtils.getProperty("PSE_RBS_URL");
            // BPMURL=GenericUtils.getProperty("PSE_BPM");

        }

        return URL;

    }

    /**
     * @param URLtype
     * @return
     * @desc return url from config file
     */
    public String getBPMURLLink(String URLtype) {
        String BPMURL = "";

        if (URLtype.equalsIgnoreCase("QA_01_NWB")) {
            // URL = GenericUtils.getProperty("QA_NWB_URL");
            BPMURL = GenericUtils.getProperty("CIT_BPM");

        } else if (URLtype.equalsIgnoreCase("QA_01_RBS")) {
            // URL = GenericUtils.getProperty("QA_RBS_URL");
            BPMURL = GenericUtils.getProperty("CIT_BPM");

        } else if (URLtype.equalsIgnoreCase("QA_02_RBS")) {
            // URL = GenericUtils.getProperty("QA_RBS02_URL");
            BPMURL = GenericUtils.getProperty("UAT_BPM");

        } else if (URLtype.equalsIgnoreCase("QA_02_NWB")) {
            // URL = GenericUtils.getProperty("QA_NWB02_URL");
            BPMURL = GenericUtils.getProperty("UAT_BPM");

        } else if (URLtype.equalsIgnoreCase("CIT_BPM")) {

            BPMURL = GenericUtils.getProperty("CIT_BPM");

        } else if (URLtype.equalsIgnoreCase("PSE_NWB")) {
            // URL = GenericUtils.getProperty("PSE_NWB_URL");
            BPMURL = GenericUtils.getProperty("PSE_BPM");

        } else if (URLtype.equalsIgnoreCase("PSE_RBS")) {
            // URL = GenericUtils.getProperty("PSE_RBS_URL");
            BPMURL = GenericUtils.getProperty("PSE_BPM");

        }
         else if (URLtype.equalsIgnoreCase("QA_04_NWB")) {
            // URL = GenericUtils.getProperty("PSE_NWB_URL");
            BPMURL = GenericUtils.getProperty("UAT_BPM");

        } else if (URLtype.equalsIgnoreCase("QA_04_RBS")) {
            // URL = GenericUtils.getProperty("PSE_RBS_URL");
            BPMURL = GenericUtils.getProperty("UAT_BPM");

        }
        

        return BPMURL;

    }

    /**
     * @param sStepDesc
     * @param sExpected
     * @param sActual
     * @param driver
     * @param context
     * @throws Exception
     * @desc method is called when ever a test fails
     */
    public void failTest(String sStepDesc, String sExpected, String sActual, WebDriver driver, TestContext context)
            throws Exception {

        context.scenarioContext.setContext(TestData.Status, "FAIL");

        // Add screen shots to the Extent Report
        addfullScreenCaptureToExtentReport(driver, context);

        Assert.fail("Test Failed:" + sStepDesc + " || Expected => " + sExpected + " || Actual => " + sActual);
    }

    /**
     * @param driver
     * @param context
     * @throws ParseException
     * @desc Capture network logs
     */
    public void captureNetworkLogFailures(WebDriver driver, TestContext context) throws ParseException {

        LogEntries logEntries = driver.manage().logs().get(LogType.PERFORMANCE);

        List<String> NetworkErrors = new ArrayList<String>();

        for (LogEntry entry : logEntries) {

            if (entry.getMessage().toLowerCase().contains("v1") &&
                    (entry.getMessage().contains(" 500 ")
                            || entry.getMessage().contains(" 502 ")
                            || entry.getMessage().contains(" 503 ")
                            || entry.getMessage().contains(" 400 ")
                            || entry.getMessage().contains(" 403 ")
                            || entry.getMessage().contains(" 404 ")
                            || entry.getMessage().contains(" 501 "))) {


                NetworkErrors.add(entry.getMessage());
            }

        }

        if (NetworkErrors.size() > 0) {
            Reporter.addScenarioLog(
                    "<b=>=============================== Network Log Errors =================================</b>");

            for (String netError : NetworkErrors) {

                String networkError = parseLogObject(netError);

                // String jsonFormattedMsg = toPrettyFormat(netError);
                // log any error to console
                System.out.println(networkError);

                // write any errors to the log
                Reporter.addScenarioLog(networkError);

                // add errors to TestContext
                context.scenarioContext.setContext(TestData.NetworkErrors, networkError);

            }

            Reporter.addScenarioLog(
                    "<b=>==================================================================================</b>");
        }

    }

    private static String parseLogObject(String networkLog) throws ParseException {

        String ErrorString = "";
        // JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        // Read JSON file
        Object logObj = jsonParser.parse(networkLog);

        // JSONArray log = (JSONArray) logObj;

        JSONObject jsonData = (JSONObject) logObj;

        // Get employee object within list
        JSONObject messageObject = (JSONObject) jsonData.get("message");

        // ring header = (String) employeeObject.get("headersText");

        JSONObject params = (JSONObject) messageObject.get("params");

        JSONObject response = (JSONObject) params.get("response");

        JSONObject headers = (JSONObject) response.get("headers");


        String dateTime = (String) headers.get("Date");
        ErrorString += "<b>DateTime: " + dateTime.toString() + "</b>\r";

        String headersText = (String) response.get("headersText");
        String headersTextLine1 = headersText.substring(0, headersText.indexOf("\n"));
        ErrorString += "<b>" + headersTextLine1.toString() + "</b>\r";

        String url = (String) response.get("url");
        ErrorString += "<b>" + url.toString() + "</b>\r";

        return ErrorString.toString();

    }

    /**
     * @param driver
     * @param testContext
     * @return
     * @throws IOException
     * @desc takes a screen shot and returns it's path
     */
    public static String returnScreencapturePath(WebDriver driver, TestContext testContext) throws IOException {

        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        String testSnapShotDir = (String) testContext.scenarioContext.getContext(TestData.TestSnapShotDir);

        File Dest = new File("ScreenShots\\" + System.currentTimeMillis() + ".png");

        String errflpath = Dest.getPath();

        FileUtils.copyFile(scrFile, Dest);

        return errflpath;

    }

    /**
     * @param driver
     * @param context
     * @throws InvalidFormatException
     * @desc Adds a screen shotto the extent report and word evidence document
     */
    public void addfullScreenCaptureToExtentReport(final WebDriver driver, TestContext context)
            throws InvalidFormatException {

        try {

            Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
            String localTestResultsPath = prop.getProperty("localTestResultsPath");

            String testName = (String) context.scenarioContext.getContext(TestData.TestName);
            String brand = (String) context.scenarioContext.getContext(TestData.Brand);
            String segment = (String) context.scenarioContext.getContext(TestData.Segment);

            JavascriptExecutor jexec = (JavascriptExecutor) driver;
            jexec.executeScript("window.scrollTo(0,0)"); // will scroll to (0,0)

            boolean isScrollBarPresent = (boolean) jexec.executeScript(
                    "return document.documentElement.scrollHeight>document.documentElement.clientHeight");
            long scrollHeight = (long) jexec.executeScript("return document.documentElement.scrollHeight");
            long clientHeight = (long) jexec.executeScript("return document.documentElement.clientHeight");
            int fileIndex = 1;
            String pathToScreenShot = "";

            if (driver instanceof WebDriver) {
                if (isScrollBarPresent) {

                    int screenShotCount = 1;
                    while (scrollHeight > 0) {

                        pathToScreenShot = returnScreencapturePath(driver, context);
                        // Always screen shot the page
                        if (screenShotCount == 1) {
                            // Add to extent reports
                            Reporter.addScreenCaptureFromPath(pathToScreenShot);

                            // Add to word doc
                            addToWordDoc(localTestResultsPath + "\\" + TestRun.getTestRunName(), testName, brand, segment,

                                    pathToScreenShot);


                        }

                        jexec.executeScript("window.scrollTo(0," + clientHeight * fileIndex++ + ")");

                        scrollHeight = scrollHeight - clientHeight;

                        // if the page needs to be scrolled then screen shot
                        // again
                        if (scrollHeight > 150) {
                            pathToScreenShot = returnScreencapturePath(driver, context);

                            // Add to extent reports
                            Reporter.addScreenCaptureFromPath(pathToScreenShot);

                            // Add to word doc
                            addToWordDoc(localTestResultsPath + "\\" + TestRun.getTestRunName(), testName, brand, segment,
                                    pathToScreenShot);
                        }

                        screenShotCount++;
                    }
                } else {
                    // On error pages there may not be an scroll bar present

                    pathToScreenShot = returnScreencapturePath(driver, context);

                    // Add to extent reports
                    Reporter.addScreenCaptureFromPath(pathToScreenShot);

                    // Add to word doc
                    addToWordDoc(localTestResultsPath + "\\" + TestRun.getTestRunName(), testName, brand, segment,
                            pathToScreenShot);

                }

            }
        } catch (IOException e) {

            e.printStackTrace();
        }

    }


    public void addCurrentScreenCaptureWOScrolling(final WebDriver driver, TestContext context)
            throws InvalidFormatException {

        try {

            Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
            String localTestResultsPath = prop.getProperty("localTestResultsPath");

            String testName = (String) context.scenarioContext.getContext(TestData.TestName);

            String pathToScreenShot = "";

            if (driver instanceof WebDriver) {

                pathToScreenShot = returnScreencapturePath(driver, context);
                // take screen shot the page

                // Add to extent reports
                Reporter.addScreenCaptureFromPath(pathToScreenShot);

                // Add to word doc
                //            addToWordDoc(localTestResultsPath + "\\" + TestRun.getTestRunName(), testName, pathToScreenShot);

            }

        } catch (IOException e) {

            e.printStackTrace();
        }

    }

    /**
     * @param pathToFile, testname & snapshot path
     * @return N/A
     * @desc Adds a screen shot to the word document
     */
    public static void addToWordDoc(String pathToFile, String testName, String brand, String segment, String sSnapshotPath)
            throws InvalidFormatException, IOException {

        File f = new File(pathToFile + "\\" + testName + "_" + brand + "_" + segment + ".docx");
        XWPFDocument docum;
        if (f.exists()) {
            FileInputStream fis = new FileInputStream(f);
            OPCPackage pkg = OPCPackage.open(fis);
            docum = new XWPFDocument(pkg);
        } else {
            docum = new XWPFDocument();
        }

        try {

            XWPFParagraph p = docum.createParagraph();
            XWPFRun r = p.createRun();
            r.addBreak();
            InputStream imgStream = new FileInputStream(sSnapshotPath);
            BufferedImage img = ImageIO.read(imgStream);
            int w = img.getWidth();
            int h = img.getHeight();
            double scale = 1.0;
            int scaleValue = 72 * 6;
            if (w > scaleValue) {
                scale = (double) scaleValue / w;
            }
            /*
             * r.addPicture(new FileInputStream(sSnapshotPath),
             * XWPFDocument.PICTURE_TYPE_JPEG, "name", Units.toEMU(450),
             * Units.toEMU(300));
             */
            r.addPicture(new FileInputStream(sSnapshotPath), XWPFDocument.PICTURE_TYPE_JPEG, "name",
                    Units.toEMU(w * scale), Units.toEMU(h * scale));

            FileOutputStream out = new FileOutputStream(f);
            docum.write(out);
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * @param pathToFile, testname & snapshot path
     * @return N/A
     * @desc Adds a screen shot to the word document
     */
    public static void addTestStatusToWordDoc(TestContext context) throws InvalidFormatException, IOException {

        // Examples
        // https://www.programcreek.com/java-api-examples/?api=org.apache.poi.xwpf.usermodel.XWPFParagraph

        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String localTestResultsPath = prop.getProperty("localTestResultsPath");

        String pathToFile = localTestResultsPath + "\\" + TestRun.getTestRunName();

        String testName = (String) context.scenarioContext.getContext(TestData.TestName);
        String brand = (String) context.scenarioContext.getContext(TestData.Brand);
        String segment = (String) context.scenarioContext.getContext(TestData.Segment);

        String fileName = testName + "_" + brand + "_" + segment;

        File f = new File(pathToFile + "\\" + fileName + ".docx");
        XWPFDocument docum;
        if (f.exists()) {
            FileInputStream fis = new FileInputStream(f);
            OPCPackage pkg = OPCPackage.open(fis);
            docum = new XWPFDocument(pkg);

            try {

            	
               // add the test info to begining of the document
            	XmlCursor cursor =null;
                
               for (XWPFParagraph paragraph : docum.getParagraphs()) {
            	   cursor = paragraph.getCTP().newCursor();
            	   break;
            	 		  
               }
               
               XWPFParagraph p = docum.insertNewParagraph(cursor);
               XWPFRun r = p.createRun();

              


                r.setText("======================================================");
                r.addBreak();
                r.setText("=================== TEST STATUS =======================");
                r.addBreak();
                r.setText("======================================================");
                r.addBreak();
                r.setText("TEST RUN: " + context.scenarioContext.getContext(TestData.TestRunName));
                r.addBreak();
                r.setText("TEST: " + context.scenarioContext.getContext(TestData.TestName));
                r.addBreak();
                r.setText("SCENARIO NAME: " + context.scenarioContext.getContext(TestData.ScenarioName));
                r.addBreak();
                r.setText("TEST STATUS: " + context.scenarioContext.getContext(TestData.Status));
                r.addBreak();
                r.setText("JIRA REF: " + context.scenarioContext.getContext(TestData.JIRA));
                r.addBreak();
                r.setText("APPLICATION ID: " + context.scenarioContext.getContext(TestData.ApplicationID));
                r.addBreak();
                r.setText("DBID: " + context.scenarioContext.getContext(TestData.DBID));
                r.addBreak();
                r.setText("BIN: " + context.scenarioContext.getContext(TestData.BIN));
                r.addBreak();
                r.setText("PORTFOLIO CODE: " + context.scenarioContext.getContext(TestData.PortfolioCode));
                r.addBreak();
                r.setText("SIC Code: " + context.scenarioContext.getContext(TestData.SICCode));
                r.addBreak();
                r.setText("BRAND: " + context.scenarioContext.getContext(TestData.Brand));
                r.addBreak();
                r.setText("SEGMENT: " + context.scenarioContext.getContext(TestData.Segment));
                r.addBreak();
                r.setText("ENTITY TYPE: " + context.scenarioContext.getContext(TestData.EnityType));
                r.addBreak();
                r.setText("NEEDS INFO: " + context.scenarioContext.getContext(TestData.NeedsInfo));
                r.addBreak();

                r.setText("======================================================");
                r.addBreak();
                r.setText("DB CHECKS");
                r.addBreak();
                r.setText("======================================================");
                r.addBreak();
                
                String AppStatus="";
                if(context.scenarioContext.getContext(TestData.ApplicationStatus)!=null)
                	AppStatus = (String) context.scenarioContext.getContext(TestData.ApplicationStatus);
                	
                
                String reasonText="";
                if(context.scenarioContext.getContext(TestData.ReasonText)!=null)
                	reasonText = (String) context.scenarioContext.getContext(TestData.ReasonText);
                	
                
                
                r.setText("APPLICATION STATUS: " + AppStatus);
                r.addBreak();
                r.setText("REASON TEXT: " + reasonText);
                r.addBreak();
                

                r.addBreak();
                r.setText("REPORT : " + context.scenarioContext.getContext(TestData.TestSnapShotDir));
                r.addBreak();
                if(FieldValidationResultTitle!=null) {
                    r.setText("Field Validation Result : " + FieldValidationResultTitle);
                    r.addBreak();
                }
                if(FieldValidationResultFirstName!=null) {
                    r.setText("Field Validation Result : " + FieldValidationResultFirstName);
                    r.addBreak();
                }
                if(FieldValidationResultLastName!=null) {
                    r.setText("Field Validation Result : " + FieldValidationResultLastName);
                    r.addBreak();
                }
                if(FieldValidationResultDOB!=null) {
                    r.setText("Field Validation Result : " + FieldValidationResultDOB);
                    r.addBreak();
                }
                if(FieldValidationResultEmailAddress!=null) {
                    r.setText("Field Validation Result : " + FieldValidationResultEmailAddress);
                    r.addBreak();
                }
                if (!FinancialsPage.tooltipValidationStatus.equals(""))
                {
                    r.setText("FINANCIAL PAGE:TOOL TIP DESCRIPTION : " + FinancialsPage.tooltipValidationStatus);
                    r.addBreak();
                }
                if (!FinancialsPage.latestFinancialsStatus.equals(""))
                {
                    r.setText("FINANCIAL PAGE:LATEST FINANCIAL INFO : " + FinancialsPage.latestFinancialsStatus);
                    r.addBreak();
                }
                if (!FinancialsPage.reportDateStatus.equals(""))
                {
                    r.setText("FINANCIAL PAGE:REPORTING DATE : " + FinancialsPage.reportDateStatus);
                    r.addBreak();
                }
                if (!FinancialsPage.applStatusReasonVal.equals("")) {
                    r.setText("FINANCIAL TIER3 RULE: APPLICATION STATUS & REASON VALIDATION : " + FinancialsPage.applStatusReasonVal);
                    r.addBreak();
                }
                if (!FinancialsPage.consentTextValidation.equals(""))
                {
                    r.setText("FINANCIAL CONSENT TEXT VALIDATION : " + FinancialsPage.consentTextValidation);
                    r.addBreak();
                }
                if (!FinancialsPage.validationStatus.equals(""))
                {
                    r.setText("FINANCIAL CONSENT TEXT VALIDATION : " + FinancialsPage.validationStatus);
                    r.addBreak();
                }

                r.setText("======================================================");

                if ((String) context.scenarioContext.getContext(TestData.TestName) == "FAIL") {

                    r.addBreak(BreakType.PAGE);
                    r.setText("======================================================");
                    r.setText("================= Network Errors =====================");
                    r.setText("======================================================");
                    r.addBreak();
                    r.setText((String) context.scenarioContext.getContext(TestData.NetworkErrors));
                }

                FileOutputStream out = new FileOutputStream(f);
                docum.write(out);
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * @param string
     * @return JSON object
     * @desc Take network log string and convert to json object
     */
    public static String toPrettyFormat(String jsonString) {
        JsonParser parser = new JsonParser();
        com.google.gson.JsonObject json = parser.parse(jsonString).getAsJsonObject();

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String prettyJson = gson.toJson(json);

        return prettyJson;
    }

    /**
     * @param buttonText
     * @param driver
     * @param context
     * @throws Exception
     * @desc Click any button in DJ using button text
     */
    public void clickAnyButtonInDigitalJourney(String buttonText, WebDriver driver, TestContext context)
            throws Exception {

        this.waitForLoading(driver);
        this.waitForLoadingElementInvisibility(driver);
        try {

            WebElement expButtonToClick = driver.findElement(By.xpath("//button[text()='" + buttonText + "']"));

            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", expButtonToClick);

            if (expButtonToClick != null) {

                // Add screen shot capture for extent report
                addfullScreenCaptureToExtentReport(driver, context);

                expButtonToClick.click();

            }
        } catch (Exception e) {
            e.printStackTrace();
            failTest("button click failed", "button expected:" + buttonText, "Not found", driver, context);
        }

    }

    public void clickAnyLinkInDigitalJourney(String linkText, WebDriver driver, TestContext context)
            throws Exception {

        this.waitForLoading(driver);
        this.waitForLoadingElementInvisibility(driver);
        try {

            WebElement expLinkToClick = driver.findElement(By.xpath("//a[text()='" + linkText + "']"));
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", expLinkToClick);
            if (expLinkToClick != null) {
                Thread.sleep(1);
                expLinkToClick.click();
            }
        } catch (Exception e) {
            //e.printStackTrace();
            failTest("Link click failed", "Link expected:" + linkText, "Not found", driver, context);
        }

    }


    public void scrollToElement(WebDriver driver, By locator) {
        WebElement expButtonToClick = driver.findElement(locator);

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", expButtonToClick);
    }


    public void scrollToElement(WebDriver driver, WebElement element) {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);
    }


    public void scrollWindow(WebDriver driver, String x, String y) {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(" + x + "," + y + ")", "");
    }

    /**
     * @param buttonText
     * @param index
     * @param driver
     * @param context
     * @throws Exception
     * @desc Click any button in DJ using button text By index
     */
    public void clickAnyButtonInDigitalJourney(String buttonText, String index, WebDriver driver, TestContext context)
            throws Exception {

        this.waitForLoading(driver);
        this.waitForLoadingElementInvisibility(driver);
        try {

            WebElement expButtonToClick = driver
                    .findElement(By.xpath("(//button[text()='" + buttonText + "'])[" + index + "]"));

            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", expButtonToClick);

            if (expButtonToClick != null) {

                // Add screen shot capture for extent report
                //addfullScreenCaptureToExtentReport(driver, context);

                Thread.sleep(1);
                expButtonToClick.click();

            }
        } catch (Exception e) {

            failTest("button click failed", "button expected:" + buttonText, "Not found", driver, context);
        }

    }

    /**
     * @param by
     * @param eleName
     * @param driver
     * @return
     * @desc looks for a web element
     */
    public WebElement findAnyWebElement(By by, String eleName, WebDriver driver) {
        WebElement eLe = null;

        try {
            eLe = driver.findElement(by);

            return eLe;

        } catch (Exception e) {

            return null;
        }

    }

    /**
     * @param int number of characters
     * @return String
     * @desc Generates a random string
     */
    public static String randomAlphaNumeric(int count) {

        String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }

        return builder.toString();
    }

    /**
     * @param by
     * @param driver
     * @return
     * @desc Is the element present
     */
    public boolean isElementPresent(By by, WebDriver driver) {
        try {

            setImplicitTimeout(driver, 2);
            driver.findElement(by);
            return true;

        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @param by
     * @param driver
     * @return
     * @desc Is the element present
     */
    public boolean isElementPresent(WebElement element, WebDriver driver) {
        try {

            setImplicitTimeout(driver, 1);
            element.isDisplayed();
            resetImplicitTimeoutToDefault(driver);
            return true;


        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @param testDataSheetName
     * @param appID
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc Write application ID to excel sheet
     */

    public void writeApplicationID(String testDataSheetName, String appID, TestContext testContext, WebDriver driver)
            throws Exception {

        try {
            String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
            String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

            ExcelUtils.WriteApplicationIDToDataSheet(testDataSheetName, testName, appID, brand);

        } catch (Exception e) {
            failTest("Done Page - Error writing Application ID", "Error writing Application ID", "", driver,
                    testContext);
        }

    }

    /**
     * @param testDataSheetName
     * @param reasonText
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc Write Reason text to Data sheet
     */
    public void writeReasonText(String testDataSheetName, String reasonText, TestContext testContext, WebDriver driver)
            throws Exception {

        try {
            String DBID = (String) testContext.scenarioContext.getContext(TestData.DBID);
            String BIN = (String) testContext.scenarioContext.getContext(TestData.BIN);
            String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
            String segment = (String) testContext.scenarioContext.getContext(TestData.Segment);
            String appId = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
            String appStatus = (String) testContext.scenarioContext.getContext(TestData.ApplicationStatus);
            String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);
            String testRunName = TestRun.getTestRunName();

            ExcelUtils.WriteReasonTextToDataSheet(testRunName, testDataSheetName, testName, reasonText, DBID, BIN,
                    brand, segment, appId, appStatus);

        } catch (Exception e) {
            failTest("Data Verification - Error writing Reason Text", "Error writing Reason Text", "", driver,
                    testContext);
        }

    }

    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc Capture BIN id
     */
    public void captureBIN(TestContext testContext, WebDriver driver) throws Exception {

        String DBID = (String) testContext.scenarioContext.getContext(TestData.DBID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application ID for the test
        oracleBBC.returnBIN(DBID, brand, driver);

    }

    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc clear Applications for BIN
     */
    public void removeApplicationsForBIN(String BIN, String brand) throws Exception {

        OracleBBC oracleBBC = new OracleBBC();
        oracleBBC.removeApplicationTraceForBIN(BIN, brand);

    }

    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc Capture application id from DB and write to test context
     */
    public void captureApplicationID(TestContext testContext, WebDriver driver) throws Exception {

        String DBID = (String) testContext.scenarioContext.getContext(TestData.DBID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);
        String testName = (String) testContext.scenarioContext.getContext(TestData.TestName);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application ID for the test
        oracleBBC.callBackDBFetchDJ1(DBID, brand, driver);

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);

        // Write application ID to the data sheet
        //writeApplicationID("Done", appID, testContext, driver);

    }

    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc capture reason id and write to test context
     */
    public void captureReasonText(TestContext testContext, WebDriver driver) throws Exception {

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application ID for the test
        oracleBBC.fetchReasonTestForApplication(appID, brand);

        String reasonText = (String) testContext.scenarioContext.getContext(TestData.ReasonText);

        if (reasonText == null)
            reasonText = "";

        // Write application ID to the data sheet
        writeReasonText("DataVerification", reasonText, testContext, driver);
    }

    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc capture reason
     */
    public String returnReasonForApplication(TestContext testContext, WebDriver driver) throws Exception {

        String reasonText = "";
        this.captureReasonText(testContext, driver);
        reasonText = (String) testContext.scenarioContext.getContext(TestData.ReasonText);
        return reasonText;
    }


    /**
     * @param testContext
     * @param driver
     * @throws Exception
     * @desc return application Status
     */
    public String returnApplicationState(TestContext testContext, WebDriver driver) throws Exception {

        String appState = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        oracleBBC.returnApplicationState(appID, brand);

        appState = (String) testContext.scenarioContext.getContext(TestData.ApplicationStatus);
        return appState;
    }

    public String statusOfKP(TestContext testContext, WebDriver driver) throws Exception {

        String kpState = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        oracleBBC.statusOfKP(appID, brand);

        return kpState;
    }

    public String KPDetailsFromDB(TestContext testContext, WebDriver driver, String field) throws Exception {

        String details = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        details = oracleBBC.KPDetailsFromDB(appID, brand,field);

        return details;
    }


    public String returnApplicationSubStatus(TestContext testContext, WebDriver driver) throws Exception {

        String appSubState = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        oracleBBC.returnApplicationSubStatus(appID, brand);

        appSubState = (String) testContext.scenarioContext.getContext(TestData.ApplicationSubStatus);
        return appSubState;
    }

    public String[] readFromTextFile(String filePath) throws Exception {


        String token1 = "";
        Scanner inFile1 = new Scanner(new File(filePath+"\\src\\test\\resources\\testdata\\CountryDropdownInput.txt")).useDelimiter("[\\r\\n]+");
        List<String> temps = new ArrayList<String>();
        while (inFile1.hasNext()) {
            token1 = inFile1.next();
            temps.add(token1);
        }
        inFile1.close();

        String[] tempsArray = temps.toArray(new String[0]);

        return tempsArray;
    }

    public void writeToTextFile(String[] actualValues) throws Exception {
        // Create our BufferedWriter.
        Properties prop = FileReaderManager.getInstance().getConfigReader().getProperties();
        String localTestResultsPath = prop.getProperty("localTestResultsPath");
        System.out.println(localTestResultsPath+"output path");

        BufferedWriter writer = new BufferedWriter(new FileWriter(
                localTestResultsPath+"\\output.txt"));

        // Loop over the elements in the string array and write each line.
        for (String line : actualValues) {
            writer.write(line);
            writer.newLine();
        }
        writer.close();
    }

    public String returnConsentFlag(TestContext testContext) throws Exception {

        String consentFlag = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String regBrand=(String) testContext.scenarioContext.getContext(TestData.Brand);
        String brand = regBrand.substring(0,regBrand.lastIndexOf("_"));

        OracleBBC oracleBBC = new OracleBBC(testContext);

        consentFlag = oracleBBC.returnConsentFlag(appID, brand);

        return consentFlag;
    }

    public String returnApplicationExpiryDate(TestContext testContext, WebDriver driver) throws Exception {

        String appExpDate = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        oracleBBC.returnApplicationExpiryDate(appID, brand);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        appExpDate= sdf.format(testContext.scenarioContext.getContext(TestData.ApplicationExpDate));
        return appExpDate;
    }

    public String returnFIFlag(TestContext testContext) throws Exception {
        String validFIFlag = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        validFIFlag = oracleBBC.returnValifFIFlag(appID, brand);

        return validFIFlag;
    }

    public String returnApplicationStartDate(TestContext testContext, WebDriver driver) throws Exception {

        String appStartDate = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        oracleBBC.returnApplicationStartDate(appID, brand);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        appStartDate = sdf.format(testContext.scenarioContext.getContext(TestData.ApplicationStartDate));
        return appStartDate;
    }

    public String returnFinUpdEmailAddr(TestContext testContext) throws Exception {
        String emailAddress= "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        emailAddress = oracleBBC.returnFinUpdEmailAddr(appID, brand);

        return emailAddress;
    }

    /*
     * private String getBrand(TestContext testContext) { String regBrand=(String)
     * testContext.scenarioContext.getContext(TestData.Brand);
     * return(regBrand.substring(0,regBrand.lastIndexOf("_"))); }
     */
    public String returnAppLastUpdatedDate(TestContext testContext) throws Exception {

        String appUpdatedDate = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        oracleBBC.returnApplicationUpdateDate(appID, brand);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        appUpdatedDate= sdf.format(testContext.scenarioContext.getContext(TestData.ApplicationUpdatedDate));
        return appUpdatedDate;
    }

    public String returnReportingDate(TestContext testContext) throws Exception {

        String reportingDate = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        oracleBBC.returnReportingDate(appID, brand);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        reportingDate= sdf.format(testContext.scenarioContext.getContext(TestData.ReportingDate));
        return reportingDate;
    }

    public String returnStartDateInFI(TestContext testContext) throws Exception {

        String startDate = "";
        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        oracleBBC.returnReportingDate(appID, brand);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        startDate= sdf.format(testContext.scenarioContext.getContext(TestData.ApplicationStartDate));
        return startDate;
    }

    public Map<String,Double> returnFIFields(TestContext testContext) throws Exception {

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand =(String) testContext.scenarioContext.getContext(TestData.Brand);
        OracleBBC oracleBBC = new OracleBBC(testContext);

        Map<String,Double> fiFields = oracleBBC.returnFIFields(appID, brand);

        return fiFields;
    }

    public String returnApplicationPrevState(TestContext testContext, WebDriver driver) throws Exception {

        String appPrevState = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        oracleBBC.returnPrevApplicationState(appID, brand);

        appPrevState = (String) testContext.scenarioContext.getContext(TestData.ApplicationPrevStatus);
        return appPrevState;
    }
    
    
    public String statusOfKP_STATE_IND_Value(TestContext testContext, WebDriver driver) throws Exception {

        String appKPStateInd = "";

        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
        oracleBBC.returnKPSTATEIND(appID, brand);

        appKPStateInd = (String) testContext.scenarioContext.getContext(TestData.KPStatus);
        System.out.println("appKPStateInd"+appKPStateInd);
        
        return appKPStateInd;
    }
    
    public String statusOfKP_STATE_IND_removed_Value(TestContext testContext, WebDriver driver) throws Exception {

    	String appKPStateInd = "";
        
        String appID = (String) testContext.scenarioContext.getContext(TestData.ApplicationID);
        String brand = (String) testContext.scenarioContext.getContext(TestData.Brand);

        OracleBBC oracleBBC = new OracleBBC(testContext);

        // Pick up and store the Application State for the test
       oracleBBC.removeKPSTATEIND(appID, brand);

        appKPStateInd = (String) testContext.scenarioContext.getContext(TestData.KPStatus);
        System.out.println("appKPStateInd"+appKPStateInd);
        
        return appKPStateInd;
        
    }

   


}
